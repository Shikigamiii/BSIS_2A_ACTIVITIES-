<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Guidelines - OPERAH</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />

    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
        }

        .sidebar {
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, #00416A, #E4E5E6);
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            transition: transform 0.3s ease-in-out;
            z-index: 1050;
        }

        .sidebar .logo {
            display: block;
            margin: 20px auto 10px;
            width: 70px;
            height: 70px;
        }

        .sidebar h4 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: bold;
            color: #fff;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: #ffffffcc;
            text-decoration: none;
            margin-bottom: 6px;
            transition: all 0.2s ease-in-out;
            font-weight: 400;
        }

        .sidebar a i {
            margin-right: 12px;
            font-size: 1.2em;
            flex-shrink: 0;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: rgba(255, 255, 255, 0.1);
            color: #fff;
            font-weight: 600;
            padding-left: 25px;
        }

        .logout {
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.05);
            text-align: center;
        }

        .logout a {
            color:rgb(245, 40, 40);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            font-weight: 500;
        }

        .logout a i {
            margin-right: 8px;
            font-size: 1.2em;
        }

        .content {
            margin-left: 250px;
            padding: 40px 20px;
        }

        .guide-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.05);
        }

        .step-box {
            display: flex;
            align-items: flex-start;
            margin-bottom: 25px;
        }

        .step-number {
            min-width: 40px;
            height: 40px;
            background-color: #007bff;
            color: white;
            font-weight: bold;
            text-align: center;
            line-height: 40px;
            border-radius: 50%;
            margin-right: 15px;
            position: relative;
        }

        .step-number i {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 1.3em;
        }

        @media (max-width: 991.98px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .content {
                margin-left: 0;
                padding: 20px;
            }

            .navbar-toggler {
                margin-left: 10px;
            }
        }
    </style>
</head>
<body>

<!-- NAVBAR for Mobile -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary d-lg-none">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" onclick="toggleSidebar()">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand ms-2" href="#"><i class="bi bi-info-circle me-2"></i>Guidelines</a>
    </div>
</nav>

<!-- OVERLAY for Sidebar Toggle -->
<div class="overlay" id="overlay" onclick="toggleSidebar()"></div>

<!-- Sidebar -->
<div class="sidebar" id="sidebarMenu">
    <div>
        <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo" class="logo">
        <h4>OPERAH System</h4>
        <div class="menu-links">
            <a href="index.php"><i class="bi bi-house-door-fill me-2"></i>Home</a>
            <a href="submit_complaint.php"><i class="bi bi-megaphone-fill me-2"></i>Submit Report</a>
            <a href="history.php"><i class="bi bi-clock-history me-2"></i>Report History</a>
            <a href="request_documents.php"><i class="bi bi-file-earmark-text me-2"></i>Request Documents</a>
            <a href="user_guidelines.php" class="active"><i class="bi bi-info-circle me-2"></i>Guidelines</a>
        </div>
    </div>
    <div class="logout">
        <a href="logout.php"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
    </div>
</div>

<!-- Main Content -->
<div class="content">
    <div class="guide-card container">
        <h3 class="mb-4 text-primary">
            <i class="bi bi-info-circle-fill me-2"></i>
            How to Use the OPERAH System
        </h3>
        <p class="mb-4 text-muted">Follow these simple steps to submit a report, track its progress, and request documents from your barangay.</p>

        <div class="step-box">
            <div class="step-number bg-success">
                <i class="bi bi-person-check-fill"></i>
            </div>
            <div class="step-text">
                <h5>Step 1: Login to Your Account</h5>
                <p>Use your registered email and password to securely access your dashboard and all services offered by the OPERAH System.</p>
            </div>
        </div>

        <div class="step-box">
            <div class="step-number bg-info">
                <i class="bi bi-megaphone-fill"></i>
            </div>
            <div class="step-text">
                <h5>Step 2: Submit a Report</h5>
                <p>Navigate to <strong>Submit Report</strong>. Fill in the report type, description, and location accurately. Attach supporting images if needed.</p>
            </div>
        </div>

        <div class="step-box">
            <div class="step-number bg-warning">
                <i class="bi bi-clock-history"></i>
            </div>
            <div class="step-text">
                <h5>Step 3: Track Report Status</h5>
                <p>Visit <strong>Report History</strong> to view feedback, updates, and resolutions from the barangay staff regarding your report.</p>
            </div>
        </div>

        <div class="step-box">
            <div class="step-number bg-secondary">
                <i class="bi bi-file-earmark-text-fill"></i>
            </div>
            <div class="step-text">
                <h5>Step 4: Request Documents</h5>
                <p>Go to <strong>Request Documents</strong> and choose from options like Barangay Clearance, Indigency, or Residency. Include the purpose and preferred pickup date.</p>
            </div>
        </div>

        <div class="step-box">
            <div class="step-number bg-danger">
                <i class="bi bi-hourglass-split"></i>
            </div>
            <div class="step-text">
                <h5>Step 5: Wait for Confirmation</h5>
                <p>You can monitor the document request status. You’ll be notified once it's <strong>approved</strong> or if any additional information is needed.</p>
            </div>
        </div>

        <hr class="my-4">

        <div class="mt-4">
            <h5 class="text-dark mb-3"><i class="bi bi-lightbulb-fill me-2 text-warning"></i>Quick Tips</h5>
            <ul class="text-muted ps-4">
                <li>Carefully review your report details before submission to avoid delays.</li>
                <li>Ensure your contact information is accurate for smooth communication and updates.</li>
                <li>When requesting a document, select a <strong>preferred pickup date</strong> that gives the barangay ample time to prepare—typically 1–2 working days.</li>
                <li>Track the status of your reports and document requests regularly through the system.</li>
                <li>If your request is urgent or requires clarification, use the Helpdesk or contact the barangay office directly.</li>
            </ul>
        </div>

        <p class="text-muted mt-4">
            Need assistance? Contact the Barangay Helpdesk or email: <a href="https://www.facebook.com/p/Now-Na-Sta-Maria-Ilocos-Sur-100076349209306/">support@sta-maria.gov.ph</a>
        </p>
    </div>
</div>

<!-- Toggle Sidebar Script -->
<script>
    function toggleSidebar() {
        document.getElementById('sidebarMenu').classList.toggle('show');
    }
</script>

</body>
</html>
