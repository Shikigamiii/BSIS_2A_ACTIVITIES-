<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include('includes/db.php');
$user_id = $_SESSION['user_id'];

$user_query = mysqli_query($conn, "SELECT name FROM users WHERE id = '$user_id'");
$user = mysqli_fetch_assoc($user_query);
$user_name = $user['name'] ?? 'User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard - OPERAH</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            margin: 0;
            background-color: #f4f6f9;
            font-family: 'Segoe UI', sans-serif;
        }

        .sidebar {
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, #00416A, #E4E5E6);
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            transition: transform 0.3s ease-in-out;
            z-index: 1050;
        }

        .sidebar .logo {
            display: block;
            margin: 20px auto 10px;
            width: 70px;
            height: 70px;
        }

        .sidebar h4 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: bold;
            color: #fff;
        }

        .sidebar a {
            display: block;
            padding: 12px 20px;
            color: #ffffffcc;
            text-decoration: none;
            margin-bottom: 6px;
            transition: all 0.2s ease-in-out;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: rgba(255, 255, 255, 0.1);
            color: #fff;
            font-weight: 500;
            padding-left: 25px;
        }

        .logout {
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.05);
            text-align: center;
        }

        .logout a {
            color: rgb(245, 40, 40);
            text-decoration: none;
        }

        /* UPDATED CONTENT STYLES WITH BACKGROUND IMAGE */
        .content {
            margin-left: 250px;
            padding: 40px 20px;
            background-image: url('../assets/img/BG.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
            color: #fff;
            text-shadow: 1px 1px 4px rgba(0,0,0,0.7);
        }

        @media (max-width: 991.98px) {
            .sidebar {
                transform: translateX(-100%);
                position: fixed;
                height: 100vh;
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .content {
                margin-left: 0;
                padding: 20px;
            }
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1040;
        }

        .overlay.show {
            display: block;
        }
    </style>
</head>
<body>

<!-- NAVBAR for Mobile -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary d-lg-none">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" onclick="toggleSidebar()">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand ms-2" href="#"><i class="bi bi-house-door-fill me-2"></i>Home</a>
    </div>
</nav>

<!-- OVERLAY for Sidebar Toggle -->
<div class="overlay" id="overlay" onclick="toggleSidebar()"></div>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebarMenu">
    <div>
        <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo" class="logo">
        <h4>OPERAH System</h4>
        <div class="menu-links">
            <a href="index.php" class="active"><i class="bi bi-house-door-fill me-2"></i>Home</a>
            <a href="submit_complaint.php"><i class="bi bi-megaphone-fill me-2"></i>Submit Report</a>
            <a href="history.php"><i class="bi bi-clock-history me-2"></i>Report History</a>
            <a href="request_documents.php"><i class="bi bi-file-earmark-text me-2"></i>Request Documents</a>
            <a href="user_guidelines.php"><i class="bi bi-info-circle me-2"></i>Guidelines</a>
        </div>
    </div>
    <div class="logout">
        <a href="logout.php"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
    </div>
</div>

<!-- MAIN CONTENT -->
<!-- MAIN CONTENT -->
<div class="content">
    <div class="container">
        <h3 class="mb-3 fw-bold"><i class="bi bi-person-circle me-2 text-light"></i>Welcome, <?= htmlspecialchars($user_name) ?> 👋</h3>
        <p class="lead text-light" style="max-width: 600px;">
            Use this Operah System to submit reports, track their status, and request important documents easily and conveniently.
        </p>
    </div>
</div>


<!-- JavaScript -->
<script>
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebarMenu');
        const overlay = document.getElementById('overlay');
        sidebar.classList.toggle('show');
        overlay.classList.toggle('show');
    }
</script>

</body>
</html>
