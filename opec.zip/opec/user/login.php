<?php
session_start();
include('../includes/db.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE email = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 's', $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        header('Location: index.php');
        exit();
    } else {
        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - OPERAH System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f0f2f5;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            font-family: 'Segoe UI', sans-serif;
            padding: 15px;
        }

        .login-container {
            background: #fff;
            padding: 40px 30px;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
            width: 100%;
            max-width: 420px;
        }

        .logo {
            width: 80px;
            height: 80px;
            object-fit: contain;
            margin-bottom: 10px;
        }

        .title-text {
            font-size: 22px;
            font-weight: 700;
            color: #1c1e21;
        }

        .subtitle {
            font-size: 15px;
            color: #606770;
            margin-bottom: 25px;
        }

        .form-label {
            font-weight: 500;
            margin-bottom: 6px;
            color: #333;
        }

        .form-control {
            border-radius: 8px;
            padding: 12px 14px;
            font-size: 15px;
        }

        .btn-login {
            background-color: #42b72a;
            color: #fff;
            border: none;
            padding: 12px;
            font-weight: 600;
            border-radius: 8px;
            font-size: 16px;
            width: 100%;
        }

        .btn-login:hover {
            background-color: #36a420;
        }

        .signup-link {
            margin-top: 20px;
            font-size: 14px;
        }

        .signup-link a {
            text-decoration: none;
            font-weight: 500;
            color: #007bff;
        }

        @media (max-width: 480px) {
            .title-text {
                font-size: 20px;
            }

            .login-container {
                padding: 25px 20px;
            }

            .logo {
                width: 70px;
                height: 70px;
            }
        }
    </style>
</head>
<body>

<div class="login-container text-center">
    <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo" class="logo">
    <div class="title-text">Municipality of Sta. Maria</div>
    <div class="subtitle">Login to your OPERAH account</div>

    <?php if ($error): ?>
        <div class="alert alert-danger text-start"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="mb-3 text-start">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" required placeholder="Enter your email">
        </div>
        <div class="mb-3 text-start">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required placeholder="Enter your password">
        </div>
        <div class="d-grid mt-3">
            <button type="submit" class="btn btn-login">Log In</button>
        </div>
    </form>

    <div class="signup-link">
        Don’t have an account? <a href="register.php">Create one</a>
    </div>
</div>

</body>
</html>
