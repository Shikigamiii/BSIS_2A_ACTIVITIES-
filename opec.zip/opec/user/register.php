<?php
session_start();
include('../includes/db.php');

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = trim($_POST['fname']);
    $lname = trim($_POST['lname']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $birthday = $_POST['b_month'] . ' ' . $_POST['b_day'] . ', ' . $_POST['b_year'];
    $gender = $_POST['gender'];
    $barangay = trim($_POST['barangay']);

    $check = mysqli_prepare($conn, "SELECT id FROM users WHERE email = ?");
    mysqli_stmt_bind_param($check, "s", $email);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);

    if (mysqli_stmt_num_rows($check) > 0) {
        $error = "Email is already registered.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $name = $fname . ' ' . $lname;

        $insert = mysqli_prepare($conn, "INSERT INTO users (name, email, password, barangay, gender, birthday, status) VALUES (?, ?, ?, ?, ?, ?, 'active')");
        mysqli_stmt_bind_param($insert, "ssssss", $name, $email, $hashed_password, $barangay, $gender, $birthday);

        if (mysqli_stmt_execute($insert)) {
            $success = "Registration successful. Please log in.";
        } else {
            $error = "Something went wrong. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Account</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f0f2f5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            font-family: 'Segoe UI', sans-serif;
        }

        .form-box {
            background: #fff;
            border-radius: 12px;
            padding: 30px 25px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 500px;
        }

        .form-box h2 {
            font-size: 26px;
            font-weight: 700;
            text-align: center;
        }

        .form-box small {
            font-size: 14px;
            color: #606770;
            display: block;
            text-align: center;
            margin-bottom: 20px;
        }

        .form-control, .form-select {
            border-radius: 8px;
            padding: 10px 12px;
            font-size: 15px;
        }

        .form-check-input {
            margin-top: 5px;
        }

        .btn-success {
            width: 100%;
            font-size: 16px;
            font-weight: 600;
        }

        .form-text {
            font-size: 12px;
            color: #606770;
            text-align: center;
        }

        .login-link {
            display: block;
            text-align: center;
            margin-top: 16px;
            font-size: 14px;
        }

        @media (max-width: 576px) {
            .form-box {
                padding: 25px 20px;
            }

            .form-box h2 {
                font-size: 22px;
            }
        }
    </style>
</head>
<body>
<div class="form-box">
    <h2>Create a new account</h2>
    <small>It's quick and easy.</small>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="row mb-3">
            <div class="col-12 col-md-6 mb-2 mb-md-0">
                <input type="text" name="fname" class="form-control" placeholder="First name" required>
            </div>
            <div class="col-12 col-md-6">
                <input type="text" name="lname" class="form-control" placeholder="Last name" required>
            </div>
        </div>

        <label class="form-label">Birthday</label>
        <div class="row mb-3">
            <div class="col-4">
                <select class="form-select" name="b_month" required>
                    <option value="">Month</option>
                    <?php for ($m = 1; $m <= 12; $m++): ?>
                        <option><?= date('M', mktime(0, 0, 0, $m, 10)) ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-4">
                <select class="form-select" name="b_day" required>
                    <option value="">Day</option>
                    <?php for ($d = 1; $d <= 31; $d++): ?>
                        <option><?= $d ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-4">
                <select class="form-select" name="b_year" required>
                    <option value="">Year</option>
                    <?php for ($y = date('Y'); $y >= 1950; $y--): ?>
                        <option><?= $y ?></option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>

        <label class="form-label">Gender</label>
        <div class="mb-3">
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" value="Female" required>
                <label class="form-check-label">Female</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" value="Male" required>
                <label class="form-check-label">Male</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" value="Custom" required>
                <label class="form-check-label">Custom</label>
            </div>
        </div>

        <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>

      <label class="form-label">Select Barangay</label>
<select name="barangay" class="form-select mb-3" required>
    <option value="">-- Select Barangay --</option>
    <?php
    $barangays = [
        'Ag-agrao', 'Ampuagan', 'Baballasioan', 'Baliw Daya (San Gelacio)', 'Baliw Laud (Simbuok)',
        'Bia-o', 'Butir', 'Cabaroan', 'Danuman East', 'Danuman West',
        'Dunglayan', 'Gusing', 'Langaoan', 'Laslasong Norte', 'Laslasong Sur',
        'Laslasong West', 'Lesseb', 'Lingsat', 'Lubong', 'Maynganay Norte',
        'Maynganay Sur (San Ignacio)', 'Nagsayaoan', 'Nagtupacan', 'Nalvo', 'Pacang',
        'Penned', 'Poblacion Norte (San Gregorio)', 'Poblacion Sur (San Francisco)',
        'Silag', 'Sumagui', 'Suso', 'Tangaoan', 'Tinaan'
    ];
    foreach ($barangays as $brgy): ?>
        <option value="<?= htmlspecialchars($brgy) ?>"><?= htmlspecialchars($brgy) ?></option>
    <?php endforeach; ?>
</select>


        <input type="password" name="password" class="form-control mb-3" placeholder="New password" required minlength="6">

        <p class="form-text mb-3">
            By clicking Sign Up, you agree to our <a href="#">Terms</a>, <a href="#">Privacy Policy</a>, and <a href="#">Cookies Policy</a>.
        </p>

        <button type="submit" class="btn btn-success">Sign Up</button>
    </form>

    <a href="login.php" class="login-link">Already have an account?</a>
</div>
</body>
</html>
