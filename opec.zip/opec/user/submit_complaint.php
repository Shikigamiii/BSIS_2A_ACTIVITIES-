<?php
// Increase upload and post limits
ini_set('upload_max_filesize', '1024M');
ini_set('post_max_size', '1024M');
ini_set('max_execution_time', '300');
ini_set('max_input_time', '300');
ini_set('memory_limit', '1024M');

session_start();
include('../includes/db.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../PHPMailer/PHPMailer.php';
require '../PHPMailer/SMTP.php';
require '../PHPMailer/Exception.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Admin email config
$admin_email = 'stamariailocossur61@gmail.com';
$admin_name = 'OPERAH Admin';

function file_upload_error_message($error_code) {
    $upload_errors = array(
        UPLOAD_ERR_OK => 'There is no error, the file uploaded successfully.',
        UPLOAD_ERR_INI_SIZE => 'The uploaded file exceeds the upload_max_filesize directive in php.ini.',
        UPLOAD_ERR_FORM_SIZE => 'The uploaded file exceeds the MAX_FILE_SIZE directive specified in the HTML form.',
        UPLOAD_ERR_PARTIAL => 'The uploaded file was only partially uploaded.',
        UPLOAD_ERR_NO_FILE => 'No file was uploaded.',
        UPLOAD_ERR_NO_TMP_DIR => 'Missing a temporary folder.',
        UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
        UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload.',
    );
    return $upload_errors[$error_code] ?? 'Unknown upload error.';
}

$success = '';
$error = '';
$user_id = $_SESSION['user_id'];

// Get user info
$user_result = mysqli_query($conn, "SELECT fullname, email FROM users WHERE id = $user_id");
$user = mysqli_fetch_assoc($user_result);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $barangay = $_POST['barangay'] ?? '';
    $type = ($_POST['type'] ?? '') === 'Other' ? trim($_POST['other_type']) : ($_POST['type'] ?? '');
    $remarks = $_POST['remarks'] ?? '';
    $incident_date = $_POST['incident_date'] ?? '';
    $urgency = $_POST['urgency'] ?? '';
    $file_uploaded = $_FILES['evidence']['name'] ?? '';

    $upload_dir = '../uploads/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
    $upload_path = $upload_dir . basename($file_uploaded);
    $file_ext = strtolower(pathinfo($upload_path, PATHINFO_EXTENSION));
    $allowed_ext = ['jpg', 'jpeg', 'png', 'pdf', 'mp4'];

    if (!empty($barangay) && !empty($type) && !empty($incident_date) && !empty($urgency)) {
        if (!empty($file_uploaded)) {
            if ($_FILES['evidence']['error'] === UPLOAD_ERR_OK) {
                if (in_array($file_ext, $allowed_ext)) {
                    if (!move_uploaded_file($_FILES['evidence']['tmp_name'], $upload_path)) {
                        $error = "Failed to upload file.";
                    }
                } else {
                    $error = "Invalid file format. Only JPG, PNG, PDF, and MP4 are allowed.";
                }
            } else {
                $error = "File upload error: " . file_upload_error_message($_FILES['evidence']['error']);
            }
        } else {
            $file_uploaded = '';
        }

        if (!$error) {
            $stmt = mysqli_prepare($conn, "INSERT INTO complaints (user_id, barangay, type, remarks, incident_date, urgency, evidence, date_filed) VALUES (?, ?, ?, ?, ?, ?, ?, CURDATE())");
            mysqli_stmt_bind_param($stmt, 'issssss', $user_id, $barangay, $type, $remarks, $incident_date, $urgency, $file_uploaded);
            if (mysqli_stmt_execute($stmt)) {
                $success = "Complaint submitted successfully.";

                // ============ SEND EMAIL TO USER ============
                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'stamariailocossur61@gmail.com'; // Your Gmail
                    $mail->Password = 'jxsu lnnp lcnm erzn'; // App password
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;

                    $mail->setFrom('youremail@gmail.com', 'OPERAH System');
                    $mail->addAddress($user['email'], $user['fullname']);
                    $mail->isHTML(true);
                    $mail->Subject = 'Report Submitted Successfully';
                    $mail->Body = "
                        <p>Hello <strong>{$user['fullname']}</strong>,</p>
                        <p>Your report has been submitted successfully:</p>
                        <p><strong>Barangay:</strong> $barangay<br>
                           <strong>Type:</strong> $type<br>
                           <strong>Urgency:</strong> $urgency<br>
                           <strong>Date of Incident:</strong> $incident_date<br>
                           <strong>Remarks:</strong> " . nl2br(htmlspecialchars($remarks)) . "</p>
                        <p>We'll review your report and notify you of updates.</p>
                        <p>Thank you,<br>OPERAH Team</p>";
                    $mail->send();
                } catch (Exception $e) {
                    error_log("User Mailer Error: " . $mail->ErrorInfo);
                }

                // ============ SEND TO ADMIN ============
                $adminMail = new PHPMailer(true);
                try {
                    $adminMail->isSMTP();
                    $adminMail->Host = 'smtp.gmail.com';
                    $adminMail->SMTPAuth = true;
                    $adminMail->Username = 'macktzy@gmail.com';
                    $adminMail->Password = 'xbpt xlmy aakp lpbm';
                    $adminMail->SMTPSecure = 'tls';
                    $adminMail->Port = 587;

                    $adminMail->setFrom('youremail@gmail.com', 'OPERAH System');
                    $adminMail->addAddress($admin_email, $admin_name);
                    $adminMail->isHTML(true);
                    $adminMail->Subject = 'New Complaint Submitted - ' . $barangay;
                    $adminMail->Body = "
                        <p>Hello <strong>{$admin_name}</strong>,</p>
                        <p>A new complaint has been submitted in Barangay <strong>{$barangay}</strong>.</p>
                        <p><strong>From:</strong> {$user['fullname']}<br>
                           <strong>Type:</strong> {$type}<br>
                           <strong>Urgency:</strong> {$urgency}<br>
                           <strong>Date of Incident:</strong> {$incident_date}<br>
                           <strong>Remarks:</strong> " . nl2br(htmlspecialchars($remarks)) . "</p>
                        <p>Check the OPERAH system for full details.</p>
                        <p>Thanks,<br>OPERAH Team</p>";
                    $adminMail->send();
                } catch (Exception $e) {
                    error_log("Admin Mailer Error: " . $adminMail->ErrorInfo);
                }

            } else {
                $error = "Error submitting report. Please try again.";
            }
        }
    } else {
        $error = "Please fill in all required fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Submit Report - OPERAH</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />

    <style>
        body {
            margin: 0;
            background-color: #f4f6f9;
            font-family: 'Segoe UI', sans-serif;
        }
        .sidebar {
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, #00416A, #E4E5E6);
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            transition: transform 0.3s ease-in-out;
            z-index: 1050;
        }
        .sidebar .logo {
            display: block;
            margin: 20px auto 10px;
            width: 70px;
            height: 70px;
        }
        .sidebar h4 {
            text-align: center;
            font-weight: bold;
            margin-bottom: 30px;
        }
        .sidebar a {
            display: block;
            padding: 12px 20px;
            color: #ffffffcc;
            text-decoration: none;
            margin-bottom: 6px;
            transition: all 0.2s ease-in-out;
        }
        .sidebar a:hover,
        .sidebar a.active {
            background-color: rgba(255, 255, 255, 0.1);
            color: #fff;
            font-weight: 500;
            padding-left: 25px;
        }
        .logout {
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.05);
            text-align: center;
        }
        .logout a {
            color: rgb(245, 40, 40);
            text-decoration: none;
        }
        .main-content {
            margin-left: 250px;
            padding: 40px 20px;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
            max-width: 700px;
            margin: auto;
        }
        #other-box {
            display: none;
        }
        @media (max-width: 991.98px) {
            .sidebar {
                transform: translateX(-100%);
                position: fixed;
            }
            .sidebar.show {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
        }
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            background-color: rgba(0,0,0,0.5);
            z-index: 1040;
        }
        .overlay.show {
            display: block;
        }
        #evidence-preview img,
        #evidence-preview video {
            max-width: 100%;
            border-radius: 8px;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<!-- NAVBAR for Mobile -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary d-lg-none">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" onclick="toggleSidebar()">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand ms-2" href="#"><i class="bi bi-megaphone-fill me-2"></i>Submit Complaint</a>
    </div>
</nav>

<!-- OVERLAY -->
<div class="overlay" id="overlay" onclick="toggleSidebar()"></div>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebarMenu">
    <div>
        <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo" class="logo" />
        <h4>OPERAH System</h4>
        <div class="menu-links">
            <a href="index.php"><i class="bi bi-house-door-fill me-2"></i>Home</a>
            <a href="submit_complaint.php" class="active"><i class="bi bi-megaphone-fill me-2"></i>Submit Report</a>
            <a href="history.php"><i class="bi bi-clock-history me-2"></i>Report History</a>
            <a href="request_documents.php"><i class="bi bi-file-earmark-text me-2"></i>Request Documents</a>
            <a href="user_guidelines.php"><i class="bi bi-info-circle me-2"></i>Guidelines</a>
        </div>
    </div>
    <div class="logout">
        <a href="logout.php"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
    </div>
</div>

<!-- MAIN CONTENT -->
<div class="main-content">
    <div class="form-container">
        <h3 class="mb-4"><i class="bi bi-megaphone-fill text-primary me-2"></i>Submit a Report</h3>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php elseif ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data" novalidate>
            <div class="mb-3">
                <label for="barangay" class="form-label">Barangay</label>
                <select name="barangay" id="barangay" class="form-select" required>
                    <option value="">-- Select Barangay --</option>
                    <?php
                    $barangays = ["Ag-agrao", "Ampuagan", "Baballasioan", "Baliw Daya (San Gelacio)", "Baliw Laud (Simbuok)", "Bia-o", "Butir", "Cabaroan", "Danuman East", "Danuman West", "Dunglayan", "Gusing", "Langaoan", "Laslasong Norte", "Laslasong Sur", "Laslasong West", "Lesseb", "Lingsat", "Lubong", "Maynganay Norte", "Maynganay Sur (San Ignacio)", "Nagsayaoan", "Nagtupacan", "Nalvo", "Pacang", "Penned", "Poblacion Norte (San Gregorio)", "Poblacion Sur (San Francisco)", "Silag", "Sumagui", "Suso", "Tangaoan", "Tinaan"];
                    foreach ($barangays as $brgy) {
                        $selected = (isset($_POST['barangay']) && $_POST['barangay'] === $brgy) ? 'selected' : '';
                        echo "<option value=\"" . htmlspecialchars($brgy) . "\" $selected>" . htmlspecialchars($brgy) . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="type" class="form-label">Report Type</label>
                <select name="type" id="type" class="form-select" onchange="toggleOtherBox(this.value)" required>
                    <option value="">-- Select Type --</option>
                    <option value="Noise" <?= (isset($_POST['type']) && $_POST['type'] === 'Noise') ? 'selected' : '' ?>>Noise</option>
                    <option value="Garbage" <?= (isset($_POST['type']) && $_POST['type'] === 'Garbage') ? 'selected' : '' ?>>Garbage</option>
                    <option value="Road Issue" <?= (isset($_POST['type']) && $_POST['type'] === 'Road Issue') ? 'selected' : '' ?>>Road Issue</option>
                    <option value="Other" <?= (isset($_POST['type']) && $_POST['type'] === 'Other') ? 'selected' : '' ?>>Other</option>
                </select>
            </div>

            <div class="mb-3" id="other-box" style="<?= (isset($_POST['type']) && $_POST['type'] === 'Other') ? 'display:block;' : 'display:none;' ?>">
                <label for="other_type" class="form-label">Please specify</label>
                <input type="text" name="other_type" id="other_type" class="form-control" placeholder="Enter complaint type" value="<?= isset($_POST['other_type']) ? htmlspecialchars($_POST['other_type']) : '' ?>">
            </div>

            <div class="mb-3">
                <label for="incident_date" class="form-label">Date of Incident</label>
                <input type="date" name="incident_date" id="incident_date" class="form-control" required value="<?= isset($_POST['incident_date']) ? htmlspecialchars($_POST['incident_date']) : '' ?>">
            </div>

            <div class="mb-3">
                <label for="urgency" class="form-label">Urgency</label>
                <select name="urgency" id="urgency" class="form-select" required>
                    <option value="">-- Select Urgency --</option>
                    <option value="Low" <?= (isset($_POST['urgency']) && $_POST['urgency'] === 'Low') ? 'selected' : '' ?>>Low</option>
                    <option value="Medium" <?= (isset($_POST['urgency']) && $_POST['urgency'] === 'Medium') ? 'selected' : '' ?>>Medium</option>
                    <option value="High" <?= (isset($_POST['urgency']) && $_POST['urgency'] === 'High') ? 'selected' : '' ?>>High</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="evidence" class="form-label">Upload Evidence (Image/Video/PDF)</label>
                <input type="file" name="evidence" id="evidence" class="form-control" accept=".jpg,.jpeg,.png,.pdf,.mp4" onchange="previewEvidence(event)" />
                <div id="evidence-preview"></div>
            </div>

            <div class="mb-3">
                <label for="remarks" class="form-label">Remarks</label>
                <textarea name="remarks" id="remarks" class="form-control" rows="4"><?= isset($_POST['remarks']) ? htmlspecialchars($_POST['remarks']) : '' ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary"><i class="bi bi-send-check-fill me-1"></i>Submit Complaint</button>
        </form>
    </div>
</div>

<script>
function toggleSidebar() {
    document.getElementById('sidebarMenu').classList.toggle('show');
    document.getElementById('overlay').classList.toggle('show');
}
function toggleOtherBox(value) {
    const otherBox = document.getElementById('other-box');
    const otherInput = document.getElementById('other_type');
    if (value === 'Other') {
        otherBox.style.display = 'block';
        otherInput.required = true;
    } else {
        otherBox.style.display = 'none';
        otherInput.required = false;
        otherInput.value = '';
    }
}
function previewEvidence(event) {
    const file = event.target.files[0];
    const preview = document.getElementById('evidence-preview');
    preview.innerHTML = '';

    if (!file) return;
    const url = URL.createObjectURL(file);
    const type = file.type;

    if (type.startsWith('image/')) {
        const img = document.createElement('img');
        img.src = url;
        preview.appendChild(img);
    } else if (type === 'video/mp4') {
        const video = document.createElement('video');
        video.src = url;
        video.controls = true;
        preview.appendChild(video);
    } else {
        preview.innerHTML = `<p>File selected: ${file.name}</p>`;
    }
}

// Frontend file size limit ~1GB
document.getElementById('evidence').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (file && file.size > 1024 * 1024 * 1024) { // 1GB
        alert('File is too large! Maximum allowed size is 1GB.');
        event.target.value = '';
        document.getElementById('evidence-preview').innerHTML = '';
    }
});
</script>

</body>
</html>
