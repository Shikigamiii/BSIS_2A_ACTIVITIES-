<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include('../includes/db.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../PHPMailer/PHPMailer.php';
require '../PHPMailer/SMTP.php';
require '../PHPMailer/Exception.php';

$success = $error = '';

// Fetch user data
$user_id = $_SESSION['user_id'];
$query = mysqli_query($conn, "SELECT barangay, name AS full_name, email, contact_number FROM users WHERE id = $user_id");
$user = mysqli_fetch_assoc($query);
$user_barangay = htmlspecialchars($user['barangay'] ?? '');
$user_name = $user['full_name'];
$user_email = $user['email'];
$contact_number = $user['contact_number'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $document_type = mysqli_real_escape_string($conn, $_POST['document_type']);
    $barangay = mysqli_real_escape_string($conn, $_POST['barangay']);
    $purpose = mysqli_real_escape_string($conn, $_POST['purpose']);
    $pickup_date = mysqli_real_escape_string($conn, $_POST['pickup_date']);
    $notes = mysqli_real_escape_string($conn, $_POST['notes']);

    $query = "INSERT INTO document_requests (user_id, document_type, barangay, purpose, pickup_date, notes, status, date_requested)
              VALUES (?, ?, ?, ?, ?, ?, 'Pending', NOW())";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'isssss', $user_id, $document_type, $barangay, $purpose, $pickup_date, $notes);

    if (mysqli_stmt_execute($stmt)) {
        // Email notification removed as requested
        /*
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'macktzy@gmail.com';
            $mail->Password = 'xbpt xlmy aakp lpbm';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;
            $mail->setFrom('youremail@gmail.com', 'OPEC Document Center');
            $mail->addAddress($user_email, $user_name);
            $mail->isHTML(true);
            $mail->Subject = 'Document Request Confirmation';
            $mail->Body = "
                <h3>Hello, {$user_name}</h3>
                <p>Your document request has been submitted:</p>
                <ul>
                    <li><strong>Document:</strong> {$document_type}</li>
                    <li><strong>Barangay:</strong> {$barangay}</li>
                    <li><strong>Purpose:</strong> {$purpose}</li>
                    <li><strong>Pick-up Date:</strong> {$pickup_date}</li>
                </ul>
                <p>Status: <strong>Pending</strong></p>
                <p>Thank you for using the OPEC System.</p>
            ";
            $mail->send();
            $success = "Request submitted and email sent.";
        } catch (Exception $e) {
            $success = "Request submitted, but email failed: " . $mail->ErrorInfo;
        }
        */

        // Instead, just confirm submission success:
        $success = "Request submitted successfully.";

        // SMS Notification
        $api_key = '3e97b47e1478a74d7367af156fb85235';
        $sender_name = 'Makcy Rin';
        $message = "Hello {$user_name}, your request for {$document_type} (Brgy. {$barangay}) was received. Status: Pending. - OPEC";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.semaphore.co/api/v4/messages');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            'apikey' => $api_key,
            'number' => $contact_number,
            'message' => $message,
            'sendername' => $sender_name
        ]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $sms_response = curl_exec($ch);
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_status == 200) {
            $success .= "<br>SMS notification sent.";
        } else {
            $error .= "<br>SMS sending failed. Response: " . $sms_response;
        }
    } else {
        $error = "Failed to submit your request: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Request Documents - OPERAH</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- Bootstrap & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />

    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
        }

        .sidebar {
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, #00416A, #E4E5E6);
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            z-index: 1050;
        }

        .sidebar .logo {
            display: block;
            margin: 20px auto 10px;
            width: 70px;
            height: 70px;
        }

        .sidebar h4 {
            text-align: center;
            font-weight: bold;
            color: #fff;
            margin-bottom: 30px;
        }

        .sidebar a {
            display: block;
            padding: 12px 20px;
            color: #ffffffcc;
            text-decoration: none;
            transition: 0.2s;
            margin-bottom: 6px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: rgba(255,255,255,0.1);
            color: #fff;
            font-weight: 500;
            padding-left: 25px;
        }

        .sidebar a i {
            margin-right: 8px;
            font-size: 1.1em;
            vertical-align: middle;
        }

        .logout {
            padding: 15px 20px;
            background: rgba(255,255,255,0.05);
            text-align: center;
        }

        .logout a {
            color:rgb(245, 40, 40);
            text-decoration: none;
        }

        .content {
            margin-left: 250px;
            padding: 40px 20px;
        }

        @media (max-width: 991.98px) {
            .sidebar {
                transform: translateX(-100%);
                position: fixed;
                height: 100vh;
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .content {
                margin-left: 0;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- NAVBAR for Mobile -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary d-lg-none">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" onclick="toggleSidebar()">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand ms-2" href="#"><i class="bi bi-file-earmark-text me-2"></i>Request Documents</a>
    </div>
</nav>

<!-- OVERLAY for Sidebar Toggle -->
<div class="overlay" id="overlay" onclick="toggleSidebar()"></div>

<!-- ✅ SIDEBAR -->
<div class="sidebar" id="sidebarMenu">
    <div>
        <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo" class="logo">
        <h4>OPERAH System</h4>
        <div class="menu-links">
            <a href="index.php"><i class="bi bi-house-door-fill me-2"></i>Home</a>
            <a href="submit_complaint.php"><i class="bi bi-megaphone-fill me-2"></i>Submit Report</a>
            <a href="history.php"><i class="bi bi-clock-history me-2"></i>Report History</a>
            <a href="request_documents.php" class="active"><i class="bi bi-file-earmark-text me-2"></i>Request Documents</a>
            <a href="user_guidelines.php"><i class="bi bi-info-circle me-2"></i>Guidelines</a>
        </div>
    </div>
    <div class="logout">
        <a href="logout.php"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
    </div>
</div>

<!-- ✅ CONTENT -->
<div class="content">
    <div class="container">
        <h3 class="mb-4"><i class="bi bi-file-earmark-text-fill text-success me-2"></i>Request Barangay Document</h3>

        <?php if ($success): ?>
            <div class="alert alert-success"><i class="bi bi-check-circle-fill me-2"></i><?= $success ?></div>
        <?php elseif ($error): ?>
            <div class="alert alert-danger"><i class="bi bi-x-circle-fill me-2"></i><?= $error ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="document_type" class="form-label"><i class="bi bi-file-earmark-text me-2"></i>Document Type</label>
                <select name="document_type" id="document_type" class="form-select" required>
                    <option value="">-- Select Document --</option>
                    <option value="Barangay Clearance">Barangay Clearance</option>
                    <option value="Certificate of Residency">Certificate of Residency</option>
                    <option value="Certificate of Indigency">Certificate of Indigency</option>
                    <option value="Business Permit">Business Permit</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label"><i class="bi bi-geo-alt-fill me-2 text-danger"></i>Your Barangay</label>
                <input type="text" class="form-control" value="<?= $user_barangay ?>" readonly />
                <input type="hidden" name="barangay" value="<?= $user_barangay ?>" />
            </div>

            <div class="mb-3">
                <label for="purpose" class="form-label"><i class="bi bi-info-circle me-2 text-warning"></i>Purpose</label>
                <input type="text" name="purpose" id="purpose" class="form-control" required placeholder="e.g., Job Application" />
            </div>

            <div class="mb-3">
                <label for="pickup_date" class="form-label"><i class="bi bi-calendar-event me-2 text-primary"></i>Preferred Pick-up Date</label>
                <input type="date" name="pickup_date" id="pickup_date" class="form-control" required />
            </div>

            <div class="mb-3">
                <label for="notes" class="form-label"><i class="bi bi-chat-left-text me-2 text-secondary"></i>Additional Notes (Optional)</label>
                <textarea name="notes" id="notes" class="form-control" rows="3" placeholder="Any specific instructions..."></textarea>
            </div>

            <button type="submit" class="btn btn-success w-100">
                <i class="bi bi-send-check-fill me-1"></i>Submit Request
            </button>
        </form>
    </div>
</div>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Payment Required Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-warning text-dark">
        <h5 class="modal-title" id="paymentModalLabel"><i class="bi bi-cash-stack me-2"></i>Payment Required</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Your document request has been successfully submitted.</p>
        <p><strong>Note:</strong> Please proceed to your barangay office to pay the required fee for your request.</p>
        <p>Keep your Gmail active for status updates.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Okay</button>
      </div>
    </div>
  </div>
</div>

<?php if ($success): ?>
<script>
    window.addEventListener('DOMContentLoaded', function () {
        var paymentModal = new bootstrap.Modal(document.getElementById('paymentModal'));
        paymentModal.show();
    });
</script>
<?php endif; ?>

<!-- JavaScript -->
<script>
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebarMenu');
        const overlay = document.getElementById('overlay');
        sidebar.classList.toggle('show');
        overlay.classList.toggle('show');
    }
</script>

</body>
</html>
