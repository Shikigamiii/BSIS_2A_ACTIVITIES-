<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$complaints = [];

$stmt = mysqli_prepare($conn, "SELECT * FROM complaints WHERE user_id = ? ORDER BY date_filed DESC");
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result) {
    $complaints = mysqli_fetch_all($result, MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Complaint History - OPERAH</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- ✅ Bootstrap & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
        }

        .sidebar {
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(to bottom right, #00416A, #E4E5E6);
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            transition: transform 0.3s ease;
            z-index: 1050;
        }

        .sidebar .logo {
            display: block;
            margin: 20px auto 10px;
            width: 70px;
            height: 70px;
        }

        .sidebar h4 {
            text-align: center;
            font-weight: bold;
            margin-bottom: 30px;
        }

        .sidebar a {
            display: block;
            padding: 12px 20px;
            color: #ffffffcc;
            text-decoration: none;
            margin-bottom: 6px;
            transition: all 0.2s ease-in-out;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: rgba(255, 255, 255, 0.1);
            color: #fff;
            font-weight: 500;
            padding-left: 25px;
        }

        .logout {
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.05);
            text-align: center;
        }

        .logout a {
            color: rgb(245, 40, 40);
            text-decoration: none;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
        }

        .form-container {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
        }

        @media (max-width: 991.98px) {
            .sidebar {
                transform: translateX(-100%);
                position: fixed;
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding: 15px;
            }
        }

        @media (max-width: 767.98px) {
            .desktop-table {
                display: none;
            }

            .mobile-cards {
                display: block;
            }
        }

        @media (min-width: 768px) {
            .mobile-cards {
                display: none;
            }
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1040;
        }

        .overlay.show {
            display: block;
        }
    </style>
</head>
<body>

<!-- ✅ Mobile Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary d-lg-none">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" onclick="toggleSidebar()">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand ms-2" href="#"><i class="bi bi-clock-history me-2"></i>Complaint History</a>
    </div>
</nav>

<!-- ✅ Overlay -->
<div class="overlay" id="overlay" onclick="toggleSidebar()"></div>

<!-- ✅ Sidebar -->
<div class="sidebar" id="sidebarMenu">
    <div>
        <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo" class="logo">
        <h4>OPERAH System</h4>
        <div class="menu-links">
            <a href="index.php"><i class="bi bi-house-door-fill me-2"></i>Home</a>
            <a href="submit_complaint.php"><i class="bi bi-megaphone-fill me-2"></i>Submit Report</a>
            <a href="history.php" class="active"><i class="bi bi-clock-history me-2"></i>Report History</a>
            <a href="request_documents.php"><i class="bi bi-file-earmark-text me-2"></i>Request Documents</a>
            <a href="user_guidelines.php"><i class="bi bi-info-circle me-2"></i>Guidelines</a>
        </div>
    </div>
    <div class="logout">
        <a href="logout.php"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
    </div>
</div>

<!-- ✅ Main Content -->
<div class="main-content">
    <div class="form-container">
        <h3 class="mb-4"><i class="bi bi-journal-text me-2 text-primary"></i>Your Report History</h3>

        <?php if (count($complaints) > 0): ?>

            <!-- ✅ Desktop Table -->
            <div class="table-responsive desktop-table">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Type</th>
                            <th>Date Filed</th>
                            <th>Status</th>
                            <th>Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($complaints as $index => $complaint): ?>
                            <tr>
                                <td><?= $index + 1 ?></td>
                                <td><?= htmlspecialchars($complaint['type']) ?></td>
                                <td><?= htmlspecialchars($complaint['date_filed']) ?></td>
                                <td>
                                    <?php if ($complaint['status'] == 'Pending'): ?>
                                        <span class="badge bg-warning text-dark">Pending</span>
                                    <?php elseif ($complaint['status'] == 'Resolved'): ?>
                                        <span class="badge bg-success">Resolved</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?= htmlspecialchars($complaint['status']) ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($complaint['remarks'] ?? 'N/A') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- ✅ Mobile Cards -->
            <div class="mobile-cards">
                <?php foreach ($complaints as $index => $complaint): ?>
                    <div class="card mb-3">
                        <div class="card-body">
                            <h6 class="card-title mb-2"><strong>Type:</strong> <?= htmlspecialchars($complaint['type']) ?></h6>
                            <p class="mb-1"><strong>Date Filed:</strong> <?= htmlspecialchars($complaint['date_filed']) ?></p>
                            <p class="mb-1">
                                <strong>Status:</strong>
                                <?php if ($complaint['status'] == 'Pending'): ?>
                                    <span class="badge bg-warning text-dark">Pending</span>
                                <?php elseif ($complaint['status'] == 'Resolved'): ?>
                                    <span class="badge bg-success">Resolved</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><?= htmlspecialchars($complaint['status']) ?></span>
                                <?php endif; ?>
                            </p>
                            <p><strong>Remarks:</strong> <?= htmlspecialchars($complaint['remarks'] ?? 'N/A') ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

        <?php else: ?>
            <div class="alert alert-info"><i class="bi bi-info-circle-fill me-1"></i> You have not submitted any complaints yet.</div>
        <?php endif; ?>
    </div>
</div>

<script>
    function toggleSidebar() {
        document.getElementById('sidebarMenu').classList.toggle('show');
        document.getElementById('overlay').classList.toggle('show');
    }
</script>

</body>
</html>
