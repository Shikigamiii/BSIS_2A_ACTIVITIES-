-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2025 at 06:23 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `opec_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `fullname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`, `email`, `fullname`) VALUES
(1, '', '$2y$10$lySnDnUI3a/dUiUdU5bMGuvqV/Dh0teyRLGLTrY0ht8TGSnoOUzGS', 'macktzy@gmail.com', 'Mcgyver Rin');

-- --------------------------------------------------------

--
-- Table structure for table `captains`
--

CREATE TABLE `captains` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `barangay` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `captains`
--

INSERT INTO `captains` (`id`, `fullname`, `name`, `email`, `password`, `barangay`) VALUES
(1, NULL, 'Macky Rin', 'macktzy@gmail.com', '$2y$10$x15t0BKUuxSuGTyZRaHdbuq9ad33n5YSona63vGKBwCa2m1oF8Eo6', 'Lesseb'),
(2, NULL, 'Ryan Roldan', 'krakengaming011@gmail.com', '$2y$10$EfJUJg4YRWWiHYbB.v4UUeutkrfbjBbHcgVlyAuLNyZ/FeXLef8qu', 'Lingsat'),
(3, NULL, 'GUSTABO', 'cjclauven@gmail.com', '$2y$10$umS3J.6FjWNoZXdgbPgWIOwh.T/O.lwp5nZ0KiV3.bxCU2OsRkFUy', 'MAYNGANAY NORTE'),
(4, NULL, 'John Mark Bandong', 'johnmarkbandong01@gmail.com', '$2y$10$7Ztd4k5Qfi2TRD5wWfZ.L.5jCk728WchCn0.u4F9qqYL8DQYfeHSO', 'Suso');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `barangay` varchar(100) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `type` varchar(100) NOT NULL,
  `remarks` text DEFAULT NULL,
  `date_filed` date NOT NULL DEFAULT curdate(),
  `incident_date` date DEFAULT NULL,
  `urgency` enum('Low','Medium','High') NOT NULL DEFAULT 'Low',
  `evidence` varchar(255) DEFAULT NULL,
  `current_location` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `priority` enum('Low','Medium','High') DEFAULT 'Low',
  `is_anonymous` tinyint(1) DEFAULT 0,
  `complaint_type` varchar(255) DEFAULT NULL,
  `admin_status` varchar(50) DEFAULT NULL,
  `admin_remarks` text DEFAULT NULL,
  `admin_update_approved` tinyint(1) DEFAULT 1,
  `captain_status` varchar(50) DEFAULT NULL,
  `captain_update_approved` tinyint(1) DEFAULT 1,
  `captain_remarks` text DEFAULT NULL,
  `sent_to_captain` tinyint(1) DEFAULT 0,
  `notified_captain` tinyint(1) DEFAULT 0,
  `captain_status_suggestion` varchar(50) DEFAULT NULL,
  `forwarded_to_barangay` tinyint(1) DEFAULT 0,
  `forwarded_to_captain` tinyint(1) DEFAULT 0,
  `sent_to_admin` tinyint(1) NOT NULL DEFAULT 0,
  `shared_to_barangay` tinyint(1) DEFAULT 0,
  `admin_notified` tinyint(1) DEFAULT 0,
  `admin_response` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `user_id`, `barangay`, `title`, `description`, `category`, `status`, `created_at`, `type`, `remarks`, `date_filed`, `incident_date`, `urgency`, `evidence`, `current_location`, `image_path`, `priority`, `is_anonymous`, `complaint_type`, `admin_status`, `admin_remarks`, `admin_update_approved`, `captain_status`, `captain_update_approved`, `captain_remarks`, `sent_to_captain`, `notified_captain`, `captain_status_suggestion`, `forwarded_to_barangay`, `forwarded_to_captain`, `sent_to_admin`, `shared_to_barangay`, `admin_notified`, `admin_response`) VALUES
(51, 8, 'Suso', NULL, NULL, NULL, 'In Progress', '2025-07-03 11:00:33', 'Road Issue', 'Under Construction', '2025-07-03', '2025-07-03', 'Low', 'ROAD.jpg', NULL, NULL, 'Low', 0, NULL, NULL, NULL, 1, NULL, 1, NULL, 0, 0, NULL, 0, 1, 0, 0, 0, NULL),
(52, 7, 'Suso', NULL, NULL, NULL, 'Resolved', '2025-07-03 13:43:36', 'Road Issue', 'The road now resolved', '2025-07-03', '2025-07-03', 'Low', 'ROAD.jpg', NULL, NULL, 'Low', 0, NULL, NULL, NULL, 1, NULL, 1, NULL, 0, 0, NULL, 0, 0, 0, 0, 0, NULL),
(53, 4, 'Lesseb', NULL, NULL, NULL, 'In Progress', '2025-07-04 03:41:45', 'Road Issue', '', '2025-07-04', '2025-07-04', 'Low', '2dcf1939-3d6b-4d2b-bcec-1ccfd054c0e3.mp4', NULL, NULL, 'Low', 0, NULL, NULL, NULL, 1, NULL, 1, NULL, 0, 0, NULL, 0, 1, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `document_requests`
--

CREATE TABLE `document_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `document_type` varchar(100) DEFAULT NULL,
  `purpose` text DEFAULT NULL,
  `barangay` varchar(100) DEFAULT NULL,
  `pickup_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `date_requested` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `document_requests`
--

INSERT INTO `document_requests` (`id`, `user_id`, `document_type`, `purpose`, `barangay`, `pickup_date`, `notes`, `status`, `date_requested`) VALUES
(21, 4, 'Certificate of Residency', 'Job Application', 'Lesseb', '2025-06-22', 'thanks', 'Done', '2025-06-21 19:25:55'),
(22, 4, 'Business Permit', 'For my sari sari store', 'Lesseb', '2025-06-21', '', 'Pending', '2025-06-21 20:02:13'),
(27, 4, 'Barangay Clearance', 'for my job application', 'Lesseb', '2025-06-23', 'thanks', 'Done', '2025-06-23 18:57:24'),
(28, 4, 'Certificate of Indigency', 'For Scholarship', 'Lesseb', '2025-06-28', 'Thanks', 'Done', '2025-06-28 15:31:54'),
(29, 7, 'Barangay Clearance', 'For Job', 'Lingsat', '2025-07-02', 'thanks ', 'Done', '2025-07-02 18:46:20'),
(30, 7, 'Barangay Clearance', 'For Job', 'Lingsat', '2025-07-02', '', 'Done', '2025-07-02 18:49:57');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `complaint_id` int(11) NOT NULL,
  `barangay` varchar(100) NOT NULL,
  `from_admin` tinyint(1) DEFAULT 1,
  `message` text NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `barangay` varchar(100) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `birthday` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `contact_number` varchar(15) NOT NULL,
  `role` varchar(20) DEFAULT 'user',
  `status` enum('active','deactivated') NOT NULL DEFAULT 'active',
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `name`, `email`, `barangay`, `gender`, `birthday`, `password`, `created_at`, `contact_number`, `role`, `status`, `phone`) VALUES
(3, NULL, 'Kraken Qt', 'cjclauven@gmail.com', 'Lingsat', NULL, NULL, '$2y$10$gKG5CTaBYQN/VSP0Nbbta.wSARiddVINJ7uH7xsWwpUSHbRK5hgG6', '2025-06-21 15:20:56', '', 'user', 'active', NULL),
(4, NULL, 'Mcgyver Las-igan', 'macktzy@gmail.com', 'Lesseb', 'Male', 'Dec 8, 1998', '$2y$10$ylH66qsR/nKEYrgUqxhhT.Hpguv217CsET.gzIJVMlGzO34cpwUJ2', '2025-06-21 16:03:16', '', 'user', 'active', NULL),
(5, NULL, 'janea lyn ilar', 'ilarjanealyn@gmail.com', 'Danuman East', 'Female', 'Sep 23, 2004', '$2y$10$R1LflkuY/mFKfbFVdm9znOKXGefrgVNCSTyg/2nFSg6dKd0RJSZ7e', '2025-06-30 09:24:32', '', 'user', 'active', NULL),
(6, NULL, 'Francess Mae Taculog', 'francessmaetaculog2004@gmail.com', 'Laslasong Sur', 'Female', 'May 21, 2004', '$2y$10$kPRTLSXLkEmUs.q7CJJAqulQBFg6QSxmhho9R05KehDsjSPxo/Lgm', '2025-06-30 10:26:08', '', 'user', 'active', NULL),
(7, NULL, 'Macky Rin', 'krakengaming011@gmail.com', 'Lingsat', 'Male', 'Dec 2, 2024', '$2y$10$m11rDa.oyMwjkexmzThf0uThOq6puHRJbfFXM7vsiQBqCrWkifAxi', '2025-07-02 18:14:03', '', 'user', 'active', NULL),
(8, NULL, 'Longemar Tabieros', 'longemartabier1208@gmail.com', 'Nagtupacan', 'Male', 'Jun 23, 2002', '$2y$10$dD7me/qMpwuhRC.bX92pRufAfh5nPxHqE4gHRuWInmVpSR5/Njk0O', '2025-07-03 16:27:53', '', 'user', 'active', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `captains`
--
ALTER TABLE `captains`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `complaints_ibfk_1` (`user_id`);

--
-- Indexes for table `document_requests`
--
ALTER TABLE `document_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `complaint_id` (`complaint_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `captains`
--
ALTER TABLE `captains`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `document_requests`
--
ALTER TABLE `document_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `complaints_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `document_requests`
--
ALTER TABLE `document_requests`
  ADD CONSTRAINT `document_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`complaint_id`) REFERENCES `complaints` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
