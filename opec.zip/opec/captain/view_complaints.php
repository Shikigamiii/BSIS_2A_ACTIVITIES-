<?php
session_start();
include('../includes/db.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/PHPMailer.php';
require '../PHPMailer/SMTP.php';
require '../PHPMailer/Exception.php';

if (!isset($_SESSION['captain_id'])) {
    header("Location: login.php");
    exit();
}

$barangay = $_SESSION['barangay'];
$barangay_clean = str_replace(' ', '_', strtolower($barangay));
$logo_dir = '../assets/img/barangay_logos/';
$extensions = ['png', 'jpg', 'jpeg', 'svg'];
$barangay_logo = null;

foreach ($extensions as $ext) {
    $possible_path = $logo_dir . $barangay_clean . '.' . $ext;
    if (file_exists($possible_path)) {
        $barangay_logo = $possible_path;
        break;
    }
}
if (!$barangay_logo) {
    $barangay_logo = '../assets/img/default_logo.png';
}

$message = "";
$admin_email = 'macktzy@gmail.com';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_notify_complaint_id']) && isset($_POST['notify_status'])) {
    $complaint_id = (int)$_POST['send_notify_complaint_id'];
    $notify_status = $_POST['notify_status'];

    if (!in_array($notify_status, ['In Progress', 'Resolved'])) {
        $message = "<div class='alert alert-danger'>Invalid notification status.</div>";
    } else {
        $check = mysqli_query($conn, "SELECT * FROM complaints WHERE id = $complaint_id AND barangay = '" . mysqli_real_escape_string($conn, $barangay) . "'");
        if ($check && mysqli_num_rows($check) > 0) {
            $complaint = mysqli_fetch_assoc($check);

            $uploaded_file_path = null;
            if ($notify_status === 'Resolved' && isset($_FILES['evidence_image']) && $_FILES['evidence_image']['error'] === UPLOAD_ERR_OK) {
                $upload_dir = '../uploads/evidence/';
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }

                $file_tmp = $_FILES['evidence_image']['tmp_name'];
                $file_name = basename($_FILES['evidence_image']['name']);
                $target_file = $upload_dir . time() . '_' . preg_replace("/[^A-Za-z0-9._-]/", "_", $file_name);

                if (move_uploaded_file($file_tmp, $target_file)) {
                    $uploaded_file_path = $target_file;
                } else {
                    $message = "<div class='alert alert-danger'>Failed to upload evidence image.</div>";
                }
            }

            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'stamariailocossur61@gmail.com';
                $mail->Password = 'jxsu lnnp lcnm erzn';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('your_gmail@gmail.com', 'Barangay OPERAH');
                $mail->addAddress($admin_email);

                $mail->isHTML(true);
                $mail->Subject = "Notification: Report #$complaint_id Status Update - $notify_status";
                $mail->Body = "
                    <h3>Report Notification</h3>
                    <p>The Barangay Captain has notified that Report ID: <strong>$complaint_id</strong> titled <strong>" . htmlspecialchars($complaint['title']) . "</strong> in barangay <strong>" . htmlspecialchars($barangay) . "</strong> is now marked as <strong>$notify_status</strong>.</p>
                    <p>Please check the admin panel for more details.</p>
                ";

                if ($uploaded_file_path) {
                    $mail->addAttachment($uploaded_file_path);
                }

                $mail->send();
                $message = "<div class='alert alert-success'>Notification email sent to admin for report ID $complaint_id as '$notify_status'.</div>";
            } catch (Exception $e) {
                $message = "<div class='alert alert-danger'>Failed to send email notification: {$mail->ErrorInfo}</div>";
            }
        } else {
            $message = "<div class='alert alert-danger'>Complaint not found or unauthorized.</div>";
        }
    }
}

$query = "SELECT c.*, u.name FROM complaints c JOIN users u ON c.user_id = u.id WHERE c.barangay = '" . mysqli_real_escape_string($conn, $barangay) . "' ORDER BY c.created_at DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>View Complaints</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', sans-serif;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 250px;
            background: linear-gradient(135deg, #1c4966, #3a8db7);
            padding-top: 30px;
            color: #fff;
            display: flex;
            flex-direction: column;
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease;
        }

        .sidebar .logo {
            display: block;
            margin: 0 auto 20px;
            width: 80px;
            height: 80px;
            object-fit: contain;
        }

        .sidebar h4 {
            text-align: center;
            margin-bottom: 35px;
            font-weight: bold;
            font-size: 22px;
        }

        .sidebar a {
            display: block;
            padding: 14px 30px;
            color: #e0e7ff;
            font-weight: 600;
            font-size: 16px;
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: background-color 0.25s ease, color 0.25s ease;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: #fff;
            border-left: 4px solid #82c7ff;
        }

        .logout {
            margin-top: auto;
            padding: 25px 0;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }

        .logout a {
            color: #ffb3b3;
            font-weight: 600;
            font-size: 16px;
            text-decoration: none;
        }

        .logout a:hover {
            color: #ff7a7a;
        }

        .main-content {
            margin-left: 250px;
            padding: 40px 30px;
        }

        .container-box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.05);
        }

        .table-responsive {
            display: block;
        }

        .btn-group-horizontal {
            display: flex;
            flex-direction: column;
            gap: 10px;
            align-items: center;
        }

        .toggle-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            background-color: #4ca1af;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            z-index: 1050;
            font-size: 18px;
        }

        .resolved-upload-area input,
        .resolved-upload-area button {
            width: 100%;
        }

        .mobile-card {
            display: none;
        }

        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding: 60px 20px;
            }

            .toggle-btn {
                display: block;
            }

            .btn-group-horizontal {
                flex-direction: column;
            }
        }

        @media (max-width: 768px) {
            .table-responsive {
                display: none;
            }

            .mobile-card {
                display: block;
            }

            .card.complaint {
                margin-bottom: 1rem;
                padding: 1rem;
                background: #fff;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            }
        }
    </style>
</head>
<body>

<button class="toggle-btn" onclick="toggleSidebar()">☰</button>

<div class="sidebar" id="sidebar">
    <img src="<?= htmlspecialchars($barangay_logo); ?>" alt="Barangay Logo" class="logo">
    <h4>Brgy. Captain</h4>
    <a href="captain_dashboard.php">Dashboard</a>
    <a href="view_complaints.php" class="active">View Reports</a>
    <a href="view_requests.php">View Requests</a>
    <div class="logout">
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="main-content" id="mainContent">
    <div class="container-box">
        <h2 class="mb-4">Complaints About Brgy. <?= htmlspecialchars($barangay); ?></h2>
        <?= $message; ?>

        <!-- Desktop Table -->
        <div class="table-responsive">
            <table class="table table-bordered mt-3 align-middle text-center">
                <thead class="table-dark">
                    <tr>
                        <th>Title</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Filed By</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['title']) ?></td>
                        <td><?= htmlspecialchars($row['type']) ?></td>
                        <td><?= htmlspecialchars($row['status']) ?></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['created_at']) ?></td>
                        <td>
                            <div class="btn-group-horizontal">
                                <form method="POST" onsubmit="return confirm('Send IN-PROGRESS notification to admin for this complaint?');">
                                    <input type="hidden" name="send_notify_complaint_id" value="<?= $row['id'] ?>" />
                                    <input type="hidden" name="notify_status" value="In Progress" />
                                    <button type="submit" class="btn btn-sm btn-warning">Send In-Progress</button>
                                </form>
                                <form method="POST" enctype="multipart/form-data" class="resolved-form">
                                    <input type="hidden" name="send_notify_complaint_id" value="<?= $row['id'] ?>" />
                                    <input type="hidden" name="notify_status" value="Resolved" />
                                    <div class="resolved-upload-area" style="display: none;">
                                        <input type="file" name="evidence_image" accept="image/*" class="form-control form-control-sm mb-2" required />
                                        <button type="submit" class="btn btn-sm btn-success">Confirm & Send Resolved</button>
                                    </div>
                                    <button type="button" class="btn btn-sm btn-success toggle-resolved-btn">Send Resolved</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Mobile View Cards -->
        <?php mysqli_data_seek($result, 0); while ($row = mysqli_fetch_assoc($result)): ?>
        <div class="mobile-card card complaint">
            <h5><?= htmlspecialchars($row['title']) ?></h5>
            <p><strong>Type:</strong> <?= htmlspecialchars($row['type']) ?></p>
            <p><strong>Status:</strong> <?= htmlspecialchars($row['status']) ?></p>
            <p><strong>Filed By:</strong> <?= htmlspecialchars($row['name']) ?></p>
            <p><strong>Date:</strong> <?= htmlspecialchars($row['created_at']) ?></p>
            <div class="btn-group-horizontal">
                <form method="POST" onsubmit="return confirm('Send IN-PROGRESS notification to admin for this complaint?');">
                    <input type="hidden" name="send_notify_complaint_id" value="<?= $row['id'] ?>" />
                    <input type="hidden" name="notify_status" value="In Progress" />
                    <button type="submit" class="btn btn-sm btn-warning w-100">Send In-Progress</button>
                </form>
                <form method="POST" enctype="multipart/form-data" class="resolved-form mt-2">
                    <input type="hidden" name="send_notify_complaint_id" value="<?= $row['id'] ?>" />
                    <input type="hidden" name="notify_status" value="Resolved" />
                    <div class="resolved-upload-area" style="display: none;">
                        <input type="file" name="evidence_image" accept="image/*" class="form-control form-control-sm mb-2" required />
                        <button type="submit" class="btn btn-sm btn-success w-100">Confirm & Send Resolved</button>
                    </div>
                    <button type="button" class="btn btn-sm btn-success toggle-resolved-btn w-100">Send Resolved</button>
                </form>
            </div>
        </div>
        <?php endwhile; ?>

    </div>
</div>

<script>
    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('active');
    }

    document.querySelectorAll('.toggle-resolved-btn').forEach(function(btn) {
        btn.addEventListener('click', function () {
            const form = btn.closest('.resolved-form');
            const uploadArea = form.querySelector('.resolved-upload-area');
            uploadArea.style.display = 'block';
            btn.style.display = 'none';
        });
    });

    document.addEventListener('click', function(event) {
        const sidebar = document.getElementById('sidebar');
        const toggleBtn = document.querySelector('.toggle-btn');
        if (!sidebar.contains(event.target) && !toggleBtn.contains(event.target)) {
            sidebar.classList.remove('active');
        }
    });
</script>

</body>
</html>
