<?php
session_start();
include('../includes/db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'captain') {
    header("Location: login.php");
    exit();
}

$captain_barangay = $_SESSION['barangay'];

// Fetch complaints for captain's barangay
$complaints = [];
$result = mysqli_query($conn, "SELECT * FROM complaints WHERE barangay = '$captain_barangay' ORDER BY date_filed DESC");
if ($result) {
    $complaints = mysqli_fetch_all($result, MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Captain's Complaint Inbox</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="bg-light p-4">

<h2 class="mb-4">Reports in Your Barangay (<?= htmlspecialchars($captain_barangay) ?>)</h2>

<?php foreach ($complaints as $complaint): ?>
    <div class="card mb-4 shadow-sm">
        <div class="card-header bg-primary text-white">
            Complaint #<?= $complaint['id'] ?> | <?= htmlspecialchars($complaint['type']) ?>
        </div>
        <div class="card-body">
            <p><strong>Description:</strong> <?= htmlspecialchars($complaint['description']) ?></p>
            <p><strong>Status:</strong> <?= htmlspecialchars($complaint['status']) ?></p>
            <p><strong>Filed on:</strong> <?= htmlspecialchars($complaint['date_filed']) ?></p>

            <!-- Fetch messages related to this complaint -->
            <h5>Messages:</h5>
            <div class="border p-3 bg-white" style="max-height: 200px; overflow-y: auto;">
                <?php
                $cid = $complaint['id'];
                $msgs = mysqli_query($conn, "SELECT * FROM messages WHERE complaint_id = $cid ORDER BY timestamp ASC");
                if (mysqli_num_rows($msgs) > 0):
                    while ($m = mysqli_fetch_assoc($msgs)):
                ?>
                    <div class="mb-2">
                        <strong><?= ucfirst($m['sender_role']) ?>:</strong>
                        <?= htmlspecialchars($m['message']) ?><br>
                        <small class="text-muted"><?= $m['timestamp'] ?></small>
                    </div>
                <?php endwhile; else: ?>
                    <p class="text-muted">No messages yet.</p>
                <?php endif; ?>
            </div>

            <!-- Reply and Mark as Resolved -->
            <form action="../actions/send_message.php" method="POST" class="mt-3">
                <input type="hidden" name="complaint_id" value="<?= $complaint['id'] ?>">
                <input type="hidden" name="sender_role" value="captain">
                <div class="input-group">
                    <input type="text" name="message" class="form-control" placeholder="Reply to Admin..." required />
                    <button class="btn btn-success" type="submit">Send</button>
                </div>
            </form>

            <?php if ($complaint['status'] !== 'Resolved'): ?>
                <form action="../actions/mark_resolved.php" method="POST" class="mt-2">
                    <input type="hidden" name="complaint_id" value="<?= $complaint['id'] ?>">
                    <button class="btn btn-danger btn-sm" type="submit">Mark as Resolved</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; ?>

</body>
</html>
