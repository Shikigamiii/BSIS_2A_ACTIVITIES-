<?php
session_start();
include('../includes/db.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/PHPMailer.php';
require '../PHPMailer/SMTP.php';
require '../PHPMailer/Exception.php';

// Check if user is authenticated
if (!isset($_SESSION['captain_id'])) {
    header("Location: ../login.php");
    exit();
}

// Validate POST data
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['request_id'], $_POST['status'])) {
    $request_id = mysqli_real_escape_string($conn, $_POST['request_id']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    // Optional fields if status is "Done"
    $user_email = isset($_POST['email']) ? $_POST['email'] : '';
    $user_name = isset($_POST['name']) ? $_POST['name'] : '';
    $document = isset($_POST['document']) ? $_POST['document'] : '';

    // Update status in the database
    $update = mysqli_query($conn, "UPDATE document_requests SET status='$status' WHERE id='$request_id'");

    if ($update && $status === 'Done') {
        // Send email if status is Done
        $mail = new PHPMailer(true);

        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'macktzy@gmail.com'; // Replace with your Gmail
            $mail->Password   = 'xbpt xlmy aakp lpbm'; // App password, not your Gmail password
            $mail->SMTPSecure = 'tls';
            $mail->Port       = 587;

            // Recipients
            $mail->setFrom('youremail@gmail.com', 'OPERAH System');
            $mail->addAddress($user_email, $user_name);

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Document Request Marked as Done';
            $mail->Body    = "
                <p>Dear <strong>$user_name</strong>,</p>
                <p>Your document request for <strong>$document</strong> has been marked as <strong>Done</strong>.</p>
                <p>You may now visit your barangay hall to claim it.</p>
                <br>
                <p>Thank you,<br>OPERAH System</p>
            ";

            $mail->send();
            $_SESSION['success'] = "Status updated and email sent!";
        } catch (Exception $e) {
            $_SESSION['error'] = "Status updated, but email could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } elseif ($update) {
        $_SESSION['success'] = "Status updated successfully!";
    } else {
        $_SESSION['error'] = "Failed to update status.";
    }
} else {
    $_SESSION['error'] = "Invalid request.";
}

header("Location: view_requests.php");
exit();
?>
