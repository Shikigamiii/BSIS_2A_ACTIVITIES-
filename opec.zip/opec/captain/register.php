<?php
session_start();
include('../includes/db.php');

$error = '';
$success = '';

// Complete list of Barangays in Sta. Maria
$barangay_list = [
    "Ag-agrao", "Ampuagan", "Baballasioan", "Baliw Daya (San Gelacio)", "Baliw Laud (Simbuok)",
    "Bia-o", "Butir", "Cabaroan", "Danuman East", "Danuman West", "Dunglayan", "Gusing", "Langaoan",
    "Laslasong Norte", "Laslasong Sur", "Laslasong West", "Lesseb", "Lingsat", "Lubong",
    "Maynganay Norte", "Maynganay Sur (San Ignacio)", "Nagsayaoan", "Nagtupacan", "Nalvo",
    "Pacang", "Penned", "Poblacion Norte (San Gregorio)", "Poblacion Sur (San Francisco)",
    "Silag", "Sumagui", "Suso", "Tangaoan", "Tinaan"
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $barangay = trim($_POST['barangay']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($name) || empty($email) || empty($barangay) || empty($password) || empty($confirm_password)) {
        $error = "Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM captains WHERE email = ? LIMIT 1");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Email is already registered.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert_stmt = $conn->prepare("INSERT INTO captains (name, email, barangay, password) VALUES (?, ?, ?, ?)");
            $insert_stmt->bind_param('ssss', $name, $email, $barangay, $hashed_password);
            if ($insert_stmt->execute()) {
                $success = "Registration successful! You can now <a href='login.php'>login</a>.";
            } else {
                $error = "Registration failed. Please try again.";
            }
            $insert_stmt->close();
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Register - OPERAH Captain</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 1rem;
        }
        .register-card {
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            padding: 2rem;
            width: 100%;
            max-width: 500px;
            text-align: center;
        }
        .register-logo img {
            height: 70px;
            margin-bottom: 1rem;
        }
        .register-title {
            font-size: 1.5rem;
            font-weight: bold;
        }
        .register-subtitle {
            font-size: 0.95rem;
            color: #6c757d;
            margin-bottom: 1.5rem;
        }
        .btn-green {
            background-color: #28a745;
            border: none;
        }
        .btn-green:hover {
            background-color: #218838;
        }
        .login-link {
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

<div class="register-card">
    <div class="register-logo">
        <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo">
    </div>
    <div class="register-title">Municipality of Sta. Maria</div>
    <div class="register-subtitle">Register your OPERAH Captain account</div>

    <?php if ($error): ?>
        <div class="alert alert-danger text-start"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success text-start"><?= $success ?></div>
    <?php endif; ?>

    <form method="POST" novalidate>
        <div class="mb-3 text-start">
            <label for="name" class="form-label">Full Name</label>
            <input type="text" id="name" name="name" class="form-control" required
                   value="<?= isset($_POST['name']) ? htmlspecialchars($_POST['name']) : '' ?>">
        </div>

        <div class="mb-3 text-start">
            <label for="email" class="form-label">Email</label>
            <input type="email" id="email" name="email" class="form-control" required
                   value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
        </div>

        <div class="mb-3 text-start">
            <label for="barangay" class="form-label">Barangay</label>
            <select id="barangay" name="barangay" class="form-select" required>
                <option value="">Select Barangay</option>
                <?php foreach ($barangay_list as $b): ?>
                    <option value="<?= htmlspecialchars($b) ?>"
                        <?= (isset($_POST['barangay']) && $_POST['barangay'] === $b) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($b) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3 text-start">
            <label for="password" class="form-label">Password</label>
            <input type="password" id="password" name="password" class="form-control" required>
        </div>

        <div class="mb-3 text-start">
            <label for="confirm_password" class="form-label">Confirm Password</label>
            <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-green w-100 fw-semibold">Register</button>
    </form>

    <div class="mt-3 login-link">
        Already have an account? <a href="login.php">Login here</a>
    </div>
</div>

</body>
</html>
