<?php
session_start();
include('../includes/db.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $stmt = $conn->prepare("SELECT id, name, barangay, password FROM captains WHERE email = ? LIMIT 1");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['captain_id'] = $user['id'];
            $_SESSION['captain_name'] = $user['name'];
            $_SESSION['barangay'] = $user['barangay'];
            header('Location: captain_dashboard.php');
            exit();
        } else {
            $error = "Invalid email or password.";
        }
        $stmt->close();
    } else {
        $error = "Please enter a valid email address.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Login - OPERAH Captain</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background: linear-gradient(135deg, #e9f5ec, #ffffff);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }
        .login-card {
            background: #fff;
            border-radius: 1rem;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            padding: 2rem;
            width: 100%;
            max-width: 420px;
        }
        .login-logo img {
            height: 70px;
        }
        .login-title {
            font-size: 1.6rem;
            font-weight: 700;
        }
        .login-subtitle {
            font-size: 0.95rem;
            color: #6c757d;
        }
        .btn-green {
            background-color: #28a745;
            border: none;
        }
        .btn-green:hover {
            background-color: #218838;
        }
        .register-link a {
            color: #28a745;
            text-decoration: none;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="login-card mx-auto text-center">
        <div class="login-logo mb-3">
            <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo" class="img-fluid">
        </div>
        <div class="login-title">Barangay Official</div>
        <div class="login-subtitle mb-4">Login to your OPERAH account</div>

        <?php if ($error): ?>
            <div class="alert alert-danger text-start"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" class="text-start" novalidate>
            <div class="mb-3">
                <label for="email" class="form-label">Email Address</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    class="form-control"
                    required
                    value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>"
                    autofocus
                >
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    class="form-control"
                    required
                >
            </div>

            <button type="submit" class="btn btn-green w-100 fw-semibold">Log In</button>
        </form>

        <div class="mt-3 register-link text-center">
            Don’t have an account? <a href="register.php">Create one</a>
        </div>
    </div>
</div>

</body>
</html>
