<?php
session_start();
include('../includes/db.php');

if (!isset($_SESSION['captain_id'])) {
    header("Location: login.php");
    exit();
}

$barangay = trim($_SESSION['barangay']);
$barangay_clean = str_replace(' ', '_', strtolower($barangay));

$logo_dir = '../assets/img/barangay_logos/';
$extensions = ['png', 'jpg', 'jpeg', 'svg'];
$barangay_logo = null;
foreach ($extensions as $ext) {
    $possible_path = $logo_dir . $barangay_clean . '.' . $ext;
    if (file_exists($possible_path)) {
        $barangay_logo = $possible_path;
        break;
    }
}
if (!$barangay_logo) {
    $barangay_logo = '../assets/img/default_logo.png';
}

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM complaints WHERE TRIM(LOWER(barangay)) = LOWER(?)");
$stmt->bind_param("s", $barangay);
$stmt->execute();
$result = $stmt->get_result();
$complaints_count = $result->fetch_assoc()['total'] ?? 0;
$stmt->close();

$stmt2 = $conn->prepare("
    SELECT COUNT(*) as total 
    FROM document_requests dr
    JOIN users u ON dr.user_id = u.id 
    WHERE TRIM(LOWER(u.barangay)) = LOWER(?)
");
$stmt2->bind_param("s", $barangay);
$stmt2->execute();
$result2 = $stmt2->get_result();
$docs_count = $result2->fetch_assoc()['total'] ?? 0;
$stmt2->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Captain Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', sans-serif;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 250px;
            background: linear-gradient(135deg, #1c4966, #3a8db7);
            padding-top: 30px;
            color: #fff;
            display: flex;
            flex-direction: column;
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease-in-out;
        }

        .sidebar .logo {
            display: block;
            margin: 0 auto 20px;
            width: 80px;
            height: auto;
            max-height: 80px;
            object-fit: contain;
            filter: drop-shadow(0 0 3px rgba(255, 255, 255, 0.5));
        }

        .sidebar h4 {
            text-align: center;
            margin-bottom: 35px;
            font-weight: bold;
            font-size: 22px;
        }

        .sidebar a {
            display: block;
            padding: 14px 30px;
            color: #e0e7ff;
            font-weight: 600;
            font-size: 16px;
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: background-color 0.25s ease, color 0.25s ease;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: #fff;
            border-left: 4px solid #82c7ff;
        }

        .logout {
            margin-top: auto;
            padding: 25px 0;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }

        .logout a {
            color: #ffb3b3;
            font-weight: 600;
            font-size: 16px;
            text-decoration: none;
        }

        .logout a:hover {
            color: #ff7a7a;
        }

        .main-content {
            margin-left: 250px;
            padding: 40px 30px;
        }

        .toggle-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            background-color: #4ca1af;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            z-index: 1050;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding-top: 70px;
                padding-left: 20px;
                padding-right: 20px;
            }

            .toggle-btn {
                display: block;
            }
        }

        .card-title {
            font-size: 1.1rem;
        }

        .card-text {
            font-size: 2rem;
            font-weight: bold;
        }
    </style>
</head>
<body>

<button class="toggle-btn" onclick="toggleSidebar()">☰</button>

<div class="sidebar" id="sidebar">
    <img src="<?= htmlspecialchars($barangay_logo); ?>" alt="Brgy Logo" class="logo">
    <h4>Brgy. Captain</h4>
    <a href="captain_dashboard.php" class="active">Dashboard</a>
    <a href="view_complaints.php">View Reports</a>
    <a href="view_requests.php">View Requests</a>
    <div class="logout">
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="main-content">
    <h2 class="mb-4 text-center text-md-start">Welcome, Brgy. <?= htmlspecialchars($barangay); ?> Official</h2>

    <div class="row g-4">
        <div class="col-12 col-md-6">
            <div class="card text-white bg-primary h-100">
                <div class="card-body">
                    <h5 class="card-title">Total Reports Against Your Barangay</h5>
                    <p class="card-text"><?= $complaints_count; ?></p>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6">
            <div class="card text-white bg-success h-100">
                <div class="card-body">
                    <h5 class="card-title">Total Document Requests From Your Barangay</h5>
                    <p class="card-text"><?= $docs_count; ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('active');
}
</script>

</body>
</html>
