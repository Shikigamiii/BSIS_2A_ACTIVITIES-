<?php
session_start();
if (!isset($_SESSION['captain_id'])) {
    header("Location: ../login.php");
    exit();
}

include('../includes/db.php');
$barangay = $_SESSION['barangay'];

$barangay_clean = str_replace(' ', '_', strtolower($barangay));
$logo_dir = '../assets/img/barangay_logos/';
$extensions = ['png', 'jpg', 'jpeg', 'svg'];
$barangay_logo = null;

foreach ($extensions as $ext) {
    $possible_path = $logo_dir . $barangay_clean . '.' . $ext;
    if (file_exists($possible_path)) {
        $barangay_logo = $possible_path;
        break;
    }
}

if (!$barangay_logo) {
    $barangay_logo = '../assets/img/default_logo.png';
}

$query = "SELECT dr.*, u.name AS full_name, u.email 
          FROM document_requests dr 
          JOIN users u ON dr.user_id = u.id 
          WHERE u.barangay = '" . mysqli_real_escape_string($conn, $barangay) . "'
          ORDER BY dr.date_requested DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en" >
<head>
    <meta charset="UTF-8" />
    <title>Captain - Document Requests</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        /* Reset */
        *, *::before, *::after {
            box-sizing: border-box;
        }
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            min-height: 100vh;
            color: #212529;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 250px;
            background: linear-gradient(135deg, #1c4966, #3a8db7);
            padding-top: 30px;
            color: #fff;
            display: flex;
            flex-direction: column;
            z-index: 1100;
            transition: transform 0.3s cubic-bezier(0.4,0,0.2,1);
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.15);
        }

        .sidebar .logo {
            display: block;
            margin: 0 auto 20px;
            width: 80px;
            height: 80px;
            object-fit: contain;
            filter: drop-shadow(0 0 3px rgba(255, 255, 255, 0.5));
            user-select: none;
        }

        .sidebar h4 {
            text-align: center;
            margin-bottom: 35px;
            font-weight: 700;
            font-size: 22px;
            letter-spacing: 0.05em;
            user-select: none;
        }

        .sidebar a {
            display: block;
            padding: 14px 30px;
            color: #e0e7ff;
            font-weight: 600;
            font-size: 16px;
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: background-color 0.25s ease, color 0.25s ease, border-color 0.25s ease;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: #fff;
            border-left: 4px solid #82c7ff;
        }

        .logout {
            margin-top: auto;
            padding: 25px 0;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }

        .logout a {
            color: #ffb3b3;
            font-weight: 600;
            font-size: 16px;
            text-decoration: none;
        }

        .logout a:hover,
        .logout a:focus {
            color: #ff7a7a;
            outline: none;
            text-decoration: underline;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            padding: 40px 30px;
            transition: margin-left 0.3s ease;
            min-height: 100vh;
        }

        .container-box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.05);
        }

        /* Status badges */
        .badge-pending { background-color: #ffc107; color: #000; }
        .badge-done { background-color: #28a745; }
        .badge-cancelled { background-color: #dc3545; }

        /* Buttons container */
        .action-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            justify-content: center;
        }
        .action-buttons form, .action-buttons a {
            flex: 1 1 auto;
            min-width: 100px;
            margin: 0;
        }
        .action-buttons button, .action-buttons a.btn {
            width: 100%;
        }

        /* Responsive */

        /* Sidebar toggle button */
        .toggle-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            background-color: #4ca1af;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            z-index: 1150;
            cursor: pointer;
            font-size: 20px;
            line-height: 1;
            user-select: none;
            box-shadow: 0 3px 6px rgb(0 0 0 / 0.16);
            transition: background-color 0.3s ease;
        }
        .toggle-btn:hover,
        .toggle-btn:focus {
            background-color: #37838a;
            outline: none;
        }

        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding: 20px 15px 40px;
            }

            .toggle-btn {
                display: block;
            }

            .action-buttons {
                flex-direction: column;
                gap: 10px;
            }

            /* Responsive table: hide headers and show labels on td */
            .table thead {
                display: none;
            }

            .table tbody tr {
                margin-bottom: 1rem;
                display: block;
                border: 1px solid #dee2e6;
                border-radius: 8px;
                padding: 15px 20px;
                background-color: #fff;
                box-shadow: 0 2px 8px rgb(0 0 0 / 0.05);
            }

            .table tbody tr td {
                display: block;
                text-align: left;
                padding-left: 50%;
                position: relative;
                border: none;
                border-bottom: 1px solid #dee2e6;
                font-size: 15px;
            }

            .table tbody tr td:last-child {
                border-bottom: none;
            }

            .table tbody tr td::before {
                content: attr(data-label);
                position: absolute;
                left: 20px;
                top: 50%;
                transform: translateY(-50%);
                font-weight: 700;
                text-transform: uppercase;
                font-size: 12px;
                color: #6c757d;
                white-space: nowrap;
            }
        }

        /* Smaller mobile adjustments */
        @media (max-width: 576px) {
            .container-box {
                padding: 20px;
            }
            .sidebar h4 {
                font-size: 18px;
                margin-bottom: 25px;
            }
            .sidebar a {
                font-size: 14px;
                padding: 12px 20px;
            }
            .main-content {
                padding: 15px 10px 30px;
            }
            .action-buttons button,
            .action-buttons a.btn {
                font-size: 14px;
                padding: 8px 12px;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar Toggle Button -->
<button class="toggle-btn" aria-label="Toggle Sidebar" aria-expanded="false" aria-controls="sidebar" id="sidebarToggle">☰</button>

<!-- Sidebar -->
<nav class="sidebar" id="sidebar" role="navigation" aria-label="Main sidebar navigation">
    <img src="<?= htmlspecialchars($barangay_logo); ?>" alt="Barangay Logo" class="logo" />
    <h4>Brgy. Captain</h4>
    <a href="captain_dashboard.php">Dashboard</a>
    <a href="view_complaints.php">View Reports</a>
    <a href="view_requests.php" class="active" aria-current="page">View Requests</a>
    <div class="logout">
        <a href="logout.php">Logout</a>
    </div>
</nav>

<!-- Main Content -->
<main class="main-content" role="main" tabindex="-1">
    <div class="container-box">
        <h2 class="mb-4">Document Requests - Brgy. <?= htmlspecialchars($barangay) ?></h2>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="table-responsive" role="region" aria-label="Document requests table">
                <table class="table table-bordered table-hover align-middle text-center">
                    <thead class="table-light">
                        <tr>
                            <th scope="col">Requested By</th>
                            <th scope="col">Document</th>
                            <th scope="col">Purpose</th>
                            <th scope="col">Pickup Date</th>
                            <th scope="col">Status</th>
                            <th scope="col">Requested On</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td data-label="Requested By">
                                    <?= htmlspecialchars($row['full_name']) ?><br />
                                    <small class="text-muted"><?= htmlspecialchars($row['email']) ?></small>
                                </td>
                                <td data-label="Document"><?= htmlspecialchars($row['document_type']) ?></td>
                                <td data-label="Purpose"><?= htmlspecialchars($row['purpose']) ?></td>
                                <td data-label="Pickup Date"><?= htmlspecialchars($row['pickup_date']) ?></td>
                                <td data-label="Status" aria-live="polite" aria-atomic="true">
                                    <?php
                                        $status = $row['status'];
                                        if ($status == 'Pending') {
                                            echo '<span class="badge badge-pending">Pending</span>';
                                        } elseif ($status == 'Done') {
                                            echo '<span class="badge badge-done">Done</span>';
                                        } elseif ($status == 'Cancelled') {
                                            echo '<span class="badge badge-cancelled">Cancelled</span>';
                                        } else {
                                            echo '<span class="badge bg-secondary">' . htmlspecialchars($status) . '</span>';
                                        }
                                    ?>
                                </td>
                                <td data-label="Requested On"><?= date("M d, Y h:i A", strtotime($row['date_requested'])) ?></td>
                                <td data-label="Action">
                                    <div class="action-buttons">
                                        <?php if ($status == 'Pending'): ?>
                                            <form method="POST" action="captain_update_request_status.php" style="margin:0;">
                                                <input type="hidden" name="request_id" value="<?= $row['id'] ?>" />
                                                <input type="hidden" name="email" value="<?= htmlspecialchars($row['email']) ?>" />
                                                <input type="hidden" name="name" value="<?= htmlspecialchars($row['full_name']) ?>" />
                                                <input type="hidden" name="document" value="<?= htmlspecialchars($row['document_type']) ?>" />
                                                <button name="status" value="Done" class="btn btn-sm btn-success" aria-label="Mark request as done">Done</button>
                                            </form>
                                            <form method="POST" action="captain_update_request_status.php" style="margin:0;">
                                                <input type="hidden" name="request_id" value="<?= $row['id'] ?>" />
                                                <button name="status" value="Cancelled" class="btn btn-sm btn-danger" aria-label="Cancel request">Cancel</button>
                                            </form>
                                        <?php elseif ($status == 'Done'): ?>
                                            <a href="print_document.php?id=<?= $row['id'] ?>" target="_blank" class="btn btn-sm btn-primary" aria-label="Print document request">Print</a>
                                        <?php else: ?>
                                            <em>No Action</em>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted">No document requests found for your barangay.</p>
        <?php endif; ?>
    </div>
</main>

<script>
    const sidebar = document.getElementById('sidebar');
    const toggleBtn = document.getElementById('sidebarToggle');
    const sidebarLinks = sidebar.querySelectorAll('a');

    function toggleSidebar() {
        sidebar.classList.toggle('active');
        // Update aria-expanded for accessibility
        const expanded = sidebar.classList.contains('active');
        toggleBtn.setAttribute('aria-expanded', expanded);
    }

    toggleBtn.addEventListener('click', toggleSidebar);

    // Close sidebar on link click (mobile only)
    sidebarLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (window.innerWidth <= 992 && sidebar.classList.contains('active')) {
                toggleSidebar();
            }
        });
    });

    // Optional: Close sidebar when clicking outside on mobile
    document.addEventListener('click', (e) => {
        if (window.innerWidth <= 992) {
            if (!sidebar.contains(e.target) && !toggleBtn.contains(e.target) && sidebar.classList.contains('active')) {
                toggleSidebar();
            }
        }
    });

    // Keyboard accessibility: focus main content when sidebar toggled closed
    sidebar.addEventListener('transitionend', () => {
        if (!sidebar.classList.contains('active')) {
            document.querySelector('.main-content').focus();
        }
    });
</script>

</body>
</html>
