<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include('../includes/db.php');

if (!isset($_GET['id'])) {
    die("Missing request ID.");
}

$request_id = intval($_GET['id']);
$query = "SELECT dr.*, u.name AS full_name, u.email
          FROM document_requests dr
          JOIN users u ON dr.user_id = u.id
          WHERE dr.id = $request_id";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 0) {
    die("Invalid request ID.");
}

$row = mysqli_fetch_assoc($result);
$barangay = $row['barangay']; // from document_requests table
?>

<!DOCTYPE html>
<html>
<head>
    <title>Print Document Request</title>
    <style>
        body {
            font-family: 'Times New Roman', serif;
            padding: 60px;
            color: #000;
            line-height: 1.6;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
            position: relative;
        }

        .header img {
            height: 80px;
            position: absolute;
            top: 0;
        }

        .logo-left {
            left: 0;
        }

        .logo-right {
            right: 0;
        }

        .doc-title {
            text-align: center;
            font-size: 20px;
            font-weight: bold;
            margin: 30px 0 20px;
            text-decoration: underline;
        }

        .content {
            text-align: justify;
        }

        .footer {
            margin-top: 60px;
            text-align: left;
        }

        .signatory {
            margin-top: 50px;
            text-align: right;
        }

        .btn-print {
            display: block;
            margin: 30px auto;
            padding: 10px 25px;
            font-size: 16px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        @media print {
            .btn-print {
                display: none;
            }
        }

        .watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            opacity: 0.08;
            z-index: -1;
            font-size: 80px;
            white-space: nowrap;
            pointer-events: none;
        }
    </style>
</head>
<body>

<div class="header">
    <img src="../assets/img/Sta.Maria.png" alt="Logo Left" class="logo-left">
    <img src="../assets/img/Ilocos.png" alt="Logo Right" class="logo-right">
    <h4>Republic of the Philippines</h4>
    <h5>Province of Ilocos Sur</h5>
    <h5>Municipality of Sta. Maria</h5>
    <h5><strong>Barangay <?= htmlspecialchars($barangay) ?></strong></h5>
    <h4><strong>OFFICE OF THE PUNONG BARANGAY</strong></h4>
</div>

<div class="doc-title">
    <?= strtoupper(htmlspecialchars($row['document_type'])) ?>
</div>

<div class="content">
    <p><strong>TO WHOM IT MAY CONCERN:</strong></p>
    <p>
        This is to certify that <strong><?= htmlspecialchars($row['full_name']) ?></strong>, a resident of Barangay 
        <strong><?= htmlspecialchars($barangay) ?></strong>, with email address 
        <strong><?= htmlspecialchars($row['email']) ?></strong>, has formally requested for the document stated above.
    </p>
    <p>
        The document is being issued for the purpose of <strong><?= htmlspecialchars($row['purpose']) ?></strong> 
        and is scheduled for pickup on <strong><?= htmlspecialchars($row['pickup_date']) ?></strong>.
    </p>
    <p>
        This certification is issued upon the request of the above-named person for whatever legal purpose it may serve.
    </p>
</div>

<div class="footer">
    <p>Issued this <?= date("jS \of F Y", strtotime($row['date_requested'])) ?> at Barangay <?= htmlspecialchars($barangay) ?>, Sta. Maria, Ilocos Sur.</p>

    <div class="signatory">
        <p>__________________________</p>
        <p>Punong Barangay</p>
    </div>
</div>

<div class="watermark">Barangay <?= htmlspecialchars($barangay) ?></div>

<div style="text-align: center;">
    <button onclick="window.print()" class="btn-print">🖨️ Print Document</button>
    <p>Thank you for using the OPERAH System.</p>
</div>

</body>
</html>
