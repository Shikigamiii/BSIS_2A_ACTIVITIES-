<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();
include('../includes/db.php');

// Include PHPMailer classes
require '../PHPMailer/PHPMailer.php';
require '../PHPMailer/SMTP.php';
require '../PHPMailer/Exception.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $request_id = intval($_POST['request_id']);
    $new_status = $_POST['status'];

    // Update the status of the document request
    $update_query = "UPDATE document_requests SET status = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt, 'si', $new_status, $request_id);
    mysqli_stmt_execute($stmt);

    // Fetch the user email and name who made the request
    $fetch_query = "SELECT u.email, u.name FROM document_requests dr 
                    JOIN users u ON dr.user_id = u.id 
                    WHERE dr.id = ?";
    $stmt2 = mysqli_prepare($conn, $fetch_query);
    mysqli_stmt_bind_param($stmt2, 'i', $request_id);
    mysqli_stmt_execute($stmt2);
    $result = mysqli_stmt_get_result($stmt2);
    $user = mysqli_fetch_assoc($result);

    // If status is changed to 'Done', send email notification
    if ($new_status === 'Done' && $user) {
        $mail = new PHPMailer(true);

        try {
            // SMTP configuration
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'macktzy@gmail.com'; // Your Gmail address
            $mail->Password = 'xbpt xlmy aakp lpbm';   // Your Gmail App Password
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('yourgmail@gmail.com', ' OPERAH System');
            $mail->addAddress($user['email'], $user['name']);

            $mail->isHTML(true);
            $mail->Subject = 'Your Document Request is Completed - OPERAH';
            $mail->Body    = "Hello <strong>{$user['name']}</strong>,<br><br>
                              Your document request (ID: <strong>$request_id</strong>) has been marked as <strong>Done</strong>.<br><br>
                              You may now claim your document at the Barangay Office.<br><br>
                              Regards,<br>OPERAH System";

            $mail->send();
        } catch (Exception $e) {
            error_log("Email not sent: {$mail->ErrorInfo}");
        }
    }

    header("Location: admin_view_requests.php");
    exit();
}
