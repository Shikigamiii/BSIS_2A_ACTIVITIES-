<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include('../includes/db.php');

$query = "SELECT dr.*, u.name AS full_name, u.email 
          FROM document_requests dr 
          JOIN users u ON dr.user_id = u.id 
          ORDER BY dr.date_requested DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Document Requests</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', sans-serif;
        }

        .sidebar {
    position: fixed;
    top: 0;
    left: 0;
    height: 100vh;
    width: 250px;
    background: linear-gradient(135deg, #1c4966, #3a8db7);
    padding-top: 30px;
    color: #fff;
    display: flex;
    flex-direction: column;
    z-index: 1000;
    transition: transform 0.3s ease-in-out;
    box-shadow: 2px 0 10px rgba(0, 0, 0, 0.15);
}
.sidebar .logo {
    display: block;
    margin: 0 auto 20px;
    width: 80px;
    height: 80px;
    object-fit: contain;
    filter: drop-shadow(0 0 3px rgba(255, 255, 255, 0.5));
}
.sidebar h4 {
    text-align: center;
    margin-bottom: 35px;
    font-weight: bold;
    font-size: 22px;
    letter-spacing: 1px;
    text-shadow: 0 1px 2px rgba(0,0,0,0.3);
}
.sidebar a {
    display: block;
    padding: 14px 30px;
    color: #e0e7ff;
    font-weight: 600;
    font-size: 16px;
    text-decoration: none;
    border-left: 4px solid transparent;
    transition: background-color 0.25s ease, color 0.25s ease;
}
.sidebar a:hover,
.sidebar a.active {
    background-color: rgba(255, 255, 255, 0.15);
    color: #fff;
    border-left: 4px solid #82c7ff;
}
.logout {
    margin-top: auto;
    padding: 25px 0;
    text-align: center;
    border-top: 1px solid rgba(255, 255, 255, 0.2);
}
.logout a {
    color: #ffb3b3;
    font-weight: 600;
    font-size: 16px;
    text-decoration: none;
}
.logout a:hover {
    color: #ff7a7a;
}


        .main-content {
            margin-left: 250px;
            padding: 40px 30px;
            transition: margin-left 0.3s ease-in-out;
        }

        .container-box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.05);
        }

        .badge-pending { background-color: #ffc107; color: #000; }
        .badge-done { background-color: #28a745; }
        .badge-cancelled { background-color: #dc3545; }

        .toggle-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            background-color: #4ca1af;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            z-index: 1050;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                width: 100%;
                height: auto;
                padding-bottom: 30px;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding-top: 70px;
            }

            .toggle-btn {
                display: block;
            }

            .table-responsive {
                overflow-x: auto;
            }

            .d-flex.gap-1.flex-wrap {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar Toggle Button -->
<button class="toggle-btn" onclick="toggleSidebar()">☰</button>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo" class="logo">
    <h4>OPERAH System</h4>
    <a href="dashboard.php">Dashboard</a>
    <a href="view_complaints.php">View Complaints</a>
    <a href="admin_view_requests.php" class="active">View Document Requests</a>
    <a href="update_status.php">Update Status</a>
    <a href="users.php">Manage Users</a>
    <div class="logout">
        <a href="logout.php">Logout</a>
    </div>
</div>


<!-- Main Content -->
<div class="main-content" id="mainContent">
    <div class="container-box">
           <h2 class="mb-4"><span style="font-weight: 700; color: #1c4966; padding: 6px 12px; border-radius: 6px;">Document Request Management</span></h2>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle text-center">
                    <thead class="table-light">
                        <tr>
                            <th>Requested By</th>
                            <th>Barangay</th>
                            <th>Document</th>
                            <th>Purpose</th>
                            <th>Pickup Date</th>
                            <th>Status</th>
                            <th>Requested On</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td>
                                    <?= htmlspecialchars($row['full_name']) ?><br>
                                    <small class="text-muted"><?= htmlspecialchars($row['email']) ?></small>
                                </td>
                                <td><?= htmlspecialchars($row['barangay']) ?></td>
                                <td><?= htmlspecialchars($row['document_type']) ?></td>
                                <td><?= htmlspecialchars($row['purpose']) ?></td>
                                <td><?= htmlspecialchars($row['pickup_date']) ?></td>
                                <td>
                                    <?php
                                        $status = $row['status'];
                                        if ($status == 'Pending') {
                                            echo '<span class="badge badge-pending">Pending</span>';
                                        } elseif ($status == 'Done') {
                                            echo '<span class="badge badge-done">Done</span>';
                                        } elseif ($status == 'Cancelled') {
                                            echo '<span class="badge badge-cancelled">Cancelled</span>';
                                        } else {
                                            echo '<span class="badge bg-secondary">' . htmlspecialchars($status) . '</span>';
                                        }
                                    ?>
                                </td>
                                <td><?= date("M d, Y h:i A", strtotime($row['date_requested'])) ?></td>
                                <td>
                                    <?php if ($status == 'Pending'): ?>
                                        <form method="POST" action="update_request_status.php" class="d-flex gap-1 flex-wrap justify-content-center">
                                            <input type="hidden" name="request_id" value="<?= $row['id'] ?>">
                                            <input type="hidden" name="email" value="<?= $row['email'] ?>">
                                            <input type="hidden" name="name" value="<?= $row['full_name'] ?>">
                                            <input type="hidden" name="document" value="<?= $row['document_type'] ?>">
                                            <button name="status" value="Done" class="btn btn-sm btn-success">Mark as Done</button>
                                            <button name="status" value="Cancelled" class="btn btn-sm btn-danger">Cancel</button>
                                        </form>
                                    <?php elseif ($status == 'Done'): ?>
                                        <a href="print_document.php?id=<?= $row['id'] ?>" target="_blank" class="btn btn-sm btn-primary">Print</a>
                                    <?php else: ?>
                                        <em>No action needed</em>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted">No document requests found.</p>
        <?php endif; ?>
    </div>
</div>

<script>
    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('active');
    }
</script>

</body>
</html>
