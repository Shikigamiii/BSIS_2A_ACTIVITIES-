
OPEC - Online Platform Efficient Complaint Handling System
==========================================================

SETUP INSTRUCTIONS:
1. Import the database from sql/opec_db.sql using phpMyAdmin or MySQL.
2. Edit includes/db.php with your database credentials.
3. Place the PHPMailer library files inside the PHPMailer/ directory.
4. Run index.php to start the application.

USER FEATURES:
- Register and Login
- Submit Complaints
- View Status and History
- Email Notification (requires PHPMailer setup)

ADMIN FEATURES:
- Admin Login
- View and Manage Complaints
- Update Status (sends email to user)
- Dashboard with Charts
- Manage User Accounts
