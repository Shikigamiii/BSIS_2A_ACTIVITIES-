<?php
$conn = mysqli_connect('localhost', 'root', '', 'opec_db');
?>