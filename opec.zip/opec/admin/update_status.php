<?php
session_start();
include('../includes/db.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../PHPMailer/PHPMailer.php';
require '../PHPMailer/SMTP.php';
require '../PHPMailer/Exception.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$message = "";

// Enhanced: Track if already sent to captain
$update_forwarded_flag = function($complaint_id) use ($conn) {
    mysqli_query($conn, "UPDATE complaints SET forwarded_to_captain = 1 WHERE id = $complaint_id");
};

// Enhanced: Handle complaint status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['complaint_id'], $_POST['new_status'], $_POST['remarks'])) {
    $complaint_id = (int) $_POST['complaint_id'];
    $new_status = trim($_POST['new_status']);
    $remarks = trim($_POST['remarks']);

    $status_check = mysqli_query($conn, "SELECT status FROM complaints WHERE id = $complaint_id");
    $status_row = mysqli_fetch_assoc($status_check);

    if ($status_row && $status_row['status'] === 'Resolved' && $new_status !== 'Resolved') {
        $message = "<div class='alert alert-warning'>This complaint is already resolved and status cannot be changed.</div>";
    } else {
        $result = mysqli_query($conn, "SELECT u.email, u.fullname, c.barangay, c.type FROM complaints c JOIN users u ON c.user_id = u.id WHERE c.id = $complaint_id");
        $user = mysqli_fetch_assoc($result);

        if ($user) {
            $stmt = mysqli_prepare($conn, "UPDATE complaints SET status = ?, remarks = ? WHERE id = ?");
            mysqli_stmt_bind_param($stmt, 'ssi', $new_status, $remarks, $complaint_id);
            if (mysqli_stmt_execute($stmt)) {
                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'stamariailocossur61@gmail.com';
                    $mail->Password = 'jxsu lnnp lcnm erzn';
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;

                    $mail->setFrom('macktzy@gmail.com', 'OPERAH Admin');
                    $mail->addAddress($user['email'], $user['fullname']);

                    $mail->isHTML(true);
                    $mail->Subject = 'OPERAH - Report Status Updated';
                    $mail->Body = "<p>Hi <strong>{$user['fullname']}</strong>,</p><p>Your report has been updated:</p><ul><li><strong>Report ID:</strong> $complaint_id</li><li><strong>Barangay:</strong> {$user['barangay']}</li><li><strong>Type:</strong> {$user['type']}</li><li><strong>Status:</strong> $new_status</li><li><strong>Remarks:</strong> $remarks</li></ul><p>Thank you for using the OPERAH system.</p>";

                    $mail->send();
                    $message = "<div class='alert alert-success'>Status updated and notification sent to <strong>{$user['email']}</strong>.</div>";
                } catch (Exception $e) {
                    $message = "<div class='alert alert-warning'>Updated, but email failed: " . htmlspecialchars($mail->ErrorInfo) . "</div>";
                }
            } else {
                $message = "<div class='alert alert-danger'>Failed to update complaint in the database.</div>";
            }
        } else {
            $message = "<div class='alert alert-danger'>User not found for this complaint.</div>";
        }
    }
}

// Enhanced: Forward to Captain (if not already forwarded)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_to_captain'], $_POST['complaint_id'])) {
    $complaint_id = (int) $_POST['complaint_id'];

    $query = mysqli_query($conn, "SELECT c.*, u.fullname, u.email FROM complaints c JOIN users u ON c.user_id = u.id WHERE c.id = $complaint_id");
    $complaint = mysqli_fetch_assoc($query);

    if ($complaint) {
        if (!empty($complaint['forwarded_to_captain'])) {
            $message = "<div class='alert alert-warning'>This complaint has already been forwarded to the Barangay Captain.</div>";
        } else {
            $barangay = $complaint['barangay'];
            $captain_query = mysqli_query($conn, "SELECT email FROM captains WHERE barangay = '$barangay' LIMIT 1");
            $captain = mysqli_fetch_assoc($captain_query);

            if ($captain) {
                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'macktzy@gmail.com';
                    $mail->Password = 'xbpt xlmy aakp lpbm';
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;

                    $mail->setFrom('macktzy@gmail.com', 'OPERAH Admin');
                    $mail->addAddress($captain['email']);

                    $mail->isHTML(true);
                    $mail->Subject = 'New Complaint from ' . $barangay;
                    $mail->Body = "<p>Dear Barangay Captain,</p><p>A complaint has been submitted in your barangay:</p><ul><li><strong>Report ID:</strong> {$complaint['id']}</li><li><strong>User:</strong> {$complaint['fullname']}</li><li><strong>Type:</strong> {$complaint['type']}</li><li><strong>Status:</strong> {$complaint['status']}</li><li><strong>Remarks:</strong> {$complaint['remarks']}</li><li><strong>Date Filed:</strong> {$complaint['date_filed']}</li></ul><p>Please log in to the OPERAH system to view more details.</p>";

                    $mail->send();
                    $update_forwarded_flag($complaint_id);
                    $message = "<div class='alert alert-success'>Notification sent to the Barangay Captain of <strong>$barangay</strong>.</div>";
                } catch (Exception $e) {
                    $message = "<div class='alert alert-danger'>Failed to send email to the captain: " . htmlspecialchars($mail->ErrorInfo) . "</div>";
                }
            } else {
                $message = "<div class='alert alert-warning'>No captain found for Barangay: $barangay.</div>";
            }
        }
    }
}

// Fetch complaints
$complaints = [];
$query = mysqli_query($conn, "SELECT c.id, u.fullname, c.barangay, c.type, c.status, c.remarks, c.date_filed, c.forwarded_to_captain FROM complaints c JOIN users u ON c.user_id = u.id ORDER BY c.date_filed DESC");
if ($query) {
    $complaints = mysqli_fetch_all($query, MYSQLI_ASSOC);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Update Report Status - OPERAH</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            margin: 0;
            background: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .toggle-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            background-color: #4ca1af;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            z-index: 1050;
            cursor: pointer;
            font-size: 1.25rem;
            line-height: 1;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 250px;
            background: linear-gradient(135deg, #1c4966, #3a8db7);
            padding-top: 30px;
            color: #fff;
            display: flex;
            flex-direction: column;
            z-index: 1000;
            transition: transform 0.3s ease-in-out;
            box-shadow: 2px 0 8px rgba(0, 0, 0, 0.1);
        }
        .sidebar .logo {
            display: block;
            margin: 0 auto 20px;
            width: 80px;
            height: 80px;
            object-fit: contain;
            filter: drop-shadow(0 0 3px rgba(255, 255, 255, 0.6));
        }
        .sidebar h4 {
            text-align: center;
            margin-bottom: 35px;
            font-weight: 700;
            font-size: 22px;
            letter-spacing: 0.5px;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        }
        .sidebar a {
            display: block;
            padding: 14px 30px;
            color: #e0e7ff;
            font-weight: 500;
            font-size: 16px;
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: all 0.25s ease;
        }
        .sidebar a:hover,
        .sidebar a.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: #ffffff;
            border-left: 4px solid #82c7ff;
        }
        .logout {
            margin-top: auto;
            padding: 25px 0;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }
        .logout a {
            color: #ffb3b3;
            font-weight: 600;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .logout a:hover {
            color: #ff7a7a;
        }

        .main-content {
            margin-left: 250px;
            padding: 40px 30px;
            transition: margin-left 0.3s ease-in-out;
        }
        .table-responsive {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
        }
        table.table th, table.table td {
            vertical-align: middle;
            text-align: center;
        }
        .form-inline {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-wrap: nowrap;
            justify-content: center;
        }
        .form-inline select.form-select-sm,
        .form-inline input.form-control-sm {
            min-width: 110px;
        }
        .form-inline input.form-control-sm {
            flex-grow: 1;
            min-width: 150px;
        }
        .form-inline button {
            min-width: 80px;
        }
        .badge-status {
            display: inline-block;
            padding: 0.4em 1.2em;
            font-size: 0.9em;
            font-weight: 600;
            border-radius: 50px;
            color: white;
            text-transform: uppercase;
            user-select: none;
            cursor: default;
            box-shadow: 0 2px 5px rgba(0,0,0,0.15);
        }
        .badge-pending {
            background-color: #fbbf24;
        }
        .badge-inprogress {
            background-color: #0d6efd;
        }
        .badge-resolved {
            background-color: #198754;
        }
        .finalized-text {
            font-weight: 700;
            color: #198754;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                width: 100%;
                height: auto;
                position: fixed;
                top: 0;
                left: 0;
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .toggle-btn {
                display: block;
            }
            .main-content {
                margin-left: 0;
                padding-top: 70px;
            }
            .form-inline {
                flex-wrap: wrap;
                justify-content: flex-start;
            }
            .form-inline select.form-select-sm,
            .form-inline input.form-control-sm,
            .form-inline button {
                min-width: auto;
                flex: 1 1 100%;
                margin-bottom: 6px;
            }
        }
    </style>
</head>
<body>

<button class="toggle-btn" aria-label="Toggle Sidebar" onclick="document.getElementById('sidebar').classList.toggle('active')">☰</button>

<div class="sidebar" id="sidebar">
    <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo" class="logo" />
    <h4>OPERAH System</h4>
    <a href="dashboard.php">Dashboard</a>
    <a href="view_complaints.php">View Reports</a>
    <a href="update_status.php" class="active">Update Status</a>
    <a href="users.php">Manage Users</a>
    <div class="logout">
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="main-content">
    <h2 class="mb-4"><span style="font-weight: 700; color: #1c4966; padding: 6px 12px; border-radius: 6px;">Update Reports Status</span></h2>
    <?= $message ?>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle text-center">
           <thead class="table-light">
<tr>
    <th>#</th>
    <th>Report ID</th>
    <th>User</th>
    <th>Barangay</th>
    <th>Type</th>
    <th>Status</th>
    <th>Remarks</th>
    <th>Date Filed</th>
    <th>Action</th>
</tr>
</thead>
<tbody>
<?php if ($complaints): ?>
    <?php foreach ($complaints as $i => $c): ?>
        <tr>
            <td><?= $i + 1 ?></td>
            <td><?= htmlspecialchars($c['id']) ?></td>
            <td><?= htmlspecialchars($c['fullname']) ?></td>
            <td><?= htmlspecialchars($c['barangay']) ?></td>
            <td><?= htmlspecialchars($c['type']) ?></td>
            <td>
                <?php
                    $status = strtolower($c['status']);
                    $status_class = '';
                    switch ($status) {
                        case 'pending':
                            $status_class = 'badge-pending';
                            break;
                        case 'in progress':
                            $status_class = 'badge-inprogress';
                            break;
                        case 'resolved':
                            $status_class = 'badge-resolved';
                            break;
                        default:
                            $status_class = 'badge-secondary';
                    }
                ?>
                <span class="badge-status <?= $status_class ?>" title="<?= ucfirst($status) ?>">
                    <?= strtoupper($status) ?>
                </span>
            </td>
            <td><?= htmlspecialchars($c['remarks'] ?? 'N/A') ?></td>
            <td><?= htmlspecialchars($c['date_filed']) ?></td>
            <td>
                <?php if ($c['status'] === 'Resolved'): ?>
                    <span class="finalized-text">Finalized</span>
                    <!-- Send current status as hidden input because select will be disabled -->
                    <form method="POST" class="mt-2" onsubmit="return confirm('Update remarks for this resolved complaint?');">
                        <input type="hidden" name="complaint_id" value="<?= $c['id'] ?>" />
                        <input type="hidden" name="new_status" value="Resolved" />
                        <input type="text" name="remarks" class="form-control form-control-sm mt-1" placeholder="Remarks" value="<?= htmlspecialchars($c['remarks']) ?>" required />
                        <button type="submit" class="btn btn-sm btn-primary mt-1 w-100">Update Remarks</button>
                    </form>
                    <form method="POST" onsubmit="return confirm('Send this complaint to the barangay captain?');" class="mt-2">
                        <input type="hidden" name="complaint_id" value="<?= $c['id'] ?>">
                        <input type="hidden" name="send_to_captain" value="1">
                        <button type="submit" class="btn btn-sm btn-warning w-100">Send to Captain</button>
                    </form>
                <?php else: ?>
                    <div class="d-flex flex-column gap-2">
                        <form method="POST" class="form-inline" onsubmit="return confirm('Are you sure you want to update this complaint status?');">
                            <input type="hidden" name="complaint_id" value="<?= $c['id'] ?>" />
                            <select name="new_status" class="form-select form-select-sm" required>
                                <option value="" disabled selected>--Status--</option>
                                <option value="Pending" <?= $c['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
                                <option value="In Progress" <?= $c['status'] == 'In Progress' ? 'selected' : '' ?>>In Progress</option>
                                <option value="Resolved">Resolved</option>
                            </select>
                            <input type="text" name="remarks" class="form-control form-control-sm" placeholder="Remarks" value="<?= htmlspecialchars($c['remarks']) ?>" />
                            <button type="submit" class="btn btn-sm btn-primary">Update</button>
                        </form>

                        <form method="POST" onsubmit="return confirm('Send this complaint to the barangay captain?');">
                            <input type="hidden" name="complaint_id" value="<?= $c['id'] ?>">
                            <input type="hidden" name="send_to_captain" value="1">
                            <button type="submit" class="btn btn-sm btn-warning">Send to Captain</button>
                        </form>
                    </div>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
<?php else: ?>
    <tr><td colspan="9" class="text-muted">No reports found.</td></tr>
<?php endif; ?>
</tbody>
        </table>
    </div>
</div>

</body>
</html>
