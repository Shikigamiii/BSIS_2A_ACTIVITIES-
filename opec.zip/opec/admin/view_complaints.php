<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Pagination setup
$limit = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int) $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Filters
$search = trim($_GET['search'] ?? '');
$status_filter = trim($_GET['status'] ?? '');
$barangay_filter = trim($_GET['barangay'] ?? '');
$type_filter = trim($_GET['type'] ?? '');
$urgency_filter = trim($_GET['urgency'] ?? '');

// Build WHERE clauses
$where_clauses = [];
$params = [];
$param_types = '';

if ($search !== '') {
    $where_clauses[] = "(u.fullname LIKE CONCAT('%', ?, '%'))";
    $params[] = $search;
    $param_types .= 's';
}
if ($status_filter !== '') {
    $where_clauses[] = "c.status = ?";
    $params[] = $status_filter;
    $param_types .= 's';
}
if ($barangay_filter !== '') {
    $where_clauses[] = "c.barangay = ?";
    $params[] = $barangay_filter;
    $param_types .= 's';
}
if ($type_filter !== '') {
    $where_clauses[] = "c.type = ?";
    $params[] = $type_filter;
    $param_types .= 's';
}
if ($urgency_filter !== '') {
    $where_clauses[] = "c.urgency = ?";
    $params[] = $urgency_filter;
    $param_types .= 's';
}

$where_sql = '';
if ($where_clauses) {
    $where_sql = 'WHERE ' . implode(' AND ', $where_clauses);
}

// Get total count
$count_stmt = $conn->prepare("SELECT COUNT(*) FROM complaints c JOIN users u ON c.user_id = u.id $where_sql");
if ($params) {
    $count_stmt->bind_param($param_types, ...$params);
}
$count_stmt->execute();
$count_stmt->bind_result($total_complaints);
$count_stmt->fetch();
$count_stmt->close();

$total_pages = ceil($total_complaints / $limit);

// Fetch complaints
$sql = "SELECT c.id, u.fullname, c.barangay, c.type, c.status, c.remarks, c.date_filed, c.incident_date, c.urgency, c.evidence
        FROM complaints c
        JOIN users u ON c.user_id = u.id
        $where_sql
        ORDER BY c.date_filed DESC
        LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);

if ($params) {
    $all_params = array_merge($params, [$limit, $offset]);
    $all_types = $param_types . 'ii';
    $stmt->bind_param($all_types, ...$all_params);
} else {
    $stmt->bind_param('ii', $limit, $offset);
}

$stmt->execute();
$result = $stmt->get_result();
$complaints = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get distinct barangays, types, urgencies for filters
$barangays_result = $conn->query("SELECT DISTINCT barangay FROM complaints ORDER BY barangay ASC");
$barangays = $barangays_result->fetch_all(MYSQLI_ASSOC);

$types_result = $conn->query("SELECT DISTINCT type FROM complaints ORDER BY type ASC");
$types = $types_result->fetch_all(MYSQLI_ASSOC);

$urgencies = ['Low', 'Medium', 'High'];
$statuses = ['Pending', 'In Progress', 'Resolved'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>View Reports - OPERAH Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />

<!-- Bootstrap 5 CSS & Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />

<style>
    body {
        margin: 0;
        background: #eef2f7;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .sidebar {
        position: fixed;
        top: 0; left: 0;
        height: 100vh;
        width: 250px;
        background: linear-gradient(135deg, #1c4966, #3a8db7);
        padding-top: 30px;
        color: #fff;
        display: flex;
        flex-direction: column;
        z-index: 1050;
        transition: transform 0.3s ease-in-out;
        box-shadow: 2px 0 10px rgb(0 0 0 / 0.15);
    }
    .sidebar .logo {
        display: block;
        margin: 0 auto 20px;
        width: 90px;
        height: 90px;
        object-fit: contain;
        filter: drop-shadow(0 0 3px rgba(255 255 255 / 0.5));
    }
    .sidebar h4 {
        text-align: center;
        margin: 0 0 35px;
        font-weight: 700;
        font-size: 22px;
        letter-spacing: 1.2px;
        text-shadow: 0 1px 3px rgba(0,0,0,0.3);
    }
    .sidebar a {
        display: block;
        padding: 14px 30px;
        color: #e0e7ff;
        font-weight: 600;
        text-decoration: none;
        font-size: 16px;
        transition: background-color 0.25s ease, color 0.25s ease;
        border-left: 4px solid transparent;
    }
    .sidebar a:hover,
    .sidebar a.active {
        background-color: rgba(255, 255, 255, 0.15);
        color: #fff;
        border-left-color: #82c7ff;
    }
    .logout {
        margin-top: auto;
        padding: 25px 0;
        text-align: center;
        border-top: 1px solid rgba(255,255,255,0.2);
    }
    .logout a {
        color: #ffb3b3;
        font-weight: 600;
        font-size: 16px;
        text-decoration: none;
        transition: color 0.3s ease;
    }
    .logout a:hover {
        color: #ff7a7a;
    }
    .main-content {
        margin-left: 250px;
        padding: 50px 40px 40px 40px;
        transition: margin-left 0.3s ease-in-out;
        min-height: 100vh;
    }
    @media (max-width: 768px) {
        .sidebar {
            transform: translateX(-100%);
            width: 100%;
            height: auto;
            padding-bottom: 20px;
            box-shadow: none;
        }
        .sidebar.active {
            transform: translateX(0);
            box-shadow: 0 4px 12px rgb(0 0 0 / 0.3);
        }
        .main-content {
            margin-left: 0;
            padding-top: 90px;
            padding-bottom: 30px;
        }
        .toggle-btn {
            display: block;
            position: fixed;
            top: 15px;
            left: 15px;
            background-color: #3a8db7;
            color: white;
            border: none;
            padding: 10px 14px;
            border-radius: 6px;
            font-size: 20px;
            cursor: pointer;
            box-shadow: 0 2px 8px rgb(0 0 0 / 0.25);
            z-index: 1100;
            user-select: none;
        }
    }
    .toggle-btn {
        display: none;
    }
    h2 {
        color: #1c4966;
        font-weight: 700;
        letter-spacing: 1.1px;
        margin-bottom: 30px;
        text-shadow: 0 1px 2px rgb(0 0 0 / 0.1);
    }
    form.row.gy-3.gx-3.mb-4 {
        background: white;
        padding: 20px 25px;
        border-radius: 10px;
        box-shadow: 0 3px 12px rgb(0 0 0 / 0.08);
        align-items: center;
    }
    form select.form-select,
    form input.form-control {
        min-height: 44px;
        border: 1.8px solid #b2b9c5;
        font-size: 15px;
        font-weight: 600;
        transition: border-color 0.3s ease;
    }
    form select.form-select:focus,
    form input.form-control:focus {
        border-color: #3a8db7;
        box-shadow: 0 0 7px rgba(58,141,183,0.5);
        outline: none;
    }
    form button.btn-primary {
        min-width: 90px;
        font-weight: 600;
        letter-spacing: 0.8px;
    }
    form a.btn-secondary {
        min-width: 90px;
        font-weight: 600;
        letter-spacing: 0.8px;
    }
    form button.btn-success {
        min-width: 110px;
        font-weight: 600;
        letter-spacing: 0.8px;
    }
    .table-responsive {
        background: white;
        border-radius: 12px;
        box-shadow: 0 4px 16px rgb(0 0 0 / 0.12);
        padding: 25px;
    }
    table {
        font-size: 14.5px;
        color: #2e3e50;
    }
    thead.table-light {
        background: #dbe7f7;
        color: #1c4966;
        font-weight: 700;
        font-size: 15px;
    }
    tbody tr:hover {
        background-color: #f1f8ff !important;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    .badge {
        font-size: 0.9rem;
        font-weight: 600;
        padding: 5px 12px;
        border-radius: 15px;
        user-select: none;
        text-transform: uppercase;
    }
    .bg-warning.text-dark {
        background-color: #fbbf24 !important;
        color: #713f12 !important;
    }
    .bg-info.text-white {
        background-color: #3b82f6 !important;
        color: white !important;
    }
    .bg-success {
        background-color: #16a34a !important;
        color: white !important;
    }
    .bg-secondary {
        background-color: #6b7280 !important;
        color: white !important;
    }
    .bg-primary {
        background-color: #2563eb !important;
        color: white !important;
    }
    .bg-danger {
        background-color: #dc2626 !important;
        color: white !important;
    }
    .evidence-img {
        max-width: 80px;
        max-height: 60px;
        object-fit: contain;
        border-radius: 6px;
        box-shadow: 0 0 6px rgb(0 0 0 / 0.15);
        transition: transform 0.2s ease;
        cursor: pointer;
    }
    .evidence-img:hover {
        transform: scale(1.1);
    }
    /* Pagination */
    .pagination {
        justify-content: center;
    }
    .page-item.active .page-link {
        background-color: #3a8db7;
        border-color: #3a8db7;
        color: white;
        font-weight: 600;
    }
    .page-link {
        color: #3a8db7;
        font-weight: 600;
        border-radius: 6px;
        transition: background-color 0.3s ease, color 0.3s ease;
    }
    .page-link:hover {
        background-color: #82c7ff;
        color: white;
    }
</style>
</head>
<body>

<button class="toggle-btn" onclick="toggleSidebar()" aria-label="Toggle sidebar menu">☰</button>

<div class="sidebar" id="sidebar" aria-label="Sidebar Navigation">
    <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo" class="logo" />
    <h4>OPERAH System</h4>
    <a href="dashboard.php">Dashboard</a>
    <a href="view_complaints.php" class="active" aria-current="page">View Reports</a>
    <a href="update_status.php">Update Status</a>
    <a href="users.php">Manage Users</a>
    <div class="logout">
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="main-content" id="mainContent">
    <h2>All Reports Listing</h2>

    <form method="GET" class="row gy-3 gx-3 mb-4" role="search" aria-label="Filter complaints form">
        <div class="col-12 d-flex justify-content-end gap-2 flex-wrap">
            <button type="submit" class="btn btn-primary" aria-label="Apply filters">
                <i class="bi bi-funnel-fill"></i> Filter
            </button>
            <a href="view_complaints.php" class="btn btn-secondary" aria-label="Reset filters">
                <i class="bi bi-arrow-counterclockwise"></i> Reset
            </a>
            <button type="button" class="btn btn-success" onclick="exportTableToCSV()" aria-label="Export table data as CSV">
                <i class="bi bi-download"></i> Export CSV
            </button>
        </div>

        <div class="col-lg-3 col-md-6">
            <select name="barangay" class="form-select" aria-label="Filter by Barangay">
                <option value="">Filter by Barangay</option>
                <?php foreach ($barangays as $brgy): ?>
                    <option value="<?= htmlspecialchars($brgy['barangay']) ?>" <?= ($barangay_filter === $brgy['barangay']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($brgy['barangay']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-lg-3 col-md-6">
            <select name="type" class="form-select" aria-label="Filter by Type">
                <option value="">Filter by Type</option>
                <?php foreach ($types as $t): ?>
                    <option value="<?= htmlspecialchars($t['type']) ?>" <?= ($type_filter === $t['type']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($t['type']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-lg-3 col-md-6">
            <select name="status" class="form-select" aria-label="Filter by Status">
                <option value="">Filter by Status</option>
                <?php foreach ($statuses as $status): ?>
                    <option value="<?= $status ?>" <?= ($status_filter === $status) ? 'selected' : '' ?>><?= $status ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-lg-3 col-md-6">
            <select name="urgency" class="form-select" aria-label="Filter by Urgency">
                <option value="">Filter by Urgency</option>
                <?php foreach ($urgencies as $urg): ?>
                    <option value="<?= $urg ?>" <?= ($urgency_filter === $urg) ? 'selected' : '' ?>><?= $urg ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </form>

    <div class="table-responsive" role="table" aria-label="Complaints table">
        <table class="table table-bordered table-hover align-middle text-center" id="complaintsTable">
            <thead class="table-light">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">User</th>
                    <th scope="col">Barangay</th>
                    <th scope="col">Type</th>
                    <th scope="col">Status</th>
                    <th scope="col">Urgency</th>
                    <th scope="col">Incident Date</th>
                    <th scope="col">Evidence</th>
                    <th scope="col">Remarks</th>
                    <th scope="col">Date Filed</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($complaints) > 0): ?>
                    <?php foreach ($complaints as $index => $row): ?>
                        <tr tabindex="0" aria-label="Complaint <?= $offset + $index + 1 ?> by <?= htmlspecialchars($row['fullname']) ?>">
                            <td><?= $offset + $index + 1 ?></td>
                            <td><?= htmlspecialchars($row['fullname']) ?></td>
                            <td><?= htmlspecialchars($row['barangay']) ?></td>
                            <td><?= htmlspecialchars($row['type']) ?></td>
                            <td>
                                <?php
                                $statusBadgeClass = match($row['status']) {
                                    'Pending' => 'bg-warning text-dark',
                                    'In Progress' => 'bg-info text-white',
                                    'Resolved' => 'bg-success',
                                    default => 'bg-secondary',
                                };
                                ?>
                                <span class="badge <?= $statusBadgeClass ?>"><?= htmlspecialchars($row['status']) ?></span>
                            </td>
                            <td>
                                <?php
                                $urgencyBadgeClass = match($row['urgency']) {
                                    'Low' => 'bg-secondary',
                                    'Medium' => 'bg-primary',
                                    'High' => 'bg-danger',
                                    default => 'bg-secondary',
                                };
                                ?>
                                <span class="badge <?= $urgencyBadgeClass ?>"><?= htmlspecialchars($row['urgency']) ?></span>
                            </td>
                            <td><?= htmlspecialchars($row['incident_date']) ?></td>
                            <td>
                                <?php 
                                $evidenceFile = trim($row['evidence'] ?? '');
                                $fullPath = __DIR__ . '/../uploads/' . $evidenceFile;
                                $webPath = '../uploads/' . rawurlencode($evidenceFile);

                                if ($evidenceFile !== '' && file_exists($fullPath)):
                                    $ext = strtolower(pathinfo($evidenceFile, PATHINFO_EXTENSION));
                                    if (in_array($ext, ['jpg', 'jpeg', 'png'])): ?>
                                        <a href="<?= htmlspecialchars($webPath) ?>" target="_blank" rel="noopener noreferrer" aria-label="View image evidence">
                                            <img src="<?= htmlspecialchars($webPath) ?>" alt="Evidence image for complaint #<?= htmlspecialchars($row['id']) ?>" class="evidence-img" loading="lazy" />
                                        </a>
                                    <?php elseif ($ext === 'mp4'): ?>
                                        <video width="120" height="90" controls preload="metadata" style="border-radius:6px; box-shadow: 0 0 6px rgba(0,0,0,0.15); cursor:pointer;" aria-label="Play video evidence">
                                            <source src="<?= htmlspecialchars($webPath) ?>" type="video/mp4" />
                                            Your browser does not support the video tag.
                                        </video>
                                    <?php elseif ($ext === 'pdf'): ?>
                                        <a href="<?= htmlspecialchars($webPath) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-primary" aria-label="View PDF evidence">
                                            View PDF
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted" aria-label="Unsupported file format">N/A</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted" aria-label="No evidence available">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($row['remarks']) ?></td>
                            <td><?= htmlspecialchars($row['date_filed']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="10" class="text-center text-muted">No complaints found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($total_pages > 1): ?>
    <nav aria-label="Complaints pagination">
        <ul class="pagination">
            <?php if ($page > 1): ?>
                <li class="page-item"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>" aria-label="Previous page">&laquo;</a></li>
            <?php else: ?>
                <li class="page-item disabled"><span class="page-link">&laquo;</span></li>
            <?php endif; ?>

            <?php
            // Show max 7 pages with current in center
            $start = max(1, $page - 3);
            $end = min($total_pages, $page + 3);
            for ($i = $start; $i <= $end; $i++):
            ?>
                <li class="page-item <?= ($i === $page) ? 'active' : '' ?>">
                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>" aria-current="<?= ($i === $page) ? 'page' : '' ?>">
                        <?= $i ?>
                    </a>
                </li>
            <?php endfor; ?>

            <?php if ($page < $total_pages): ?>
                <li class="page-item"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>" aria-label="Next page">&raquo;</a></li>
            <?php else: ?>
                <li class="page-item disabled"><span class="page-link">&raquo;</span></li>
            <?php endif; ?>
        </ul>
    </nav>
    <?php endif; ?>

</div>

<script>
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('active');
    }

    // Export table to CSV
    function exportTableToCSV(filename = 'complaints_export.csv') {
        const rows = [];
        const table = document.getElementById('complaintsTable');
        if (!table) return;

        // Get headers
        const headers = [...table.querySelectorAll('thead th')].map(th => th.innerText.trim());
        rows.push(headers.join(','));

        // Get rows data
        [...table.querySelectorAll('tbody tr')].forEach(tr => {
            const cells = [...tr.querySelectorAll('td')].map(td => {
                // Remove commas from text to avoid CSV column break
                let text = td.innerText.trim().replace(/,/g, ''); 
                return `"${text}"`;
            });
            rows.push(cells.join(','));
        });

        const csvContent = rows.join('\n');
        const blob = new Blob([csvContent], {type: 'text/csv;charset=utf-8;'});

        if (navigator.msSaveBlob) { // For IE 10+
            navigator.msSaveBlob(blob, filename);
        } else {
            const link = document.createElement('a');
            if (link.download !== undefined) {
                const url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', filename);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }
    }
</script>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
