<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_GET['id'] ?? null;
if (!$user_id) {
    header("Location: users.php");
    exit();
}

$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    header("Location: users.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Details - OPEC</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap + Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(to right, #e0f7fa, #ffffff);
            font-family: 'Segoe UI', sans-serif;
            padding-top: 50px;
        }

        .card {
            max-width: 700px;
            margin: auto;
            border: none;
            border-radius: 16px;
            box-shadow: 0 12px 28px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background: linear-gradient(135deg, #007bff, #0dcaf0);
            color: white;
            border-top-left-radius: 16px;
            border-top-right-radius: 16px;
        }

        .info-label {
            font-weight: 600;
            color: #555;
            font-size: 15px;
        }

        .info-value {
            font-size: 16px;
            color: #212529;
            padding-bottom: 10px;
        }

        .back-btn {
            background-color: #6c757d;
            color: #fff;
            border-radius: 8px;
        }

        .back-btn:hover {
            background-color: #5a6268;
        }

        .bi {
            margin-right: 8px;
        }
    </style>
</head>
<body>

<div class="card">
    <div class="card-header text-center py-4">
        <h4><i class="bi bi-person-circle"></i> User Details</h4>
    </div>
    <div class="card-body px-5 py-4">
        <div class="mb-3">
            <div class="info-label"><i class="bi bi-person-fill"></i> Full Name:</div>
            <div class="info-value"><?= htmlspecialchars($user['name']) ?></div>
        </div>
        <div class="mb-3">
            <div class="info-label"><i class="bi bi-envelope-fill"></i> Email:</div>
            <div class="info-value"><?= htmlspecialchars($user['email']) ?></div>
        </div>
        <div class="mb-3">
            <div class="info-label"><i class="bi bi-geo-alt-fill"></i> Barangay:</div>
            <div class="info-value"><?= htmlspecialchars($user['barangay']) ?></div>
        </div>
        <div class="mb-3">
            <div class="info-label"><i class="bi bi-calendar-event-fill"></i> Date Registered:</div>
            <div class="info-value"><?= date('F j, Y - g:i A', strtotime($user['created_at'])) ?></div>
        </div>
        <div class="text-end mt-4">
            <a href="users.php" class="btn back-btn"><i class="bi bi-arrow-left-circle"></i> Back to User List</a>
        </div>
    </div>
</div>

</body>
</html>
