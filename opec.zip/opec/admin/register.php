<?php
session_start();
include('includes/db.php');

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($fullname) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = "Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        $check_stmt = mysqli_prepare($conn, "SELECT id FROM admin_users WHERE email = ?");
        mysqli_stmt_bind_param($check_stmt, 's', $email);
        mysqli_stmt_execute($check_stmt);
        mysqli_stmt_store_result($check_stmt);

        if (mysqli_stmt_num_rows($check_stmt) > 0) {
            $error = "Email already registered.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($conn, "INSERT INTO admin_users (fullname, email, password) VALUES (?, ?, ?)");
            mysqli_stmt_bind_param($stmt, 'sss', $fullname, $email, $hashed_password);

            if (mysqli_stmt_execute($stmt)) {
                $success = "Registration successful. You can now <a href='admin_login.php'>login</a>.";
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Registration - Municipality of Sta.Maria</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #e9ecef;
            font-family: 'Segoe UI', sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .register-container {
            background: #fff;
            padding: 40px 30px;
            border-radius: 16px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 480px;
        }

        .register-container img {
            width: 90px;
            height: 90px;
            margin: 0 auto 20px;
            display: block;
        }

        .register-container h4 {
            font-weight: 700;
            text-align: center;
            margin-bottom: 8px;
        }

        .register-container p {
            text-align: center;
            font-size: 0.95rem;
            color: #555;
            margin-bottom: 25px;
        }

        .form-label {
            font-weight: 600;
        }

        .form-control {
            padding: 10px 14px;
            font-size: 15px;
            border-radius: 8px;
        }

        .btn-register {
            background-color: #28a745;
            font-weight: 600;
            font-size: 16px;
            padding: 10px;
            border-radius: 8px;
            color: #fff;
        }

        .btn-register:hover {
            background-color: #218838;
        }

        .footer-link {
            text-align: center;
            margin-top: 15px;
            font-size: 0.9rem;
        }

        .footer-link a {
            color: #007bff;
            text-decoration: none;
        }

        .footer-link a:hover {
            text-decoration: underline;
        }

        @media (max-width: 576px) {
            .register-container {
                padding: 30px 20px;
            }

            .btn-register {
                font-size: 15px;
            }

            .register-container h4 {
                font-size: 20px;
            }

            .register-container p {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

<div class="register-container">
    <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo">
    <h4>Municipality of Sta.Maria</h4>
    <p>Create your admin account</p>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="mb-3">
            <label for="fullname" class="form-label">Full Name</label>
            <input type="text" name="fullname" id="fullname" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Email Address</label>
            <input type="email" name="email" id="email" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" name="password" id="password" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="confirm_password" class="form-label">Confirm Password</label>
            <input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
        </div>

        <div class="d-grid">
            <button type="submit" class="btn btn-register">Register</button>
        </div>

        <div class="footer-link">
            Already have an account? <a href="login.php">Log in</a>
        </div>
    </form>
</div>

</body>
</html>
