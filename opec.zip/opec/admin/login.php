<?php
session_start();
include('includes/db.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (!empty($email) && !empty($password)) {
        $stmt = mysqli_prepare($conn, "SELECT id, password FROM admin_users WHERE email = ?");
        mysqli_stmt_bind_param($stmt, 's', $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($result)) {
            if (password_verify($password, $row['password'])) {
                $_SESSION['admin_id'] = $row['id'];
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Incorrect password.";
            }
        } else {
            $error = "Account not found.";
        }
    } else {
        $error = "Please enter both email and password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login - Municipality of Sta. Maria</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #e9ecef;
            font-family: 'Segoe UI', sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .login-container {
            background: #ffffff;
            padding: 35px 25px;
            border-radius: 16px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-container img {
            width: 80px;
            height: 80px;
            margin-bottom: 15px;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }

        .login-container h4 {
            font-weight: 700;
            text-align: center;
            margin-bottom: 8px;
        }

        .login-container p {
            text-align: center;
            margin-bottom: 25px;
            color: #555;
            font-size: 0.95rem;
        }

        .form-label {
            font-weight: 600;
        }

        .form-control {
            padding: 10px 14px;
            font-size: 15px;
            border-radius: 8px;
        }

        .btn-login {
            background-color: #28a745;
            font-weight: 600;
            color: #fff;
            font-size: 16px;
            padding: 10px;
            border-radius: 8px;
        }

        .btn-login:hover {
            background-color: #218838;
        }

        .footer-link {
            text-align: center;
            margin-top: 15px;
            font-size: 0.9rem;
        }

        .footer-link a {
            color: #007bff;
            text-decoration: none;
        }

        .footer-link a:hover {
            text-decoration: underline;
        }

        @media (max-width: 576px) {
            .login-container {
                padding: 25px 18px;
            }

            .login-container h4 {
                font-size: 20px;
            }

            .login-container p {
                font-size: 14px;
            }

            .btn-login {
                font-size: 15px;
            }
        }
    </style>
</head>
<body>

<div class="login-container">
    <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo">
    <h4>Municipality of Sta. Maria</h4>
    <p>Login to your <strong>OPERAH</strong> admin account</p>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" id="email" class="form-control" required placeholder="Enter your email">
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" name="password" id="password" class="form-control" required placeholder="Enter your password">
        </div>

        <div class="d-grid">
            <button type="submit" class="btn btn-login">Log In</button>
        </div>

        <div class="footer-link">
            Don’t have an account? <a href="register.php">Create one</a>
        </div>
    </form>
</div>

</body>
</html>
