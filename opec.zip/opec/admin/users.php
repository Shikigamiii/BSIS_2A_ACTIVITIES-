<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$users = [];
$query = mysqli_query($conn, "SELECT id, name, email, barangay, created_at FROM users ORDER BY created_at DESC");
if ($query) {
    $users = mysqli_fetch_all($query, MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Management - OPERAH</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            margin: 0;
            background-color: #f4f6f9;
            font-family: 'Segoe UI', sans-serif;
        }

        .toggle-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            background-color: #4ca1af;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            z-index: 1050;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 250px;
            background: linear-gradient(135deg, #1c4966, #3a8db7);
            padding-top: 30px;
            color: #fff;
            display: flex;
            flex-direction: column;
            z-index: 1000;
            transition: transform 0.3s ease-in-out;
            box-shadow: 2px 0 8px rgba(0, 0, 0, 0.15);
        }

        .sidebar .logo {
            display: block;
            margin: 0 auto 15px;
            width: 80px;
            height: 80px;
            object-fit: contain;
            filter: drop-shadow(0 0 3px rgba(255, 255, 255, 0.6));
        }

        .sidebar h4 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: bold;
            font-size: 20px;
        }

        .sidebar a {
            display: block;
            padding: 14px 30px;
            color: #e0e7ff;
            font-weight: 500;
            font-size: 16px;
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: all 0.25s ease;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: #ffffff;
            border-left: 4px solid #82c7ff;
        }

        .logout {
            margin-top: auto;
            padding: 25px 0;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }

        .logout a {
            color: #ffb3b3;
            font-weight: 600;
            text-decoration: none;
        }

        .logout a:hover {
            color: #ff7a7a;
        }

        .main-content {
            margin-left: 250px;
            padding: 40px 30px;
            transition: margin-left 0.3s ease-in-out;
        }

        .search-box {
            max-width: 400px;
            margin-bottom: 20px;
        }

        .table-responsive {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.06);
        }

        .table thead th {
            background-color: #f0f0f0;
            position: sticky;
            top: 0;
            z-index: 1;
        }

        .text-muted {
            font-style: italic;
            color: #888;
        }

        @media (max-width: 768px) {
            .toggle-btn {
                display: block;
            }

            .sidebar {
                transform: translateX(-100%);
                width: 100%;
                height: auto;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding-top: 80px;
            }
        }
    </style>
</head>
<body>

<!-- Toggle Button -->
<button class="toggle-btn" onclick="document.getElementById('sidebar').classList.toggle('active')">☰</button>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo" class="logo">
    <h4>OPERAH System</h4>
    <a href="dashboard.php">Dashboard</a>
    <a href="view_complaints.php">View Reports</a>
    <a href="update_status.php">Update Status</a>
    <a href="users.php" class="active">Manage Users</a>
    <div class="logout">
        <a href="logout.php">Logout</a>
    </div>
</div>

<!-- Main Content -->
<div class="main-content">
    <h2 class="mb-4"><span style="font-weight: 700; color: #1c4966; padding: 6px 12px; border-radius: 6px;">User Management</span></h2>

    <!-- Search Filter -->
    <input type="text" class="form-control search-box" id="searchInput" placeholder="Search user name or email...">

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle text-center" id="userTable">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Barangay</th>
                    <th>Date Registered</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($users)): ?>
                    <?php foreach ($users as $index => $user): ?>
                        <tr>
                            <td><?= $index + 1 ?></td>
                            <td><?= !empty(trim($user['name'])) ? htmlspecialchars($user['name']) : '<span class="text-muted">No name</span>' ?></td>
                            <td><?= htmlspecialchars($user['email']) ?></td>
                            <td><?= !empty(trim($user['barangay'])) ? htmlspecialchars($user['barangay']) : '<span class="text-muted">No barangay</span>' ?></td>
                            <td><?= date('F j, Y', strtotime($user['created_at'])) ?></td>
                            <td>
                                <a href="view_user.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-info">View Details</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-muted">No users found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    // Live search
    document.getElementById("searchInput").addEventListener("input", function () {
        const filter = this.value.toLowerCase();
        const rows = document.querySelectorAll("#userTable tbody tr");

        rows.forEach(row => {
            const name = row.children[1].textContent.toLowerCase();
            const email = row.children[2].textContent.toLowerCase();
            row.style.display = name.includes(filter) || email.includes(filter) ? "" : "none";
        });
    });
</script>

</body>
</html>
