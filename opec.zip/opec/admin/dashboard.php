<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Complaint Data with Color Mapping (for pie chart)
$complaint_data = [];
$comp_query = mysqli_query($conn, "SELECT status, COUNT(*) as count FROM complaints GROUP BY status");
while ($row = mysqli_fetch_assoc($comp_query)) {
    $status = strtolower($row['status']);
    $complaint_data['labels'][] = ucfirst($status);
    $complaint_data['counts'][] = $row['count'];

    switch ($status) {
        case 'pending':
            $complaint_data['colors'][] = '#e74c3c'; // Red
            break;
        case 'resolved':
            $complaint_data['colors'][] = '#2ecc71'; // Green
            break;
        case 'in progress':
            $complaint_data['colors'][] = '#3498db'; // Blue
            break;
        default:
            $complaint_data['colors'][] = '#95a5a6'; // Default Gray
    }
}

// Complaints by Barangay Data (for bar chart with distinct colors)
$complaints_brgy_data = [];
$brgy_query = mysqli_query($conn, "SELECT barangay, COUNT(*) as count FROM complaints GROUP BY barangay ORDER BY count DESC");
while ($row = mysqli_fetch_assoc($brgy_query)) {
    $complaints_brgy_data['labels'][] = $row['barangay'];
    $complaints_brgy_data['counts'][] = (int)$row['count'];
}
// Generate distinct colors for barangays (using HSL with step)
$brgy_colors = [];
$brgyCount = count($complaints_brgy_data['labels'] ?? []);
for ($i = 0; $i < $brgyCount; $i++) {
    $hue = ($i * 360 / max($brgyCount, 1)) % 360;
    $brgy_colors[] = "hsl($hue, 70%, 50%)";
}

// Monthly Complaint Data (for line chart)
$monthly_complaints = [];
$monthly_query = mysqli_query($conn, "
    SELECT YEAR(created_at) as year, MONTH(created_at) as month, status, COUNT(*) as count 
    FROM complaints 
    GROUP BY year, month, status
");
while ($row = mysqli_fetch_assoc($monthly_query)) {
    $year = $row['year'];
    $month = $row['month'];
    $status = strtolower($row['status']);

    if (!isset($monthly_complaints[$year])) {
        $monthly_complaints[$year] = [];
    }

    if (!isset($monthly_complaints[$year][$month])) {
        $monthly_complaints[$year][$month] = [];
    }

    if (!isset($monthly_complaints[$year][$month][$status])) {
        $monthly_complaints[$year][$month][$status] = 0;
    }

    $monthly_complaints[$year][$month][$status] += $row['count'];
}

// Overview data
$total_complaints = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM complaints"));
$total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM users"));
$total_captains = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM captains"));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin Dashboard - OPERAH</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Your existing CSS */
        body {
            margin: 0;
            background-color: #eef3f7;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .toggle-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            background-color: #4ca1af;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            z-index: 1100;
            cursor: pointer;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 250px;
            background: linear-gradient(135deg, #1c4966, #3a8db7);
            padding-top: 30px;
            color: #fff;
            display: flex;
            flex-direction: column;
            z-index: 1050;
            transition: transform 0.3s ease-in-out;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.15);
        }
        .sidebar .logo {
            display: block;
            margin: 0 auto 20px;
            width: 90px;
            height: 90px;
            object-fit: contain;
            filter: drop-shadow(0 0 3px rgba(255, 255, 255, 0.5));
        }
        .sidebar h4 {
            text-align: center;
            margin: 0 0 35px;
            font-weight: 700;
            font-size: 22px;
            letter-spacing: 1.2px;
            text-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
        }
        .sidebar a {
            display: block;
            padding: 14px 30px;
            color: #e0e7ff;
            font-weight: 600;
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.25s ease, color 0.25s ease;
            border-left: 4px solid transparent;
        }
        .sidebar a:hover,
        .sidebar a.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: #fff;
            border-left-color: #82c7ff;
        }
        .logout {
            margin-top: auto;
            padding: 25px 0;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }
        .logout a {
            color: #ffb3b3;
            font-weight: 600;
            font-size: 16px;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .logout a:hover {
            color: #ff7a7a;
        }
        .main-content {
            margin-left: 250px;
            padding: 40px 30px;
            background: #fff;
            min-height: 100vh;
            transition: margin-left 0.3s ease-in-out;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        }
        canvas {
            width: 100% !important;
            height: 340px !important;
        }
        .chart-card {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.06);
            padding: 25px;
            border: 1px solid #e0e0e0;
        }
        .chart-title {
            display: flex;
            align-items: center;
            font-weight: 600;
            font-size: 18px;
            margin-bottom: 15px;
            color: #333;
        }
        .chart-title i {
            margin-right: 10px;
            font-size: 20px;
            color: #4e73df;
        }

        /* Smaller year select styling */
        #yearSelect.form-select-sm {
            font-size: 0.85rem;
            padding: 0.25rem 0.5rem;
            border-radius: 6px;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                width: 100%;
                height: auto;
                padding-bottom: 20px;
                box-shadow: none;
            }
            .sidebar.active {
                transform: translateX(0);
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            }
            .main-content {
                margin-left: 0;
                padding-top: 90px;
                padding-bottom: 30px;
            }
            .toggle-btn {
                display: block;
                position: fixed;
                top: 15px;
                left: 15px;
                background-color: #3a8db7;
                color: white;
                border: none;
                padding: 10px 14px;
                border-radius: 6px;
                font-size: 20px;
                cursor: pointer;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25);
                z-index: 1100;
            }
        }
    </style>
</head>
<body>
<button class="toggle-btn" onclick="toggleSidebar()">☰</button>

<div class="sidebar" id="sidebar">
    <img src="../assets/img/Sta.Maria.png" alt="Municipality Logo" class="logo" />
    <h4>OPERAH System</h4>
    <a href="dashboard.php" class="active">Dashboard</a>
    <a href="view_complaints.php">View Reports</a>
    <a href="update_status.php">Update Status</a>
    <a href="users.php">Manage Users</a>
    <div class="logout">
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="main-content">
    <h2 class="mb-4"><span style="font-weight: 700; color: #1c4966; padding: 6px 12px; border-radius: 6px;">Admin Dashboard</span></h2>
    <div class="row g-4">
        <div class="col-12 col-md-4">
            <div class="card p-4 text-center bg-light">
                <h5>Total Reports</h5>
                <p class="display-6 text-primary fw-semibold"><?= $total_complaints['total']; ?></p>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="card p-4 text-center bg-light">
                <h5>Total Users</h5>
                <p class="display-6 text-success fw-semibold"><?= $total_users['total']; ?></p>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="card p-4 text-center bg-light">
                <h5>Total Barangay Captains</h5>
                <p class="display-6 text-info fw-semibold"><?= $total_captains['total']; ?></p>
            </div>
        </div>
    </div>

    <div class="row g-4 mt-5">
        <!-- Reports by Status -->
        <div class="col-12 col-md-6">
            <div class="chart-card">
                <div class="chart-title">
                    <i class="bi bi-chat-left-text-fill"></i> Reports by Status
                </div>
                <canvas id="complaintChart"></canvas>
            </div>
        </div>
        <!-- Complaints by Barangay -->
        <div class="col-12 col-md-6">
            <div class="chart-card">
                <div class="chart-title">
                    <i class="bi bi-geo-alt-fill"></i> Reports by Barangay
                </div>
                <canvas id="complaintsBrgyChart"></canvas>
            </div>
        </div>
    </div>

    <div class="row g-4 mt-5">
        <div class="col-12">
            <div style="display: flex; justify-content: flex-end; align-items: center; margin-bottom: 10px;">
                <select id="yearSelect" class="form-select form-select-sm" style="width: 120px;" onchange="updateChart()">
                    <?php foreach (array_keys($monthly_complaints) as $year): ?>
                        <option value="<?= $year; ?>"><?= $year; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <h5 style="margin-top: 0;">Highest Reports by Month</h5>
            <canvas id="highestComplaintsChart" style="min-height:400px;"></canvas>
        </div>
    </div>
</div>

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('active');
}

const complaintCtx = document.getElementById('complaintChart').getContext('2d');
const complaintsBrgyCtx = document.getElementById('complaintsBrgyChart').getContext('2d');
const highestComplaintsCtx = document.getElementById('highestComplaintsChart').getContext('2d');

const compLabels = <?= json_encode($complaint_data['labels'] ?? []); ?>;
const compCounts = <?= json_encode($complaint_data['counts'] ?? []); ?>;
const compColors = <?= json_encode($complaint_data['colors'] ?? []); ?>;

const brgyLabels = <?= json_encode($complaints_brgy_data['labels'] ?? []); ?>;
const brgyCounts = <?= json_encode($complaints_brgy_data['counts'] ?? []); ?>;
const brgyColors = <?= json_encode($brgy_colors ?? []); ?>;

const allMonthlyData = <?= json_encode($monthly_complaints); ?>; // Store all monthly complaint data

// Pie chart: Complaints by Status
new Chart(complaintCtx, {
    type: 'pie',
    data: {
        labels: compLabels,
        datasets: [{
            data: compCounts,
            backgroundColor: compColors,
            borderColor: '#fff',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            title: {
                display: true,
                text: 'Reports by Status',
                color: '#333',
                font: {
                    size: 18,
                    weight: 'bold'
                }
            },
            legend: {
                position: 'bottom',
                labels: { color: '#333', boxWidth: 18 }
            }
        }
    }
});

// Bar chart: Complaints by Barangay
new Chart(complaintsBrgyCtx, {
    type: 'bar',
    data: {
        labels: brgyLabels,
        datasets: [{
            label: 'Complaints',
            data: brgyCounts,
            backgroundColor: brgyColors,
            borderColor: '#333',
            borderWidth: 1
        }]
    },
    options: {
        indexAxis: 'x',
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            title: {
                display: true,
                text: 'Reports by Barangay',
                color: '#333',
                font: {
                    size: 18,
                    weight: 'bold'
                }
            },
            legend: { display: false },
            tooltip: {
                callbacks: {
                    label: ctx => `${ctx.parsed.y} Reports`
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: { stepSize: 1, color: '#444' },
                grid: { color: '#e0e0e0' }
            },
            x: {
                ticks: { color: '#444', maxRotation: 45, minRotation: 30, autoSkip: false },
                grid: { display: false }
            }
        }
    }
});

let highestComplaintsChart = new Chart(highestComplaintsCtx, {
    type: 'line',
    data: {
        labels: [], // Will be populated by updateChart
        datasets: [{
            label: 'Highest Complaints',
            data: [], // Will be populated by updateChart
            borderColor: '#3498db',
            backgroundColor: 'rgba(52, 152, 219, 0.1)',
            fill: true,
            tension: 0.4,
            borderWidth: 2,
            pointRadius: 4,
            pointBackgroundColor: '#3498db',
            pointBorderColor: '#fff',
            pointBorderWidth: 1,
            pointHoverRadius: 6,
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: '#3498db',
            pointHoverBorderWidth: 2,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            title: {
                display: true,
                text: 'Highest Reports by Month',
                color: '#333',
                font: {
                    size: 18,
                    weight: 'bold'
                }
            },
            legend: { display: false },
            tooltip: {
                mode: 'index',
                intersect: false,
                backgroundColor: '#222',
                titleColor: '#fff',
                bodyColor: '#ddd',
                cornerRadius: 6,
                padding: 10,
                displayColors: false,
                callbacks: {
                    label: function(tooltipItem) {
                        return `Reports: ${tooltipItem.raw}`;
                    }
                }
            }
        },
        interaction: {
            mode: 'nearest',
            intersect: false
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    color: '#444',
                    stepSize: 1
                },
                grid: {
                    color: '#e0e0e0',
                    drawBorder: false
                }
            },
            x: {
                ticks: {
                    color: '#444',
                    maxRotation: 90,
                    minRotation: 45,
                    autoSkip: true,
                    maxTicksLimit: 12
                },
                grid: {
                    display: false
                }
            }
        }
    }
});

function updateChart() {
    const selectedYear = document.getElementById('yearSelect').value;
    const monthlyData = allMonthlyData[selectedYear] || {};
    
    const newLabels = [];
    const newData = [];
    
    for (let month = 1; month <= 12; month++) {
        newLabels.push(new Date(selectedYear, month - 1).toLocaleString('default', { month: 'long' }) + ' ' + selectedYear);
        newData.push(monthlyData[month] ? Object.values(monthlyData[month]).reduce((a, b) => a + b, 0) : 0);
    }
    
    highestComplaintsChart.data.labels = newLabels;
    highestComplaintsChart.data.datasets[0].data = newData;
    highestComplaintsChart.update();
}

// Initialize the chart with the current year data on page load
updateChart();
</script>
</body>
</html>
