<?php
require_once('../config.php');

// Enable error reporting for debugging (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

$response = ['status' => 'error', 'message' => 'An unknown error occurred.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? $conn->real_escape_string($_POST['id']) : null;
    $firstname = $conn->real_escape_string($_POST['firstname'] ?? '');
    $lastname = $conn->real_escape_string($_POST['lastname'] ?? '');
    $gender = $conn->real_escape_string($_POST['gender'] ?? '');
    $course_id = $conn->real_escape_string($_POST['course_id'] ?? '');
    $email = $conn->real_escape_string($_POST['email'] ?? '');
    $contact = $conn->real_escape_string($_POST['contact'] ?? '');
    $address = $conn->real_escape_string($_POST['address'] ?? '');
    $password = $_POST['password'] ?? '';
    $hashed_password = $password ? password_hash($password, PASSWORD_DEFAULT) : '';

    // Validate required fields
    if (!$firstname || !$lastname || !$gender || !$course_id || !$email || (!$id && !$password)) {
        $response['message'] = "Missing required fields.";
        echo json_encode($response);
        exit;
    }

    // Check for duplicate email
    $check = $conn->query("SELECT id FROM student_list WHERE email = '$email' AND delete_flag = 0" . ($id ? " AND id != '$id'" : ""));
    if ($check && $check->num_rows > 0) {
        $response['message'] = "Email already exists.";
        echo json_encode($response);
        exit;
    }

    // Optional file upload (avatar)
    $avatar = '';
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === 0) {
        $ext = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
        $filename = uniqid("stu_", true) . '.' . $ext;
        $upload_dir = '../uploads/students/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        move_uploaded_file($_FILES['avatar']['tmp_name'], $upload_dir . $filename);
        $avatar = $filename;
    }

    if (!$id) {
        // Insert new student
        $sql = "INSERT INTO student_list 
                (firstname, lastname, gender, course_id, email, contact, address, password, avatar) 
                VALUES 
                ('$firstname', '$lastname', '$gender', '$course_id', '$email', '$contact', '$address', '$hashed_password', '$avatar')";
    } else {
        // Update existing student
        $sql = "UPDATE student_list SET 
                firstname='$firstname', lastname='$lastname', gender='$gender',
                course_id='$course_id', email='$email', contact='$contact', address='$address'";
        if (!empty($hashed_password)) {
            $sql .= ", password='$hashed_password'";
        }
        if (!empty($avatar)) {
            $sql .= ", avatar='$avatar'";
        }
        $sql .= " WHERE id='$id'";
    }

    if ($conn->query($sql)) {
        $response['status'] = 'success';
        $response['message'] = $id ? 'Student updated successfully.' : 'Student added successfully.';
    } else {
        $response['message'] = 'Database Error: ' . $conn->error;
    }
} else {
    $response['message'] = 'Invalid request method.';
}

echo json_encode($response);
