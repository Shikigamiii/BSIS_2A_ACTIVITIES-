<aside class="main-sidebar sidebar-dark-primary elevation-4 sidebar-no-expand" style="background: linear-gradient(to bottom right, #1f1c2c, #928dab); box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.5); padding: 10px;">
    <!-- Brand Logo -->
    <a href="<?php echo base_url ?>admin" class="brand-link bg-transparent text-sm border-0 shadow-sm d-flex align-items-center justify-content-center" style="padding: 15px;">
        <img src="<?php echo validate_image($_settings->info('logo'))?>" alt="Store Logo" 
            class="brand-image img-circle elevation-3 bg-black p-1" 
            style="width: 2.5rem; height: 2.5rem; object-fit: contain; box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.3);">
        <span class="brand-text font-weight-bold text-white ml-3" 
            style="text-shadow: 2px 2px 4px rgba(0,0,0,0.5); font-size: 1.2rem;">
            <?php echo $_settings->info('short_name') ?>
        </span>
    </a>
    <!-- Sidebar -->
    <div class="sidebar os-host os-theme-light os-host-overflow os-host-overflow-y os-host-resize-disabled os-host-transition os-host-scrollbar-horizontal-hidden" 
        style="background: linear-gradient(to bottom right, #2b5876, #4e4376); border-right: 3px solid rgba(255, 255, 255, 0.1);">
        <nav class="mt-4">

            <ul class="nav nav-pills nav-sidebar flex-column text-sm nav-compact nav-flat" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item mb-3">
                    <a href="./" class="nav-link nav-home d-flex align-items-center" style="border-radius: 10px; padding: 12px;">
                        <i class="nav-icon fas fa-tachometer-alt text-primary mr-3" style="font-size: 1.5rem; text-shadow: 2px 2px 5px rgba(0, 0, 255, 0.5);"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-header text-uppercase text-light font-weight-bold mt-3 mb-2" style="font-size: 0.9rem;">Students</li>
                <li class="nav-item mb-2">
                    <a href="<?php echo base_url ?>admin/?page=students/manage_student" class="nav-link nav-students_manage_student d-flex align-items-center" style="border-radius: 10px; padding: 12px;">
                        <i class="nav-icon fas fa-user-plus text-success mr-3" style="font-size: 1.5rem; text-shadow: 2px 2px 5px rgba(0, 255, 0, 0.5);"></i>
                        <p>New Student</p>
                    </a>
                </li>
                <li class="nav-item mb-2">
                    <a href="<?php echo base_url ?>admin/?page=students" class="nav-link nav-students d-flex align-items-center" style="border-radius: 10px; padding: 12px;">
                        <i class="nav-icon fas fa-users text-info mr-3" style="font-size: 1.5rem; text-shadow: 2px 2px 5px rgba(0, 255, 255, 0.5);"></i>
                        <p>Student List</p>
                    </a>
                </li>
                <li class="nav-header text-uppercase text-light font-weight-bold mt-3 mb-2" style="font-size: 0.9rem;">Maintenance</li>
                <li class="nav-item mb-2">
                    <a href="<?php echo base_url ?>admin/?page=departments" class="nav-link nav-departments d-flex align-items-center" style="border-radius: 10px; padding: 12px;">
                        <i class="nav-icon fas fa-building text-warning mr-3" style="font-size: 1.5rem; text-shadow: 2px 2px 5px rgba(255, 255, 0, 0.5);"></i>
                        <p>Department List</p>
                    </a>
                </li>
                <li class="nav-item mb-2">
                    <a href="<?php echo base_url ?>admin/?page=courses" class="nav-link nav-courses d-flex align-items-center" style="border-radius: 10px; padding: 12px;">
                        <i class="nav-icon fas fa-scroll text-danger mr-3" style="font-size: 1.5rem; text-shadow: 2px 2px 5px rgba(255, 0, 0, 0.5);"></i>
                        <p>Course List</p>
                    </a>
                </li>
                <?php if($_settings->userdata('type') == 1): ?>
                <li class="nav-item mb-2">
                    <a href="<?php echo base_url ?>admin/?page=user/list" class="nav-link nav-user_list d-flex align-items-center" style="border-radius: 10px; padding: 12px;">
                        <i class="nav-icon fas fa-users-cog text-purple mr-3" style="font-size: 1.5rem; text-shadow: 2px 2px 5px rgba(128, 0, 128, 0.5);"></i>
                        <p>User List</p>
                    </a>
                </li>
                <li class="nav-item mb-2">
                    <a href="<?php echo base_url ?>admin/?page=system_info" class="nav-link nav-system_info d-flex align-items-center" style="border-radius: 10px; padding: 12px;">
                        <i class="nav-icon fas fa-cogs text-secondary mr-3" style="font-size: 1.5rem; text-shadow: 2px 2px 5px rgba(128, 128, 128, 0.5);"></i>
                        <p>Settings</p>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</aside>
<script>
    $(document).ready(function(){
        var page = '<?php echo isset($_GET['page']) ? $_GET['page'] : 'home' ?>'.replace(/\//g, '_');
        if ($('.nav-link.nav-' + page).length > 0) {
            $('.nav-link.nav-' + page).addClass('active bg-light text-dark rounded py-2');
            $('.nav-link.nav-' + page).parents('.nav-item').addClass('menu-open');
        }
    });
</script>
