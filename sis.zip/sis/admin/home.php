<h1>Welcome to <?php echo $_settings->info('name') ?> - Admin Panel</h1>
<hr class="border-purple">

<style>
    /* Global styles */
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f7fc;
        color: #333;
    }

    h1 {
        font-size: 32px;
        color: #333;
        text-align: center;
        font-weight: 600;
        text-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    hr.border-purple {
        border: 1px solid #8e44ad;
        width: 50%;
        margin: 20px auto;
    }

    /* Section cover */
    #website-cover {
        width: 100%;
        height: 30em;
        object-fit: cover;
        object-position: center center;
        border-radius: 15px;
        box-shadow: 0px 6px 18px rgba(0, 0, 0, 0.1);
    }

    /* Info Box Styling */
    .info-box {
        border-radius: 12px;
        transition: transform 0.3s, box-shadow 0.3s;
        background: linear-gradient(145deg, #fff, #e3e9f3);
        backdrop-filter: blur(4px);
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .info-box:hover {
        transform: translateY(-6px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
    }

    .info-box .info-box-icon {
        border-radius: 12px 0 0 12px;
    }

    .info-box-content {
        padding: 10px;
    }

    .info-box-text {
        font-weight: 600;
        font-size: 18px;
        color: #333;
    }

    .info-box-number {
        font-size: 24px;
        color: #2c3e50;
    }

    /* Chart Wrappers */
    .chart-wrapper {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 15px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        padding: 1.5rem;
        transition: 0.3s ease;
    }

    .chart-wrapper:hover {
        transform: translateY(-6px);
        box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15);
    }

    .chart-container {
        width: 100%;
        height: 200px;
    }

    canvas {
        width: 100% !important;
        height: 100% !important;
    }

    /* Responsive Styling for Chart */
    @media (max-width: 768px) {
        .chart-container {
            height: 300px;
        }
    }

    /* Styling for the page layout */
    .row {
        margin-top: 20px;
    }

    .col-12 {
        margin-bottom: 20px;
    }

    /* Hover Effects */
    .info-box-icon {
        font-size: 24px;
        padding: 20px;
        text-align: center;
        border-radius: 10px;
        transition: transform 0.3s ease;
    }

    .info-box-icon:hover {
        transform: scale(1.1);
        cursor: pointer;
    }

    .chart-wrapper h5 {
        font-size: 20px;
        font-weight: bold;
        color: #444;
        margin-bottom: 1.2rem;
    }

    .chart-wrapper .chart-container {
        position: relative;
        padding: 1rem;
    }

    /* Responsive Design for small screens */
    @media (max-width: 576px) {
        .col-md-6 {
            width: 100% !important;
        }

        .chart-wrapper h5 {
            font-size: 18px;
        }
    }
</style>

<div class="row">
    <!-- Info Boxes -->
    <div class="col-12 col-sm-6 col-md-3 mb-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-dark elevation-1"><i class="fas fa-building"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Total Departments</span>
                <span class="info-box-number text-right">
                    <?php echo $conn->query("SELECT * FROM department_list WHERE delete_flag = 0 AND status = 1")->num_rows; ?>
                </span>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-md-3 mb-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-primary elevation-1"><i class="fas fa-scroll"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Total Courses</span>
                <span class="info-box-number text-right">
                    <?php echo $conn->query("SELECT * FROM course_list WHERE delete_flag = 0 AND status = 1")->num_rows; ?>
                </span>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-md-3 mb-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-warning elevation-1"><i class="fas fa-user-friends"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Students</span>
                <span class="info-box-number text-right">
                    <?php echo $conn->query("SELECT * FROM student_list WHERE delete_flag = 0")->num_rows; ?>
                </span>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-md-3 mb-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-teal elevation-1"><i class="fas fa-file-alt"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Student Academics</span>
                <span class="info-box-number text-right">
                    <?php echo $conn->query("SELECT * FROM academic_history")->num_rows; ?>
                </span>
            </div>
        </div>
    </div>
</div>

<hr>

<!-- PHP for fetching chart data -->
<?php
$dept_query = $conn->query("SELECT d.name, COUNT(s.id) AS student_count FROM academic_history s INNER JOIN course_list c ON s.course_id = c.id INNER JOIN department_list d ON c.department_id = d.id GROUP BY d.id");
$departments = [];
$student_counts = [];
while ($row = $dept_query->fetch_assoc()) {
    $departments[] = $row['name'];
    $student_counts[] = $row['student_count'];
}

$gender_query = $conn->query("SELECT gender, COUNT(id) AS count FROM student_list WHERE delete_flag = 0 GROUP BY gender");
$genders = [];
$gender_counts = [];
while ($row = $gender_query->fetch_assoc()) {
    $genders[] = ucfirst($row['gender']);
    $gender_counts[] = $row['count'];
}

$month_query = $conn->query("SELECT DATE_FORMAT(date_created, '%b %Y') as month, COUNT(id) as total FROM student_list WHERE delete_flag = 0 GROUP BY DATE_FORMAT(date_created, '%Y-%m') ORDER BY MIN(date_created)");
$months = [];
$registrations = [];
while ($row = $month_query->fetch_assoc()) {
    $months[] = $row['month'];
    $registrations[] = $row['total'];
}

$colors = ['#FFD700', '#FF0000', '#000000'];
$borders = ['#B8860B', '#8B0000', '#333333'];
$bar_bg_colors = [];
$bar_border_colors = [];
$count = count($student_counts);
for ($i = 0; $i < $count; $i++) {
    $bar_bg_colors[] = $colors[$i % count($colors)];
    $bar_border_colors[] = $borders[$i % count($borders)];
}
?>

<!-- Chart Containers -->
<div class="container-fluid px-3">
    <div class="row">
        <!-- Gender Pie Chart -->
        <div class="col-md-6 col-12 mb-4">
            <div class="chart-wrapper">
                <h5 class="mb-3 border-bottom pb-2">🧍 Gender Distribution</h5>
                <div class="chart-container">
                    <canvas id="genderChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Department Bar Chart -->
        <div class="col-md-6 col-12 mb-4">
            <div class="chart-wrapper">
                <h5 class="mb-3 border-bottom pb-2">📊 Students per Department</h5>
                <div class="chart-container">
                    <canvas id="departmentChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Monthly Line Chart (Dropdown) -->
        <div class="col-12 mb-4">
            <!-- Button to toggle the dropdown -->
            <button class="btn btn-primary w-100" type="button" data-bs-toggle="collapse" data-bs-target="#monthlyRegistrationChartWrapper" aria-expanded="false" aria-controls="monthlyRegistrationChartWrapper">
                📈 Monthly Student Registrations
            </button>
            
            <!-- Collapsible chart container -->
            <div class="collapse" id="monthlyRegistrationChartWrapper">
                <div class="chart-wrapper">
                    <div class="chart-container" style="height: 300px;">
                        <canvas id="monthlyRegistrationChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    var ctx1 = document.getElementById('departmentChart').getContext('2d');
    var ctx2 = document.getElementById('genderChart').getContext('2d');
    var ctx3 = document.getElementById('monthlyRegistrationChart').getContext('2d');

    // Pie Chart - Gender Distribution
    new Chart(ctx2, {
        type: 'pie',
        data: {
            labels: <?php echo json_encode($genders); ?>,
            datasets: [{
                label: 'Number of Enrollees',
                data: <?php echo json_encode($gender_counts); ?>,
                backgroundColor: ['#FF69B4', '#87CEEB'], // Pink for female, SkyBlue for male
                borderColor: ['#FF1493', '#1E90FF'],     // DeepPink for female, Blue for male
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
            },
        }
    });

    // Bar Chart - Students per Department
    new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($departments); ?>,
            datasets: [{
                label: 'Students per Department',
                data: <?php echo json_encode($student_counts); ?>,
                backgroundColor: <?php echo json_encode($bar_bg_colors); ?>,
                borderColor: <?php echo json_encode($bar_border_colors); ?>,
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
            },
        }
    });

    // Line Chart - Monthly Registrations
    new Chart(ctx3, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($months); ?>,
            datasets: [{
                label: 'Monthly Registrations',
                data: <?php echo json_encode($registrations); ?>,
                borderColor: '#FF6F61',
                fill: false,
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
            },
        }
    });
});
</script>
