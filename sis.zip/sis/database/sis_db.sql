-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2025 at 02:55 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sis_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_history`
--

CREATE TABLE `academic_history` (
  `id` int(30) NOT NULL,
  `student_id` int(30) NOT NULL,
  `course_id` int(30) NOT NULL,
  `semester` varchar(200) NOT NULL,
  `year` varchar(200) NOT NULL,
  `school_year` text NOT NULL,
  `status` int(10) NOT NULL DEFAULT 1 COMMENT '1= New,\r\n2= Regular,\r\n3= Returnee,\r\n4= Transferee',
  `end_status` tinyint(3) NOT NULL DEFAULT 0 COMMENT '0=pending,\r\n1=Completed,\r\n2=Dropout,\r\n3=failed,\r\n4=Transferred-out,\r\n5=Graduated',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `academic_history`
--

INSERT INTO `academic_history` (`id`, `student_id`, `course_id`, `semester`, `year`, `school_year`, `status`, `end_status`, `date_created`, `date_updated`) VALUES
(1, 1, 11, 'First Semester', '1st Year', '2018-2019', 1, 1, '2022-01-27 13:02:36', '2022-01-27 13:22:31'),
(8, 32, 9, 'First Semester', '1', '2024-2025', 2, 1, '2025-03-07 11:23:47', NULL),
(11, 52, 5, 'First Semester', '2', '2000-2001', 4, 0, '2025-03-07 11:32:49', NULL),
(12, 33, 12, 'First Semester', '3', '2010-2011', 3, 0, '2025-03-07 11:33:25', NULL),
(13, 81, 10, 'First Semester', '2', '2023-2024', 3, 0, '2025-03-07 14:00:16', NULL),
(14, 61, 1, 'Third Semester', '2', '2024-2025', 3, 1, '2025-03-07 15:17:34', NULL),
(15, 60, 10, 'First Semester', '1', '2024-2025', 1, 1, '2025-03-07 16:26:27', NULL),
(16, 5, 2, 'First Semester', '1', '2023-2024', 3, 0, '2025-03-07 16:27:00', NULL),
(17, 101, 1, 'First Semester', '1', '2024-2025', 2, 1, '2025-03-07 16:28:33', NULL),
(18, 99, 1, 'First Semester', '1', '2024-2025', 2, 1, '2025-03-07 16:28:50', NULL),
(19, 50, 2, 'First Semester', '2', '2024-2025', 3, 0, '2025-03-07 16:29:20', NULL),
(20, 72, 2, 'Second Semester', '4', '2019-2020', 2, 5, '2025-03-07 16:31:05', NULL),
(21, 92, 1, 'First Semester', '1', '2024-2025', 2, 1, '2025-03-07 16:34:04', NULL),
(22, 38, 2, 'Second Semester', '2', '2023-2024', 2, 1, '2025-03-07 16:35:05', NULL),
(23, 40, 2, 'Second Semester', '2', '2023-2024', 2, 1, '2025-03-07 16:36:19', NULL),
(24, 91, 2, 'First Semester', '2', '2024-2025', 1, 0, '2025-03-10 09:06:27', NULL),
(25, 87, 4, 'Second Semester', '4', '2020-2021', 3, 0, '2025-03-10 23:00:17', NULL),
(27, 20, 5, 'Second Semester', '3', '2022-2023', 3, 0, '2025-03-10 23:03:13', NULL),
(28, 42, 7, 'Third Semester', '1', '2024-2025', 2, 1, '2025-03-10 23:03:50', NULL),
(29, 48, 2, 'First Semester', '1', '2024-2025', 2, 1, '2025-03-10 23:04:33', NULL),
(30, 55, 1, 'Second Semester', '3', '2022-2023', 2, 1, '2025-03-10 23:06:13', NULL),
(31, 67, 1, 'Second Semester', '4', '2020-2021', 2, 4, '2025-03-10 23:06:55', NULL),
(32, 8, 1, 'First Semester', '1', '2024-2025', 2, 1, '2025-03-10 23:07:45', NULL),
(33, 9, 4, 'Second Semester', '4', '2020-2021', 4, 0, '2025-03-10 23:17:58', NULL),
(34, 56, 3, 'Third Semester', '2', '2023-2024', 4, 0, '2025-03-10 23:20:01', NULL),
(35, 43, 8, 'Second Semester', '3', '2022-2023', 4, 1, '2025-03-10 23:20:57', NULL),
(36, 41, 1, 'Second Semester', '4', '2020-2021', 2, 5, '2025-03-10 23:21:28', NULL),
(37, 66, 1, 'First Semester', '1', '2024-2025', 1, 1, '2025-03-10 23:21:49', NULL),
(38, 86, 1, 'Third Semester', '3', '2022-2023', 2, 2, '2025-03-10 23:22:40', NULL),
(39, 83, 1, 'Second Semester', '1', '2024-2025', 1, 2, '2025-03-10 23:23:03', NULL),
(40, 81, 1, 'Second Semester', '1', '2024-2025', 2, 1, '2025-03-10 23:23:25', NULL),
(41, 64, 1, 'Third Semester', '4', '2020-2021', 2, 5, '2025-03-10 23:23:59', '2025-03-10 23:24:11'),
(42, 84, 1, 'First Semester', '1', '2024-2025', 2, 1, '2025-03-10 23:24:30', NULL),
(43, 39, 11, 'First Semester', '3', '2022-2023', 1, 1, '2025-03-10 23:24:52', NULL),
(44, 62, 2, 'First Semester', '2', '2023-2024', 2, 0, '2025-03-10 23:25:18', NULL),
(45, 31, 3, 'Third Semester', '3', '2022-2023', 2, 3, '2025-03-10 23:25:46', NULL),
(46, 69, 2, 'Second Semester', '2', '2023-2024', 2, 1, '2025-03-10 23:26:19', NULL),
(47, 89, 7, 'Third Semester', '4', '2020-2021', 2, 0, '2025-03-10 23:26:37', NULL),
(48, 24, 2, 'Second Semester', '2', '2023-2024', 4, 1, '2025-03-10 23:27:01', NULL),
(49, 19, 2, 'Second Semester', '2', '2023-2024', 2, 4, '2025-03-10 23:27:20', NULL),
(50, 71, 10, 'Second Semester', '1', '2024-2025', 2, 1, '2025-03-10 23:27:47', NULL),
(51, 65, 2, 'Third Semester', '3', '2020-2021', 4, 1, '2025-03-10 23:29:38', NULL),
(52, 85, 12, 'Second Semester', '2', '2023-2024', 2, 1, '2025-03-10 23:29:56', NULL),
(53, 15, 7, 'Third Semester', '1', '2024-2025', 2, 1, '2025-03-10 23:30:32', NULL),
(54, 53, 4, 'Third Semester', '4', '2020-2021', 2, 5, '2025-03-10 23:30:55', NULL),
(55, 17, 2, 'Second Semester', '2', '2023-2024', 2, 4, '2025-03-10 23:31:14', NULL),
(56, 74, 2, 'Third Semester', '2', '2020-2021', 4, 1, '2025-03-10 23:31:37', NULL),
(57, 94, 2, 'Second Semester', '1', '2024-2025', 1, 1, '2025-03-10 23:31:54', NULL),
(58, 4, 1, 'Third Semester', '3', '2022-2023', 2, 0, '2025-03-10 23:32:16', NULL),
(59, 27, 1, 'First Semester', '1', '2024-2025', 2, 0, '2025-03-10 23:32:49', NULL),
(60, 105, 1, 'Third Semester', '4', '2020-2021', 2, 5, '2025-03-10 23:33:16', NULL),
(61, 22, 1, 'Second Semester', '1', '2024-2025', 1, 1, '2025-03-10 23:33:31', NULL),
(62, 29, 3, 'Second Semester', '2', '2022-2023', 1, 1, '2025-03-10 23:33:44', NULL),
(63, 10, 7, 'First Semester', '3', '2020-2021', 3, 1, '2025-03-10 23:34:15', NULL),
(64, 7, 11, 'Second Semester', '3', '2022-2023', 2, 3, '2025-03-10 23:34:45', NULL),
(65, 35, 1, 'Second Semester', '1', '2024-2025', 2, 1, '2025-03-10 23:35:02', NULL),
(66, 16, 11, 'Third Semester', '2', '2023-2024', 2, 0, '2025-03-10 23:35:22', NULL),
(67, 49, 3, 'Second Semester', '4', '2020-2021', 3, 1, '2025-03-10 23:35:44', NULL),
(68, 45, 2, 'Third Semester', '2', '2020-2021', 3, 1, '2025-03-10 23:36:14', NULL),
(69, 51, 9, 'First Semester', '1', '2024-2025', 2, 1, '2025-03-10 23:36:32', NULL),
(70, 36, 2, 'Second Semester', '4', '2020-2021', 2, 5, '2025-03-10 23:36:51', NULL),
(71, 78, 1, 'Second Semester', '1', '2024-2025', 2, 1, '2025-03-10 23:37:18', NULL),
(72, 98, 1, 'Second Semester', '1', '2024-2025', 1, 1, '2025-03-10 23:37:37', NULL),
(73, 73, 5, 'Third Semester', '3', '2022-2023', 3, 1, '2025-03-10 23:38:00', NULL),
(74, 93, 1, 'Second Semester', '4', '2020-2021', 4, 1, '2025-03-10 23:38:26', NULL),
(75, 47, 2, 'First Semester', '2', '2023-2024', 2, 1, '2025-03-10 23:38:57', NULL),
(76, 68, 3, 'Second Semester', '1', '2024-2025', 1, 1, '2025-03-10 23:39:13', NULL),
(77, 88, 2, 'Third Semester', '3', '2020-2021', 3, 1, '2025-03-10 23:39:32', NULL),
(78, 57, 7, 'Second Semester', '2', '2023-2024', 2, 1, '2025-03-10 23:40:07', NULL),
(79, 103, 3, 'First Semester', '4', '2020-2021', 2, 1, '2025-03-10 23:40:24', NULL),
(80, 34, 2, 'First Semester', '1', '2024-2025', 1, 1, '2025-03-10 23:40:37', NULL),
(81, 37, 5, 'Third Semester', '2', '2022-2023', 3, 1, '2025-03-10 23:40:56', NULL),
(82, 21, 3, 'Second Semester', '3', '2020-2021', 3, 1, '2025-03-10 23:41:17', NULL),
(83, 46, 5, 'Third Semester', '3', '2020-2021', 3, 0, '2025-03-10 23:41:35', NULL),
(84, 70, 2, 'Second Semester', '1', '2024-2025', 1, 2, '2025-03-10 23:41:49', NULL),
(85, 90, 2, 'Third Semester', '3', '2022-2023', 2, 1, '2025-03-10 23:42:09', NULL),
(86, 77, 9, 'Second Semester', '3', '2020-2021', 3, 1, '2025-03-10 23:42:29', NULL),
(87, 97, 1, 'Second Semester', '3', '2020-2021', 3, 1, '2025-03-10 23:42:44', NULL),
(88, 30, 5, 'Third Semester', '2', '2023-2024', 2, 3, '2025-03-10 23:43:17', NULL),
(89, 3, 2, 'Third Semester', '2', '2022-2023', 4, 1, '2025-03-10 23:43:38', NULL),
(90, 76, 2, 'Second Semester', '2', '2022-2023', 3, 0, '2025-03-10 23:43:54', NULL),
(91, 96, 1, 'Third Semester', '1', '2024-2025', 1, 0, '2025-03-10 23:44:12', NULL),
(92, 44, 4, 'Third Semester', '3', '2020-2021', 2, 1, '2025-03-10 23:44:33', NULL),
(93, 79, 1, 'Second Semester', '1', '2024-2025', 2, 2, '2025-03-10 23:44:55', NULL),
(94, 14, 2, 'Second Semester', '1', '2024-2025', 2, 1, '2025-03-10 23:45:23', NULL),
(95, 13, 2, 'Third Semester', '4', '2020-2021', 2, 4, '2025-03-10 23:45:39', NULL),
(96, 75, 1, 'First Semester', '1', '2024-2025', 1, 1, '2025-03-10 23:45:55', NULL),
(97, 95, 9, 'Third Semester', '4', '2020-2021', 2, 5, '2025-03-10 23:46:17', NULL),
(98, 23, 2, 'First Semester', '1', '2024-2025', 1, 0, '2025-03-10 23:46:40', NULL),
(99, 54, 2, 'First Semester', '1', '2024-2025', 2, 1, '2025-03-10 23:46:51', NULL),
(100, 59, 2, 'First Semester', '2', '2023-2024', 2, 0, '2025-03-10 23:47:05', NULL),
(101, 82, 5, 'Third Semester', '3', '2022-2023', 2, 3, '2025-03-10 23:47:20', NULL),
(102, 102, 2, 'Third Semester', '2', '2023-2024', 1, 2, '2025-03-10 23:47:37', NULL),
(103, 18, 2, 'Second Semester', '3', '2020-2021', 2, 2, '2025-03-10 23:47:54', NULL),
(104, 6, 1, 'Second Semester', '1', '2024-2025', 2, 3, '2025-03-10 23:48:08', NULL),
(105, 11, 7, 'First Semester', '1', '2024-2025', 1, 0, '2025-03-10 23:48:27', NULL),
(106, 80, 2, 'Third Semester', '3', '2020-2021', 2, 1, '2025-03-10 23:48:45', NULL),
(107, 100, 2, 'Third Semester', '3', '2020-2021', 1, 0, '2025-03-10 23:48:58', NULL),
(108, 58, 2, 'Third Semester', '3', '2022-2023', 2, 1, '2025-03-10 23:49:22', NULL),
(109, 28, 1, 'First Semester', '1', '2024-2025', 1, 1, '2025-03-10 23:49:43', NULL),
(110, 26, 2, 'First Semester', '2', '2020-2021', 3, 1, '2025-03-10 23:50:02', NULL),
(111, 107, 3, 'Third Semester', '1', '2024-2025', 1, 0, '2025-03-14 13:55:30', NULL),
(112, 108, 7, 'First Semester', '1', '2024-2025', 1, 0, '2025-03-14 13:58:25', NULL),
(113, 109, 1, 'First Semester', '4', '2020-2021', 1, 1, '2025-03-14 14:07:29', NULL),
(115, 110, 2, 'Second Semester', '2', '2024-2025', 1, 1, '2025-04-11 15:34:46', NULL),
(116, 111, 1, 'First Semester', '1', '2024-2025', 2, 1, '2025-05-08 16:17:12', NULL),
(117, 112, 1, 'Second Semester', '1', '2024-2025', 1, 0, '2025-05-08 16:23:29', NULL),
(118, 113, 7, 'First Semester', '1', '2020-2021', 1, 0, '2025-05-08 16:58:44', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `course_list`
--

CREATE TABLE `course_list` (
  `id` int(30) NOT NULL,
  `department_id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_list`
--

INSERT INTO `course_list` (`id`, `department_id`, `name`, `description`, `status`, `delete_flag`, `date_created`, `date_updated`) VALUES
(1, 2, 'BSIT', 'Bachelor of Science in Information Technology', 1, 0, '2022-01-27 10:03:25', NULL),
(2, 4, 'BEEd', 'Bachelor of Elementary Education', 1, 0, '2022-01-27 10:06:43', NULL),
(3, 4, 'BSEd', 'Bachelor of Secondary Education', 1, 0, '2022-01-27 10:07:21', NULL),
(4, 4, 'MAEd', 'Master of Arts in Education', 1, 0, '2022-01-27 10:07:52', NULL),
(5, 4, 'PhD Educ', 'Doctor of Philosophy in Education', 1, 0, '2022-01-27 10:08:21', NULL),
(6, 1, 'BSCE', 'Bachelor of Science in Civil Engineering', 1, 0, '2022-01-27 10:08:48', NULL),
(7, 1, 'MSCE', 'Master of Science in Civil Engineering', 1, 0, '2022-01-27 10:09:00', NULL),
(8, 1, 'BS ChE', 'Bachelor of Science in Chemical Engineering', 1, 0, '2022-01-27 10:09:35', NULL),
(9, 1, 'MS ChE', 'Master of Science in Chemical Engineering', 1, 0, '2022-01-27 10:10:16', NULL),
(10, 1, 'DEngg ChE', 'Doctor of Engineering (Chemical Engineering)', 1, 0, '2022-01-27 10:10:39', NULL),
(11, 1, 'BSCS', 'Bachelor of Science in Computer Science', 1, 0, '2022-01-27 10:12:23', NULL),
(12, 1, 'MSCS', 'Master of Science in Computer Science', 1, 0, '2022-01-27 10:12:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `department_list`
--

CREATE TABLE `department_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department_list`
--

INSERT INTO `department_list` (`id`, `name`, `description`, `status`, `delete_flag`, `date_created`, `date_updated`) VALUES
(1, 'CoEng', 'College of Engineering', 1, 0, '2022-01-27 09:22:31', '2022-01-27 09:33:36'),
(2, 'CoAS', 'College of Arts and Science', 1, 0, '2022-01-27 09:22:54', '2022-01-27 09:33:03'),
(3, 'CoB', 'College of Business', 1, 0, '2022-01-27 09:23:20', '2022-01-27 09:33:11'),
(4, 'CoE', 'College of Education', 1, 0, '2022-01-27 09:25:42', '2022-01-27 09:33:18'),
(5, 'CSSP', 'College of Social Sciences and Philosophy', 1, 0, '2022-01-27 09:26:35', '2022-01-27 09:33:49'),
(6, 'Sample101', 'Deleted Department', 1, 1, '2022-01-27 09:27:17', '2022-01-27 09:27:28');

-- --------------------------------------------------------

--
-- Table structure for table `student_list`
--

CREATE TABLE `student_list` (
  `id` int(30) NOT NULL,
  `roll` varchar(100) NOT NULL,
  `firstname` text NOT NULL,
  `middlename` text DEFAULT NULL,
  `lastname` text NOT NULL,
  `gender` varchar(100) NOT NULL,
  `contact` text NOT NULL,
  `present_address` text NOT NULL,
  `permanent_address` text NOT NULL,
  `dob` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `department_id` int(11) DEFAULT NULL,
  `year_level` varchar(10) NOT NULL DEFAULT '1st Year',
  `registration_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_list`
--

INSERT INTO `student_list` (`id`, `roll`, `firstname`, `middlename`, `lastname`, `gender`, `contact`, `present_address`, `permanent_address`, `dob`, `status`, `date_created`, `date_updated`, `delete_flag`, `department_id`, `year_level`, `registration_date`) VALUES
(1, '231415061007', 'Mark', 'D', 'Cooper', 'Male', '09123456789', 'This my sample present address.', 'This my sample permanent address.', '2007-06-23', 1, '2022-01-27 11:14:07', '2025-04-10 23:50:57', 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(3, 'DUMMY001', 'John', 'A.', 'Smith', 'Male', '09123456701', '123 Fake Street', '456 Permanent Road', '2005-01-15', 1, '2025-03-01 18:35:55', '2025-04-10 23:53:28', 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(4, 'DUMMY002', 'Jane', 'B.', 'Johnson', 'Female', '09123456702', '456 Sample Ave', '789 Permanent Blvd', '2006-02-10', 1, '2025-03-01 18:35:55', '2025-04-10 23:53:28', 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(5, 'DUMMY003', 'Michael', 'C.', 'Brown', 'Male', '09123456703', '789 Test Lane', '321 Fixed St', '2004-05-22', 1, '2025-03-01 18:35:55', '2025-04-10 23:53:28', 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(6, 'DUMMY004', 'Emma', 'D.', 'Williams', 'Female', '09123456704', '101 Example Rd', '654 Stable Ct', '2007-08-18', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(7, 'DUMMY005', 'David', 'E.', 'Miller', 'Male', '09123456705', '234 Random St', '987 Secure Blvd', '2005-12-30', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(8, 'DUMMY006', 'Sophia', 'F.', 'Davis', 'Female', '09123456706', '345 Fake Ave', '210 Reliable St', '2008-04-15', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(9, 'DUMMY007', 'Chris', 'G.', 'Garcia', 'Male', '09123456707', '567 Placeholder Rd', '432 Trusted Ct', '2003-07-07', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(10, 'DUMMY008', 'Olivia', 'H.', 'Martinez', 'Female', '09123456708', '678 Imaginary St', '543 Concrete Blvd', '2006-09-25', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(11, 'DUMMY009', 'Daniel', 'I.', 'Wilson', 'Male', '09123456709', '789 Fictional Ln', '654 Solid Ct', '2005-11-12', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(13, 'DUMMY011', 'James', 'K.', 'Thomas', 'Male', '09123456711', '101 Sample St', '123 Real Rd', '2006-06-14', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(14, 'DUMMY012', 'Mia', 'L.', 'Taylor', 'Female', '09123456712', '234 Mock Ln', '456 Fictional St', '2004-02-28', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(15, 'DUMMY013', 'Ethan', 'M.', 'Hernandez', 'Male', '09123456713', '789 Fiction St', '789 Fixed St', '2005-05-17', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(16, 'DUMMY014', 'Isabella', 'N.', 'Moore', 'Female', '09123456714', '101 Fake Ct', '321 Safe Rd', '2003-08-22', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(17, 'DUMMY015', 'Logan', 'O.', 'Jackson', 'Male', '09123456715', '234 Test Blvd', '432 Trusted Ln', '2006-03-09', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(18, 'DUMMY016', 'Charlotte', 'P.', 'White', 'Female', '09123456716', '345 Example St', '543 Concrete Ct', '2007-07-19', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(19, 'DUMMY017', 'Benjamin', 'Q.', 'Harris', 'Male', '09123456717', '567 Placeholder Ave', '654 Secure Blvd', '2004-09-14', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(20, 'DUMMY018', 'Amelia', 'R.', 'Clark', 'Female', '09123456718', '678 Imaginary Rd', '765 Safe Ct', '2005-11-21', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(21, 'DUMMY019', 'Lucas', 'S.', 'Rodriguez', 'Male', '09123456719', '789 Fiction Blvd', '876 Durable St', '2008-01-11', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(22, 'DUMMY020', 'Harper', 'T.', 'Lewis', 'Female', '09123456720', '890 Hypothetical St', '987 Concrete Ct', '2003-10-02', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(23, 'DUMMY021', 'Henry', 'U.', 'Walker', 'Male', '09123456721', '101 Sample St', '123 Real Rd', '2004-07-07', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(24, 'DUMMY022', 'Evelyn', 'V.', 'Hall', 'Female', '09123456722', '234 Mock Ln', '456 Fictional St', '2006-12-24', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(26, 'DUMMY024', 'Abigail', 'X.', 'Young', 'Female', '09123456724', '567 Placeholder Ct', '210 Fixed Ln', '2003-06-30', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(27, 'DUMMY025', 'Matthew', 'Y.', 'King', 'Male', '09123456725', '678 Imaginary Ave', '321 Safe St', '2007-09-10', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(28, 'DUMMY026', 'Ella', 'Z.', 'Wright', 'Female', '09123456726', '789 Fiction Rd', '432 Trusted Blvd', '2008-03-05', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(29, 'DUMMY027', 'Joseph', 'A.', 'Lopez', 'Male', '09123456727', '890 Fake Blvd', '543 Durable Ct', '2005-07-18', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(30, 'DUMMY028', 'Scarlett', 'B.', 'Scott', 'Female', '09123456728', '101 Hypothetical St', '654 Concrete Ave', '2006-05-22', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(31, 'DUMMY029', 'Samuel', 'C.', 'Green', 'Male', '09123456729', '234 Test Ln', '765 Safe Blvd', '2004-11-03', 1, '2025-03-01 18:35:55', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(32, 'DUMMY030', 'Mcgyver', 'Rin', 'Las-igan', 'Male', '09123456730', '345 Example Blvd', '876 Secure Rd', '2003-08-25', 1, '2025-03-01 18:35:55', '2025-03-07 16:25:31', 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(33, 'DUMMY031', 'Andrew', 'E.', 'Baker', 'Male', '09123456731', '101 Maple St', '123 Evergreen Rd', '2005-04-12', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(34, 'DUMMY032', 'Madison', 'F.', 'Rivera', 'Female', '09123456732', '456 Pine St', '456 Oak Blvd', '2006-07-19', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(35, 'DUMMY033', 'Nathan', 'G.', 'Mitchell', 'Male', '09123456733', '789 Birch St', '789 Elm Ct', '2004-09-25', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(36, 'DUMMY034', 'Chloe', 'H.', 'Perez', 'Female', '09123456734', '123 Cedar Ln', '321 Redwood Ave', '2003-12-08', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(37, 'DUMMY035', 'William', 'I.', 'Roberts', 'Male', '09123456735', '234 Spruce Blvd', '432 Sycamore Rd', '2007-02-14', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(38, 'DUMMY036', 'Ella', 'J.', 'Campbell', 'Female', '09123456736', '345 Cherry St', '543 Aspen Ct', '2005-11-21', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(39, 'DUMMY037', 'Jackson', 'K.', 'Gonzalez', 'Male', '09123456737', '567 Dogwood Ave', '654 Juniper Rd', '2008-06-03', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(40, 'DUMMY038', 'Lily', 'L.', 'Carter', 'Female', '09123456738', '678 Magnolia Ln', '765 Willow Blvd', '2006-08-29', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(41, 'DUMMY039', 'Owen', 'M.', 'Evans', 'Male', '09123456739', '789 Sequoia St', '876 Chestnut Ct', '2004-05-15', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(42, 'DUMMY040', 'Zoey', 'N.', 'Collins', 'Female', '09123456740', '890 Redwood Rd', '987 Mahogany Ave', '2007-01-22', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(43, 'DUMMY041', 'Ryan', 'O.', 'Edwards', 'Male', '09123456741', '101 Cypress Blvd', '123 Hickory St', '2006-07-10', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(44, 'DUMMY042', 'Hannah', 'P.', 'Stewart', 'Female', '09123456742', '234 Laurel Ln', '456 Acacia Rd', '2003-03-17', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(45, 'DUMMY043', 'Dylan', 'Q.', 'Morris', 'Male', '09123456743', '345 Beech St', '789 Chestnut Ave', '2005-12-04', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(46, 'DUMMY044', 'Victoria', 'R.', 'Rogers', 'Female', '09123456744', '567 Oak Blvd', '321 Palm Rd', '2004-08-19', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(47, 'DUMMY045', 'Eli', 'S.', 'Reed', 'Male', '09123456745', '678 Maple Ct', '432 Bamboo St', '2007-05-25', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(48, 'DUMMY046', 'Aria', 'T.', 'Cook', 'Female', '09123456746', '789 Walnut Rd', '543 Pine Ln', '2008-09-14', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(49, 'DUMMY047', 'Leo', 'U.', 'Morgan', 'Male', '09123456747', '890 Aspen St', '654 Birch Blvd', '2005-06-11', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(50, 'DUMMY048', 'Samantha', 'V.', 'Bell', 'Female', '09123456748', '101 Poplar Rd', '765 Sycamore Ln', '2003-12-07', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(51, 'DUMMY049', 'Isaac', 'W.', 'Murphy', 'Male', '09123456749', '234 Cedar Blvd', '876 Spruce St', '2006-02-22', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(52, 'DUMMY050', 'Layla', 'X.', 'Bailey', 'Female', '09123456750', '345 Juniper Ct', '987 Cherry Ave', '2004-11-13', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(53, 'DUMMY051', 'Carter', 'Y.', 'Howard', 'Male', '09123456751', '567 Chestnut Blvd', '123 Maple Ave', '2007-04-28', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(54, 'DUMMY052', 'Penelope', 'Z.', 'Ward', 'Female', '09123456752', '678 Elm St', '456 Redwood Rd', '2006-08-03', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(55, 'DUMMY053', 'Lincoln', 'A.', 'Cox', 'Male', '09123456753', '789 Palm Rd', '789 Oak Ct', '2005-01-15', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(56, 'DUMMY054', 'Stella', 'B.', 'Diaz', 'Female', '09123456754', '890 Spruce Ave', '321 Cedar Ln', '2003-09-30', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(57, 'DUMMY055', 'Julian', 'C.', 'Richardson', 'Male', '09123456755', '101 Hickory Rd', '432 Beech St', '2008-05-06', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(58, 'DUMMY056', 'Nova', 'D.', 'Wood', 'Female', '09123456756', '234 Acacia Blvd', '543 Poplar Ct', '2007-02-17', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(59, 'DUMMY057', 'Sebastian', 'E.', 'Watson', 'Male', '09123456757', '345 Bamboo Rd', '654 Walnut St', '2004-12-21', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(60, 'DUMMY058', 'Aurora', 'F.', 'Brooks', 'Female', '09123456758', '567 Sycamore Ln', '765 Magnolia Ave', '2006-06-24', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(61, 'DUMMY059', 'Miles', 'G.', 'Bennett', 'Male', '09123456759', '678 Maple Ct', '876 Cherry Blvd', '2005-07-11', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(62, 'DUMMY060', 'Violet', 'H.', 'Gray', 'Female', '09123456760', '789 Juniper Blvd', '987 Sequoia Rd', '2003-10-08', 1, '2025-03-01 18:37:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(63, 'DUMMY061', 'Caleb', 'I.', 'Foster', 'Male', '09123456761', '101 Maple St', '123 Evergreen Rd', '2005-06-18', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(64, 'DUMMY062', 'Hazel', 'J.', 'Gonzalez', 'Female', '09123456762', '456 Pine St', '456 Oak Blvd', '2006-03-22', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(65, 'DUMMY063', 'Eli', 'K.', 'Henderson', 'Male', '09123456763', '789 Birch St', '789 Elm Ct', '2004-11-09', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(66, 'DUMMY064', 'Lucy', 'L.', 'Fisher', 'Female', '09123456764', '123 Cedar Ln', '321 Redwood Ave', '2003-07-30', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(67, 'DUMMY065', 'Connor', 'M.', 'Cruz', 'Male', '09123456765', '234 Spruce Blvd', '432 Sycamore Rd', '2007-09-10', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(68, 'DUMMY066', 'Lillian', 'N.', 'Reyes', 'Female', '09123456766', '345 Cherry St', '543 Aspen Ct', '2005-02-17', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(69, 'DUMMY067', 'Aaron', 'O.', 'Griffin', 'Male', '09123456767', '567 Dogwood Ave', '654 Juniper Rd', '2008-08-04', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(70, 'DUMMY068', 'Paisley', 'P.', 'Russell', 'Female', '09123456768', '678 Magnolia Ln', '765 Willow Blvd', '2006-12-18', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(71, 'DUMMY069', 'Jonathan', 'Q.', 'Hayes', 'Male', '09123456769', '789 Sequoia St', '876 Chestnut Ct', '2004-04-21', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(72, 'DUMMY070', 'Bella', 'R.', 'Bryant', 'Female', '09123456770', '890 Redwood Rd', '987 Mahogany Ave', '2007-10-03', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(73, 'DUMMY071', 'Robert', 'S.', 'Ramos', 'Male', '09123456771', '101 Cypress Blvd', '123 Hickory St', '2006-05-28', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(74, 'DUMMY072', 'Aubrey', 'T.', 'James', 'Female', '09123456772', '234 Laurel Ln', '456 Acacia Rd', '2003-09-11', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(75, 'DUMMY073', 'Thomas', 'U.', 'Torres', 'Male', '09123456773', '345 Beech St', '789 Chestnut Ave', '2005-08-02', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(76, 'DUMMY074', 'Hannah', 'V.', 'Stevens', 'Female', '09123456774', '567 Oak Blvd', '321 Palm Rd', '2004-02-16', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(77, 'DUMMY075', 'Dominic', 'W.', 'Sanders', 'Male', '09123456775', '678 Maple Ct', '432 Bamboo St', '2007-07-23', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(78, 'DUMMY076', 'Zoey', 'X.', 'Price', 'Female', '09123456776', '789 Walnut Rd', '543 Pine Ln', '2008-03-12', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(79, 'DUMMY101', 'Longemar', 'Y.', 'Tabieros', 'Male', '09123456777', '890 Aspen St', '654 Birch Blvd', '2005-11-30', 1, '2025-03-01 18:38:37', '2025-03-07 14:01:26', 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(80, 'DUMMY078', 'Nora', 'Z.', 'Wood', 'Female', '09123456778', '101 Poplar Rd', '765 Sycamore Ln', '2003-06-05', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(81, 'DUMMY102', 'Glen', 'A.', 'Garabiles', 'Male', '09123456779', '234 Cedar Blvd', '876 Spruce St', '2006-01-21', 1, '2025-03-01 18:38:37', '2025-03-07 14:02:00', 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(82, 'DUMMY080', 'Skylar', 'B.', 'Watson', 'Female', '09123456780', '345 Juniper Ct', '987 Cherry Ave', '2004-10-15', 1, '2025-03-01 18:38:37', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(83, 'DUMMY061', 'Caleb', 'I.', 'Foster', 'Male', '09123456761', '101 Maple St', '123 Evergreen Rd', '2005-06-18', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(84, 'DUMMY062', 'Hazel', 'J.', 'Gonzalez', 'Female', '09123456762', '456 Pine St', '456 Oak Blvd', '2006-03-22', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(85, 'DUMMY063', 'Eli', 'K.', 'Henderson', 'Male', '09123456763', '789 Birch St', '789 Elm Ct', '2004-11-09', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(86, 'DUMMY064', 'Lucy', 'L.', 'Fisher', 'Female', '09123456764', '123 Cedar Ln', '321 Redwood Ave', '2003-07-30', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(87, 'DUMMY065', 'Connor', 'M.', 'Cruz', 'Male', '09123456765', '234 Spruce Blvd', '432 Sycamore Rd', '2007-09-10', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(88, 'DUMMY066', 'Lillian', 'N.', 'Reyes', 'Female', '09123456766', '345 Cherry St', '543 Aspen Ct', '2005-02-17', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(89, 'DUMMY067', 'Aaron', 'O.', 'Griffin', 'Male', '09123456767', '567 Dogwood Ave', '654 Juniper Rd', '2008-08-04', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(90, 'DUMMY068', 'Paisley', 'P.', 'Russell', 'Female', '09123456768', '678 Magnolia Ln', '765 Willow Blvd', '2006-12-18', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(91, 'DUMMY069', 'Jonathan', 'Q.', 'Hayes', 'Male', '09123456769', '789 Sequoia St', '876 Chestnut Ct', '2004-04-21', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(92, 'DUMMY103', 'Bella', 'R.', 'Donna', 'Female', '09123456770', '890 Redwood Rd', '987 Mahogany Ave', '2007-10-03', 1, '2025-03-01 18:40:53', '2025-03-07 16:33:49', 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(93, 'DUMMY071', 'Robert', 'S.', 'Ramos', 'Male', '09123456771', '101 Cypress Blvd', '123 Hickory St', '2006-05-28', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(94, 'DUMMY072', 'Aubrey', 'T.', 'James', 'Female', '09123456772', '234 Laurel Ln', '456 Acacia Rd', '2003-09-11', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(95, 'DUMMY073', 'Thomas', 'U.', 'Torres', 'Male', '09123456773', '345 Beech St', '789 Chestnut Ave', '2005-08-02', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(96, 'DUMMY074', 'Hannah', 'V.', 'Stevens', 'Female', '09123456774', '567 Oak Blvd', '321 Palm Rd', '2004-02-16', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(97, 'DUMMY075', 'Dominic', 'W.', 'Sanders', 'Male', '09123456775', '678 Maple Ct', '432 Bamboo St', '2007-07-23', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(98, 'DUMMY076', 'Zoey', 'X.', 'Price', 'Female', '09123456776', '789 Walnut Rd', '543 Pine Ln', '2008-03-12', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(99, 'DUMMY077', 'Ian', 'Y.', 'Bennett', 'Male', '09123456777', '890 Aspen St', '654 Birch Blvd', '2005-11-30', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(100, 'DUMMY078', 'Nora', 'Z.', 'Wood', 'Female', '09123456778', '101 Poplar Rd', '765 Sycamore Ln', '2003-06-05', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(101, 'DUMMY079', 'Adam', 'A.', 'Barnes', 'Male', '09123456779', '234 Cedar Blvd', '876 Spruce St', '2006-01-21', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(102, 'DUMMY080', 'Skylar', 'B.', 'Watson', 'Female', '09123456780', '345 Juniper Ct', '987 Cherry Ave', '2004-10-15', 1, '2025-03-01 18:40:53', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(103, 'DUMMY104', 'Mackyy', '', 'Rin', 'Male', '09664461597', 'Burgos', 'Burgos', '1998-08-12', 1, '2025-03-10 09:25:50', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(105, 'DUMMY111', 'Pogi', '', 'Las-igan', 'Male', '09664461597', 'Burgos', 'Burgos', '1998-09-12', 1, '2025-03-10 23:17:20', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(106, 'DUMMY123', 'Mary', '', 'Las-igan', 'Female', '09123456730', 'Burgos', 'Burgos', '2003-12-12', 1, '2025-03-11 00:13:04', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(107, 'DUMMY125', 'Ryan', '', 'Roldan', 'Male', '09123456779', 'Burgos', 'Burgos', '2003-12-12', 1, '2025-03-14 13:55:05', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(108, 'DUMMY127', 'Christine', '', 'Castro', 'Female', '09123456730', 'Sta. Maria', 'Sta. Maria', '2004-12-08', 1, '2025-03-14 13:58:04', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(109, 'DUMMY124', 'Ikam', '', 'Las-igan', 'Male', '09123456730', 'Burgos', 'Burgos', '2004-08-12', 1, '2025-03-14 14:07:08', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(110, 'DUMMY01', 'Mackyy', '', 'Rin', 'Male', '09664461587', 'manila', 'manila', '1998-12-08', 1, '2025-04-11 15:34:22', NULL, 0, NULL, '1st Year', '2025-05-08 16:05:08'),
(111, 'DUMMY167', 'Mark Guylord', '', 'Las-igan', 'Male', '09664461599', 'Burgos', 'Burgos', '2005-01-01', 1, '2025-05-08 16:16:46', NULL, 0, NULL, '1st Year', '2025-05-08 16:16:46'),
(112, 'DUMMY112', 'King', '', 'Bilen', 'Male', '09123456739', 'Santa', 'Santa', '2002-08-12', 1, '2025-05-08 16:23:20', NULL, 0, NULL, '1st Year', '2025-05-08 16:23:20'),
(113, 'DUMMY113', 'Ranier', '', 'Samuel', 'Male', '09123456771', 'Burgos', 'Burgos', '2005-11-11', 1, '2025-05-08 16:58:32', NULL, 0, NULL, '1st Year', '2025-05-08 16:58:32');

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'Student Information System'),
(6, 'short_name', 'SIS - PHP'),
(11, 'logo', 'uploads/logo-1643245863.png'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/cover-1643245863.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `middlename` text DEFAULT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 1 COMMENT '0=not verified, 1 = verified',
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `middlename`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `status`, `date_added`, `date_updated`) VALUES
(1, 'Adminstrator', NULL, 'Admin', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/avatar-1.png?v=1639468007', NULL, 1, 1, '2021-01-20 14:02:37', '2021-12-14 15:47:08'),
(8, 'Claire', NULL, 'Blake', 'cblake', '4744ddea876b11dcb1d169fadf494418', 'uploads/avatar-8.png?v=1643185259', NULL, 2, 1, '2022-01-26 16:20:59', '2022-01-26 16:20:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_history`
--
ALTER TABLE `academic_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `course_list`
--
ALTER TABLE `course_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `department_list`
--
ALTER TABLE `department_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_list`
--
ALTER TABLE `student_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_student_department` (`department_id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_history`
--
ALTER TABLE `academic_history`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- AUTO_INCREMENT for table `course_list`
--
ALTER TABLE `course_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `department_list`
--
ALTER TABLE `department_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `student_list`
--
ALTER TABLE `student_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `academic_history`
--
ALTER TABLE `academic_history`
  ADD CONSTRAINT `academic_history_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `academic_history_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `course_list` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `course_list`
--
ALTER TABLE `course_list`
  ADD CONSTRAINT `course_list_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `department_list` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_list`
--
ALTER TABLE `student_list`
  ADD CONSTRAINT `fk_student_department` FOREIGN KEY (`department_id`) REFERENCES `department_list` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
