<center>
		<footer>
           <p>All Rights Reserved 2018</p>
        <footer>
</center>