			<div class="span3" id="sidebar">

	<center>
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
						<li ><a href="dashboard.php"><i class="icon-chevron-right icon-large"></i><i class="icon-home icon-large"></i> Statistics</a></li>
						<li ><a href="students.php"><i class="icon-chevron-right icon-large"></i><i class="icon-group icon-large"></i> Students</a></li>
						<li class="active"><a href="payment_report.php"><i class="icon-chevron-right icon-large"></i><i class="icon-table icon-large"></i> Payment Report </a></li>
						<li><a href="student_report.php"><i class="icon-chevron-right icon-large"></i><i class="icon-file icon-large"></i> Reports</a></li>
                    </ul>
	</center>
            </div>